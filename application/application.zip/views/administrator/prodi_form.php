<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="alert alert-success" role="alert">
					<i class="fas fa-university"></i> Form Input Program Studi
				</div>
				<form action="<?= base_url('prodi/tambah_prodi_aksi') ?>" method="post">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="">Kode Prodi</label>
								<input type="text" name="kode_prodi" placeholder="Masukkan kode prodi" class="form-control" value="<?php echo set_value('kode_prodi'); ?>">
								<?= form_error('kode_prodi', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Nama Prodi</label>
								<input type="text" name="nama_prodi" placeholder="Masukkan nama prodi" class="form-control" value="<?php echo set_value('nama_prodi'); ?>">
								<?= form_error('nama_prodi', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Jenjang Studi</label>
								<select name="jenjang_studi" id="" class="form-control">
									<option value="">--Pilih Jenjang Studi--</option>
									<?php 
										$data['jenjang'] = $this->prodi_model->tampil_data('jenjang')->result();
										foreach($data['jenjang'] as $jenj)
										{ 
									?>
									<option value="<?=$jenj->jenjang_studi; ?>" <?php echo  set_select('jenjang_studi', $jenj->jenjang_studi); ?>><?=$jenj->jenjang_studi;?></option>
									<?php } ?>
								</select>
								<?= form_error('jenjang_studi', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Ketua Prodi</label>
								<select name="dosen" id="" class="form-control js-example-basic-single" required>
									<option value="">--Pilih Ketua Prodi--</option>
									<?php 
										$data['dosen'] = $this->prodi_model->tampil_data('dosen')->result();
										foreach($data['dosen'] as $dosen)
										{ 
									?>
									<option value="<?=$dosen->id_dosen; ?>" <?php echo  set_select('dosen', $dosen->id_dosen); ?>><?=$dosen->nama_dosen;?></option>
									<?php } ?>
								</select>
								<?= form_error('dosen', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<button type="submit" class="btn btn-primary">Simpan</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>