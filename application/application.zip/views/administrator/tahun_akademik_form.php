<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap justify-content-center">
							<h2 class="title-5">Buat jadwal pengisian KRS</h2>
						</div>
					</div>
				</div>
				<form action="<?= base_url('tahun_akademik/tambah_tahun_akademik_aksi') ?>" method="post">
					<div class="row justify-content-center">
						<div class="col-md-6">
							<div class="form-row">
								<div class="form-group col-md-5">
									<label for="">Tanggal awal</label>
									<input type="date" name="jadwal_awal" class="form-control" value="<?php echo set_value('jadwal_awal'); ?>" required>
									<?= form_error('jadwal_awal', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-2">
									<label for="">&nbsp;</label>
									<div clas="justify-content-center h4" style="text-align:center">s/d</div>
								</div>
								<div class="form-group col-md-5">
									<label for="">Tanggal akhir</label>
									<input type="date" name="jadwal_akhir" class="form-control" value="<?php echo set_value('jadwal_akhir'); ?>" required>
									<?= form_error('jadwal_akhir', '<div class="text-danger small">', '</div>'); ?>
								</div>
							</div>
							<div class="form-group">
								<label for="">Tahun Akademik</label>
								<input type="text" name="tahun_akademik" placeholder="Masukkan tahun akademik" class="form-control" value="<?php echo set_value('tahun_akademik'); ?>" required>
								<?= form_error('tahun_akademik', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Semester</label>
								<select name="semester" id="" class="form-control" required>
									<option>--Pilih Semester--</option>
									<option value="Ganjil" <?php echo  set_select('semester', 'Ganjil'); ?>>Ganjil</option>
									<option value="Genap" <?php echo  set_select('semester', 'Genap'); ?>>Genap</option>
								</select>
								<?= form_error('semester', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Status</label>
								<select name="status" id="" class="form-control" required>
									<option value="">--Pilih Status--</option>
									<option value="Aktif" <?php echo  set_select('status', 'Aktif'); ?>>Aktif</option>
									<option value="0" <?php echo  set_select('status', '0'); ?>>Tidak Aktif</option>
								</select>
								<?= form_error('status', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<button type="submit" class="btn btn-primary btn-block">Simpan</button>
							<a href="<?= base_url('krs') ?>" class="btn btn-outline-secondary btn-block"><i class="fas fa-undo">&nbsp; Kembali</i></a>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>