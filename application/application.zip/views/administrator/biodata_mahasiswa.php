<!DOCTYPE html>
<html lang="en">

	<head>

		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Title Page-->
		<title>Biodata</title>

		<!-- Fontfaces CSS-->
		<style>
			body{
				font-family: Calibri, Helvetica, sans-serif;
			}
			table{
				margin-left: auto;
				margin-right: auto;
			}
			.kepala{
				border-collapse:collapse;
    			border-spacing:0;
				text-align:center;
				line-height:15px;
				border-bottom:2px solid black;
			}	
			.kanan{
				width:200px;
			}
		</style>


	</head>
	<body>
		<table class="kepala" cellspacing="0" style="width:610px;position:relative;">
			<tr cellspacing="0">
				
				<th>
					<span style="width:70px;float:left;position:absolute;left:10px;top:0">
						<img class="mb-2" src="<?= base_url('assets_dashboard/images/icon/itbi.png'); ?>" alt=""
							style="width:100%;">
					</span>
					<span style="width:70px;float:right;position:absolute;right:0;top:0">
						<img class="mb-2" src="<?= base_url('assets_dashboard/images/icon/banpt.png'); ?>" alt=""
							style="width:100%;">
					</span>
					
					<span style="font-size:22px;color:rgb(255 0 0);">INSTITUT TEKNOLOGI DAN BISNIS INDONESIA</span><br>
					<span style="font-size:20px;font-weight:200;line-height:25px;">印 尼 技 術 與 商 業 學 院</span><br>
					<span style="font-size:14,5px;">ITB INDONESIA KAMPUS MILENIAL MEDAN & SERDANG BEDAGAI</span><br>
					<span style="font-size:13px;">Terakreditasi: SK BAN PT No. 413/AK/BAN-PT/Ak-PNB/PT/IX/2019</span><br>
					<span style="font-size:11px;font-weight:100;">
						<b>Kampus Milenial Medan</b>: Jln. Setia Budi No. 20 Simpang Pemda, Tanjung Sari - Medan
					</span><br>
					<span style="font-size:11px;font-weight:100;">
						<b>Kampus Milenial Serdang Bedagai</b>: Jln. Lintas Tebing Tinggi - Sei Rampah, Depan Bank BRI Kampung Pon – Sei Bamban
					</span><br>
					<span style="font-size:11px;color:rgb(0 0 255);">
						Program Studi: Teknik Informatika S1 - Sistem Informasi S1 - Teknik Industri S1 - Teknik Elektro S1 - Akuntansi D3
					</span><br>
					<span style="font-size:11px;font-weight:100;">
						Telp. dan HP/WA: 0822 7255 5670 (Ms. Afni), 0812 6247 0262 (Ms. Ridha) Web: <a href="http://milenial.itbi.ac.id">http://milenial.itbi.ac.id</a>
					</span>
				</th>
	
			</tr>
		</table>
		<table class="tabelb" style="padding-top:10px;">
			<tr>
				<th colspan="4">
					BIODATA MAHASISWA
				</th>
			</tr>
			<?php foreach($detail as $dt): ?>
			<tr>
				<th colspan="4" style="text-align:center;border:0;">
					<img class="mb-2" src="<?= base_url('assets_dashboard/images/icon/').$dt->photo; ?>" alt=""
						style="width:150px;">
				</th>
			</tr>
			<tr>
				<td>1</td>
				<td>Nama Lengkap</td>
				<td>:</td>
				<td class="kanan"><?= $dt->nama_lengkap; ?></td>
			</tr>
			<tr>
				<td>2</td>
				<td>NIM</td>
				<td>:</td>
				<td><?= $dt->nim; ?></td>
			</tr>
			<tr>
				<td>3</td>
				<td>NIK</td>
				<td>:</td>
				<td><?= $dt->nik; ?></td>
			</tr>
			<tr>
				<td>4</td>
				<td>Tempat & Tgl Lahir</td>
				<td>:</td>
				<td><?= $dt->tempat_lahir.", ".$dt->tanggal_lahir; ?></td>
			</tr>
			<tr>
				<td>5</td>
				<td>Jenis Kelamin</td>
				<td>:</td>
				<td><?= $dt->jenis_kelamin; ?></td>
			</tr>
			<tr>
				<td>6</td>
				<td>Status</td>
				<td>:</td>
				<td><?= $dt->status; ?></td>
			</tr>
			<tr>
				<td>7</td>
				<td>Agama</td>
				<td>:</td>
				<td><?= $dt->agama; ?></td>
			</tr>
			<tr>
				<td>8</td>
				<td>Alamat Tinggal</td>
				<td>:</td>
				<td><?= $dt->alamat; ?></td>
			</tr>
			<tr>
				<td>9</td>
				<td>Kode Pos</td>
				<td>:</td>
				<td><?= $dt->kode_pos; ?></td>
			</tr>
			<tr>
				<td>10</td>
				<td>No HP</td>
				<td>:</td>
				<td><?= $dt->telepon; ?></td>
			</tr>
			<tr>
				<td>11</td>
				<td>No WA</td>
				<td>:</td>
				<td><?= $dt->no_wa; ?></td>
			</tr>
			<tr>
				<td>12</td>
				<td>Email</td>
				<td>:</td>
				<td><?= $dt->email; ?></td>
			</tr>
			<tr>
				<td>13</td>
				<td>Nama Asal SMA/SMK</td>
				<td>:</td>
				<td><?= $dt->asal_sma; ?></td>
			</tr>
			<tr>
				<td>14</td>
				<td>Alamat Asal SMA/SMK</td>
				<td>:</td>
				<td><?= $dt->alamat_sma; ?></td>
			</tr>
			<tr>
				<td>15</td>
				<td>Jurusan Sewaktu SMA/SMK</td>
				<td>:</td>
				<td><?= $dt->jurusan_sma; ?></td>
			</tr>
			<tr>
				<td>16</td>
				<td>Nama Ibu</td>
				<td>:</td>
				<td><?= $dt->nama_ibu; ?></td>
			</tr>
			<tr>
				<td>17</td>
				<td>Nama Ayah</td>
				<td>:</td>
				<td><?= $dt->nama_ayah; ?></td>
			</tr>
			<tr>
				<td>18</td>
				<td>Pekerjaan Ayah</td>
				<td>:</td>
				<td><?= $dt->pekerjaan_ayah; ?></td>
			</tr>
			<tr>
				<td>19</td>
				<td>Pekerjaan Ibu</td>
				<td>:</td>
				<td><?= $dt->pekerjaan_ibu; ?></td>
			</tr>
			<tr>
				<td>20</td>
				<td>No. HP Orang Tua</td>
				<td>:</td>
				<td><?= $dt->nohp_ortu; ?></td>
			</tr>
			<tr>
				<td>21</td>
				<td>Alamat Lengkap Orang Tua</td>
				<td>:</td>
				<td><?= $dt->alamat_ortu; ?></td>
			</tr>
			<tr>
				<td>22</td>
				<td>Ukuran Jaket almamater</td>
				<td>:</td>
				<td><?= $dt->ukuran_jaket; ?></td>
			</tr>
			<tr>
				<td>23</td>
				<td>Pilihan Kampus</td>
				<td>:</td>
				<td><?= $dt->pilihan_kampus; ?></td>
			</tr>
			<tr>
				<td>24</td>
				<td>Jurusan</td>
				<td>:</td>
				<?php
					$where = array('id_prodi' => $dt->nama_prodi);
					$data['prodi']    = $this->mahasiswa_model->ambil_jenjang_prodi($where);
					foreach($data['prodi'] as $prod){ 
				?>
				<td><?= $prod->nama_prodi."-".$prod->jenjang_studi; ?></td>
				<?php	
										}
										?>
			</tr>
			<tr>
				<td>25</td>
				<td>Pilihan Kelas/Jadwal</td>
				<td>:</td>
				<td><?= $dt->pilihan_kelas; ?></td>
			</tr>

			<?php endforeach; ?>
		</table>

	</body>

</html>