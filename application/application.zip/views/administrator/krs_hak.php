<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card" style="overflow:auto;">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="h6">Pilih mahasiswa yang diberi hak mengisi KRS</h2>
							<a href="<?= base_url('krs') ?>" class="au-btn au-btn-icon au-btn--blue">
								<i class="fas fa-undo"></i>Kembali
							</a>
						</div>
					</div>
				</div>

				<?= $this->session->flashdata('pesan'); ?>
				<div class="card border-0">
					<div class="btn card-header text-left border-0" id="headingOne" data-toggle="collapse" data-target="#collapseOne"
								aria-expanded="true" aria-controls="collapseOne">
						<span class="h6">Informasi penting</span>
						<span class="fas fa-sort-down"></span>
					</div>

					<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">					
						<div class='alert alert-warning mt-3'>
							Untuk memberi hak mengisi KRS pada mahasiswa, klik tombol status
							dan pilih Lunas atau Izin maka semester mahasiswa yang bersangkutan akan otomatis berubah.
							Jika ingin mengubah semester silahkan masuk ke menu 
							<a href="<?= base_url('mahasiswa') ?>">mahasiswa</a>
						</div>
					</div>
				</div>

					
				
				<table class="table table-hover display responsive nowrap" id="datatableku" style="width:100%">
					<thead>
						<tr>
							<th>NO</th>
							<th>NIM</th>
							<th>NAMA LENGKAP</th>
							<th>Semester</th>
							<th>#</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$no = 1;
							foreach($mahasiswa as $mhs): ?>
						<tr>
							<td width="20px;"><?= $no++; ?></td>
							<td><?= $mhs->nim; ?></td>
							<td><?= $mhs->nama_lengkap; ?></td>
							<td><?= $mhs->nm_semester; ?></td>
							<td>
								<?php 
									if($mhs->status_uang_kuliah == "Lunas"){
								?>
									<span class="text-success"><em><?=$mhs->status_uang_kuliah;?></em></span>
									<span class="dropdown">
									<a class="dropdown-toggle text-secondary dropdowninfo" href="#" role="button" id="dropdownMenuLink"
										data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<span class="text-success fas fa-info-circle fa-sm"></span>
									</a>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
										<div class="p-2" style="white-space: normal;width:300px">
											Mahasiswa diizinkan mengisi KRS dan bisa 
											melihat KHS karena administrasi telah lunas
										</div>
									</div>
								</span>
								
								<?php
									}else if($mhs->status_uang_kuliah == "Izin"){
								?>

								<span class="text-success"><em><?=$mhs->status_uang_kuliah;?></em></span>
								<span class="dropdown">
									<a class="dropdown-toggle text-secondary dropdowninfo" href="#" role="button" id="dropdownMenuLink"
										data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<span class="text-success fas fa-info-circle fa-sm"></span>
									</a>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
										<div class="p-2" style="white-space: normal;width:300px">
											Mahasiswa diizinkan mengisi KRS tapi tidak bisa 
											melihat KHS karena administrasi belum lunas
										</div>
									</div>
								</span>

								<span class="dropdown">
									<a class="dropdown-toggle text-secondary" href="#" role="button" id="dropdownMenuLink"
										data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									</a>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
										<a class="dropdown-item" onclick="return confirm('Yakin akan memberi hak (Lunas) pengisian KRS?')"
											href="<?= base_url('krs/aksi_lunas_krs/'.$mhs->id) ?>">Lunas</a>
									</div>
								</span>

								<?php
									}else{
								?>
								<div class="dropdown show">
									<a class="btn btn-sm btn-success dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
										data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										Status
									</a>

									<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
										<a class="dropdown-item" onclick="return confirm('Yakin akan memberi hak (Lunas) pengisian KRS?')" href="<?= base_url('krs/aksi_hak_krs/'.$mhs->id) ?>">Lunas</a>
										<a class="dropdown-item" onclick="return confirm('Yakin akan memberi hak (Izin) pengisian KRS?')" href="<?= base_url('krs/aksi_izin_krs/'.$mhs->id) ?>">Izinkan</a>
									</div>
								</div>
								<?php
									}
								?>
							</td>
						</tr>

						<?php 
							endforeach; 
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>