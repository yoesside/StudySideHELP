<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<a href="<?= base_url('krs/hak_krs') ?>"
								class="btn btn-outline-danger">Hak pengisian KRS
							</a>
							<div class="input-group col-sm-4 p-0">
								<form class="form-inline" action="<?= base_url('tahun_akademik/sem_baru') ?>" method="post">
									<select id="inputState" name="sembaru" class="form-control btn btn-outline-success text-left">
										<option selected>- Tentukan Semester -</option>
										<option>Tetap</option>
										<option value="Semester_Baru">Semester Baru</option>
									</select>
									<div class="input-group-prepend">
										<button type="submit" class="btn btn-success rounded-0" id="semesterbr" onclick="return confirm('Yakin akan membuat semester baru?')">
											Kirim
										</button>
									</div>
								</form>
							</div>
							<a href="<?= base_url('tahun_akademik/tambah_tahun_akademik') ?>"
								class="btn btn-outline-primary">
								<i class="zmdi zmdi-plus"></i>&nbsp; Buat jadwal Pengisian KRS
							</a>
						</div>
					</div>
				</div>

				<h4 class="pb-3">Jadwal pengisian KRS </h4>
				<?= $this->session->flashdata('pesan'); ?>

				<table class="table table-hover display responsive nowrap" id="datatableku" style="width:100%">
					<thead>
						<tr>
							<th>NO</th>
							<th>TAHUN AKADEMIK</th>
							<th>Jadwal KRS</th>
							<th>STATUS</th>
							<th>AKSI</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$no = 1;
						foreach($tahun_akademik as $tak):

							$date1=date_create($tak->jadwal_awal_krs);
							$date2=date_create($tak->jadwal_akhir_krs);
						?>
						<tr>
							<td><?= $no++; ?></td>
							<td><?= $tak->tahun_akademik."-".$tak->jns_semester; ?></td>
							<td><?= date_format($date1,"d-F-Y")." s/d ".date_format($date2,"d-F-Y"); ?></td>
							<td><?= $tak->status; ?></td>
							<td>
								<?= anchor('tahun_akademik/update/'.$tak->id_thn_akad, '<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></div>') ?>
								<?= anchor('tahun_akademik/delete/'.$tak->id_thn_akad, '<div onclick="return confirm(\'Yakin akan menghapus?\')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></div>') ?>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>