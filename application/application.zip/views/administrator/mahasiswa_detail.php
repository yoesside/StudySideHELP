<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card" style="overflow:auto;">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap d-flex flex-row-reverse bd-highlight">
							<div class="dropdown">
								<button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton"
									data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<i class="fas fa-print"></i>&nbsp; Cetak Biodata
								</button>
								<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
									<?php foreach($detail as $dt_id): ?>
									<a class="dropdown-item" href="<?= base_url('mahasiswa/cetakDetailPdf/'.$dt_id->id) ?>" target="_blank">PDF</a>
									<a class="dropdown-item" href="<?= base_url('mahasiswa/cetakWord/'.$dt_id->id) ?>" target="_blank">Docx</a>
									<a class="dropdown-item" href="<?= base_url('mahasiswa/cetakXlsx/'.$dt_id->id) ?>" target="_blank">Xlsx</a>
									<a class="dropdown-item" href="<?= base_url('mahasiswa/Biodatahtml/'.$dt_id->id) ?>" target="_blank">HTML</a>
									<?php endforeach; ?>
								</div>
							</div>
						</div>
						<div class="overview-wrap justify-content-center">
							<h2 class="title-1 pr-4">Biodata Mahasiswa</h2>
						</div>
					</div>
				</div>
				<div class="row justify-content-center">
					<div class="col-md-8">
						<div class="table-responsive">
							<table class="table table-hover" style="font-size:14px;">

								<?php foreach($detail as $dt): ?>
								<tr>
									<th colspan="4" style="text-align:center;border:0;">
										<img class="mb-2" src="<?= base_url('assets_dashboard/images/icon/').$dt->photo; ?>" alt=""
											style="width:30%;">
									</th>
								</tr>
								<tr>
									<th>1</th>
									<th>NAMA LENGKAP</th>
									<td>:</td>
									<td><?= $dt->nama_lengkap; ?></td>
								</tr>
								<tr>
									<th>2</th>
									<th>NIM</th>
									<td>:</td>
									<td><?= $dt->nim; ?></td>
								</tr>
								<tr>
									<th>3</th>
									<th>NIK</th>
									<td>:</td>
									<td><?= $dt->nik; ?></td>
								</tr>
								<tr>
									<th>4</th>
									<th>Tempat & Tgl Lahir</th>
									<td>:</td>
									<td><?= $dt->tempat_lahir.", ".$dt->tanggal_lahir; ?></td>
								</tr>
								<tr>
									<th>5</th>
									<th>Jenis Kelamin</th>
									<td>:</td>
									<td><?= $dt->jenis_kelamin; ?></td>
								</tr>
								<tr>
									<th>6</th>
									<th>Status</th>
									<td>:</td>
									<td><?= $dt->status; ?></td>
								</tr>
								<tr>
									<th>7</th>
									<th>Agama</th>
									<td>:</td>
									<td><?= $dt->agama; ?></td>
								</tr>
								<tr>
									<th>8</th>
									<th>Alamat Tinggal</th>
									<td>:</td>
									<td><?= $dt->alamat; ?></td>
								</tr>
								<tr>
									<th>9</th>
									<th>Kode Pos</th>
									<td>:</td>
									<td><?= $dt->kode_pos; ?></td>
								</tr>
								<tr>
									<th>10</th>
									<th>No HP</th>
									<td>:</td>
									<td><?= $dt->telepon; ?></td>
								</tr>
								<tr>
									<th>11</th>
									<th>No WA</th>
									<td>:</td>
									<td><?= $dt->no_wa; ?></td>
								</tr>
								<tr>
									<th>12</th>
									<th>EMAIL</th>
									<td>:</td>
									<td><?= $dt->email; ?></td>
								</tr>
								<tr>
									<th>13</th>
									<th>Nama Asal SMA/SMK</th>
									<td>:</td>
									<td><?= $dt->asal_sma; ?></td>
								</tr>
								<tr>
									<th>14</th>
									<th>Alamat Asal SMA/SMK</th>
									<td>:</td>
									<td><?= $dt->alamat_sma; ?></td>
								</tr>
								<tr>
									<th>15</th>
									<th>Jurusan Sewaktu SMA/SMK</th>
									<td>:</td>
									<td><?= $dt->jurusan_sma; ?></td>
								</tr>
								<tr>
									<th>16</th>
									<th>Nama Ibu</th>
									<td>:</td>
									<td><?= $dt->nama_ibu; ?></td>
								</tr>
								<tr>
									<th>17</th>
									<th>Nama Ayah</th>
									<td>:</td>
									<td><?= $dt->nama_ayah; ?></td>
								</tr>
								<tr>
									<th>18</th>
									<th>Pekerjaan Ayah</th>
									<td>:</td>
									<td><?= $dt->pekerjaan_ayah; ?></td>
								</tr>
								<tr>
									<th>19</th>
									<th>Pekerjaan Ibu</th>
									<td>:</td>
									<td><?= $dt->pekerjaan_ibu; ?></td>
								</tr>
								<tr>
									<th>20</th>
									<th>No. HP Orang Tua</th>
									<td>:</td>
									<td><?= $dt->nohp_ortu; ?></td>
								</tr>
								<tr>
									<th>21</th>
									<th>Alamat Lengkap Orang Tua</th>
									<td>:</td>
									<td><?= $dt->alamat_ortu; ?></td>
								</tr>
								<tr>
									<th>22</th>
									<th>Ukuran Jaket almamater</th>
									<td>:</td>
									<td><?= $dt->ukuran_jaket; ?></td>
								</tr>
								<tr>
									<th>23</th>
									<th>Pilihan Kampus</th>
									<td>:</td>
									<td><?= $dt->pilihan_kampus; ?></td>
								</tr>
								<tr>
									<th>24</th>
									<th>Jurusan</th>
									<td>:</td>
									<?php
										$where = array('id_prodi' => $dt->nama_prodi);
										$data['prodi']    = $this->mahasiswa_model->ambil_jenjang_prodi($where);
										foreach($data['prodi'] as $prod){ 
											?>
									<td><?= $prod->nama_prodi."-".$prod->jenjang_studi; ?></td>
									<?php	
									}
									?>
								</tr>
								<tr>
									<th>25</th>
									<th>Pilihan Kelas/Jadwal</th>
									<td>:</td>
									<td><?= $dt->pilihan_kelas; ?></td>
								</tr>

								<?php endforeach; ?>
							</table>
						</div>
						<a href="<?= base_url('mahasiswa') ?>" class="btn btn-outline-secondary btn-block"><i class="fas fa-undo">&nbsp; Kembali</i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>