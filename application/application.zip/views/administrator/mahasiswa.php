<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card" style="overflow:auto;">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<?php 
								foreach($prodi as $kodeprod):
							?>
							<h2 class="h6">Daftar mahasiswa dalam program studi <?= $kodeprod->nama_prodi."-".$kodeprod->jenjang_studi; ?></h2>
							<?php
								endforeach; 
							?>
							<a href="<?= base_url('mahasiswa/tambah_mahasiswa') ?>" class="au-btn au-btn-icon au-btn--blue">
								<i class="zmdi zmdi-plus"></i>Tambah Mahasiswa
							</a>
						</div>
					</div>
				</div>

				<?= $this->session->flashdata('pesan'); ?>
				<div class='alert alert-warning mt-3'>
					Untuk mengubah semester mahasiswa, silahkan di klik menu ubah semester melalui
					tanda titi tiga pada kolom tindakan dari mahasiswa yang bersangkutan
				</div>
				<table class="table table-hover display responsive nowrap" id="datatableku" style="width:100%">
					<thead>
						<tr>
							<th>NO</th>
							<th>NIM</th>
							<th>NAMA LENGKAP</th>
							<th>Status User</th>
							<th>Tindakan</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							if (empty($mahasiswa)){
								echo "<div class='alert alert-warning'>Belum ada data pada program studi ini</div>";
							}else{
							$no = 1;
							foreach($mahasiswa as $mhs): ?>
						<tr>
							<td width="20px;"><?= $no++; ?></td>
							<td><?= $mhs->nim; ?></td>
							<td><?= $mhs->nama_lengkap; ?></td>
							<td>
								<?php 
									if($mhs->status_user == "Sudah"){
								?>
								<p class="text-success"><em>Telah menjadi user.</em></p>
								<?php
									}else{
								?>
								<p class="text-danger"><em>Belum menjadi user.</em></p>
								<?php
									}
								?>
							</td>
							<td>
								<div class="dropdown">
									<a class="btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
										aria-expanded="false">
										<i class="fas fa-ellipsis-v"></i>
									</a>
									<div class="dropdown-menu"  aria-labelledby="dropdownMenuButton">
										<a class="dropdown-item" href="<?= base_url('mahasiswa/detail/'.$mhs->id) ?>">Detail</a>
										<a class="dropdown-item" href="<?= base_url('mahasiswa/update/'.$mhs->id) ?>">Edit</a>
										<a class="dropdown-item" href="<?= base_url('mahasiswa/ubah_semester/'.$mhs->id) ?>">Ubah Semester</a>
										<a class="dropdown-item" onclick="return confirm('Yakin akan menghapus?')"
											href="<?= base_url('mahasiswa/delete/'.$mhs->id) ?>">Hapus</a>
											<?php 
												if($mhs->status_user == "Sudah"){
													echo "";
												}else{
											?>
											<a class="dropdown-item" onclick="return confirm('Yakin jadikan sebagi user?')"
											href="<?= base_url('users/jadi_user/'.$mhs->id) ?>">Jadikan User</a>
											<?php
												}
											?>
									</div>
								</div>
							</td>
						</tr>

						<?php 
							endforeach; 
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>