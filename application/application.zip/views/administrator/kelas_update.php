<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap justify-content-center">
							<h2 class="title-5">Edit Kelas</h2>
						</div>
					</div>
				</div>
				<form action="<?= base_url('kelas/update_aksi') ?>" method="post">
					<div class="row justify-content-center">
						<div class="col-md-6">
							<?php
								foreach ($kelas as $rowkelas){
									$nama_kelas = $rowkelas->nama_kelas;
								}
							?>
							<div class="form-group">
								<label for="">Nama Kelas</label>
								<input name="id_kelas" type="hidden" class="form-control" value="<?= $rowkelas->id_kelas; ?>" required>
								<input name="nama_kelas" class="form-control" value="<?= $nama_kelas; ?>" placeholder="Masukkan nama kelas" required>
								<?= form_error('nama_kelas', '<div class="text-danger small">', '</div>'); ?>
							</div>
							

							<button type="submit" class="btn btn-primary btn-block">Simpan</button>
							<a href="<?= base_url('kelas') ?>" class="btn btn-outline-secondary btn-block"><i class="fas fa-undo">&nbsp; Kembali</i></a>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>