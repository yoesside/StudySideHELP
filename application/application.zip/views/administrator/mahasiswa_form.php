<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap justify-content-center">
							<h2 class="title-1">Tambah Data Mahasiswa</h2>
						</div>
					</div>
				</div>


				<?= form_open_multipart('mahasiswa/tambah_mahasiswa_aksi'); ?>

				<div class="row justify-content-center">
					<div class="col-md-8">
						
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="">NIM</label>
								<input type="text" name="nim" class="form-control" value="<?php echo set_value('nim'); ?>">
								<?= form_error('nim', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group col-md-6">
								<label for="">NIK</label>
								<input type="text" name="nik" class="form-control" value="<?php echo set_value('nik'); ?>">
								<?= form_error('nik', '<div class="text-danger small">', '</div>'); ?>
							</div>
						</div>
						<div class="form-group">
							<label for="">Nama Mahasiswa</label>
							<input type="text" name="nama_lengkap" class="form-control" value="<?php echo set_value('nama_lengkap'); ?>">
							<?= form_error('nama_lengkap', '<div class="text-danger small">', '</div>'); ?>
						</div>
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="">Tempat Lahir</label>
								<input type="text" name="tempat_lahir" class="form-control"
									value="<?php echo set_value('tempat_lahir'); ?>">
								<?= form_error('tempat_lahir', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group col-md-6">
								<label for="">Tanggal Lahir</label>
								<input type="date" name="tanggal_lahir" class="form-control"
									value="<?php echo set_value('tanggal_lahir'); ?>">
								<?= form_error('tanggal_lahir', '<div class="text-danger small">', '</div>'); ?>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="">Jenis Kelamin</label>
								<select name="jenis_kelamin" id="" class="form-control">
									<option value="">--Pilih jenis kelamin--</option>
									<option value="Laki-laki" <?php echo  set_select('jenis_kelamin', 'Laki-laki'); ?>>Laki-laki</option>
									<option value="Perempuan" <?php echo  set_select('jenis_kelamin', 'Perempuan'); ?>>Perempuan</option>
								</select>
								<?= form_error('jenis_kelamin', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group col-md-6">
								<label for="">Status</label>
								<select name="status" id="" class="form-control">
									<option value="">--Pilih Status--</option>
									<option value="Belum Menikah" <?php echo  set_select('status', 'Belum Menikah'); ?>>Belum Menikah
									</option>
									<option value="Menikah" <?php echo  set_select('status', 'Menikah'); ?>>Menikah</option>
									<option value="Bercerai" <?php echo  set_select('status', 'Bercerai'); ?>>Bercerai</option>
								</select>
								<?= form_error('status', '<div class="text-danger small">', '</div>'); ?>
							</div>
						</div>
						<div class="form-group">
							<label for="">Status</label>
							<select name="agama" id="" class="form-control">
								<option value="">--Pilih Agama--</option>
								<option value="Islam" <?php echo  set_select('agama', 'Islam'); ?>>Islam</option>
								<option value="Kristen Protestan" <?php echo  set_select('agama', 'Kristen Protestan'); ?>>Kristen Protestan</option>
								<option value="Kristen Katolik" <?php echo  set_select('agama', 'Kristen Katolik'); ?>>Kristen Katolik</option>
								<option value="Hindu" <?php echo  set_select('agama', 'Hindu'); ?>>Hindu</option>
								<option value="Buddha" <?php echo  set_select('agama', 'Buddha'); ?>>Buddha</option>
								<option value="Khonghucu" <?php echo  set_select('agama', 'Khonghucu'); ?>>Khonghucu</option>
							</select>
							<?= form_error('agama', '<div class="text-danger small">', '</div>'); ?>
						</div>
						<div class="form-group">
							<label for="">Alamat Tinggal</label>
							<input type="text" name="alamat" class="form-control" value="<?php echo set_value('alamat'); ?>">
							<?= form_error('alamat', '<div class="text-danger small">', '</div>'); ?>
						</div>
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="">Kode Pos</label>
								<input type="text" name="kode_pos" class="form-control" value="<?php echo set_value('kode_pos'); ?>">
								<?= form_error('kode_pos', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group col-md-6">
								<label for="">No HP</label>
								<input type="text" name="telepon" class="form-control" value="<?php echo set_value('telepon'); ?>">
								<?= form_error('telepon', '<div class="text-danger small">', '</div>'); ?>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="">No WA</label>
								<input type="text" name="no_wa" class="form-control" value="<?php echo set_value('no_wa'); ?>">
								<?= form_error('no_wa', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group col-md-6">
								<label for="">Email</label>
								<input type="text" name="email" class="form-control" value="<?php echo set_value('email'); ?>">
								<?= form_error('email', '<div class="text-danger small">', '</div>'); ?>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="">Asal SMA/SMK</label>
								<input type="text" name="asal_sma" class="form-control" value="<?php echo set_value('asal_sma'); ?>">
								<?= form_error('asal_sma', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group col-md-6">
								<label for="">Jurusan SMA/SMK</label>
								<input type="text" name="jurusan_sma" class="form-control"
									value="<?php echo set_value('jurusan_sma'); ?>">
								<?= form_error('jurusan_sma', '<div class="text-danger small">', '</div>'); ?>
							</div>
						</div>
						<div class="form-group">
							<label for="">Alamat SMA/SMK</label>
							<input type="text" name="alamat_sma" class="form-control" value="<?php echo set_value('alamat_sma'); ?>">
							<?= form_error('alamat_sma', '<div class="text-danger small">', '</div>'); ?>
						</div>
						<div class="form-group">
							<label for="">Nama Ibu</label>
							<input type="text" name="nama_ibu" class="form-control" value="<?php echo set_value('nama_ibu'); ?>">
							<?= form_error('nama_ibu', '<div class="text-danger small">', '</div>'); ?>
						</div>
						<div class="form-group">
							<label for="">Nama Ayah</label>
							<input type="text" name="nama_ayah" class="form-control" value="<?php echo set_value('nama_ayah'); ?>">
							<?= form_error('nama_ayah', '<div class="text-danger small">', '</div>'); ?>
						</div>
						<div class="form-row">
							<div class="form-group col-md-4">
								<label for="">Pekerjaan Ayah</label>
								<input type="text" name="pekerjaan_ayah" class="form-control"
									value="<?php echo set_value('pekerjaan_ayah'); ?>">
								<?= form_error('pekerjaan_ayah', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group col-md-4">
								<label for="">Pekerjaan Ibu</label>
								<input type="text" name="pekerjaan_ibu" class="form-control"
									value="<?php echo set_value('pekerjaan_ibu'); ?>">
								<?= form_error('pekerjaan_ibu', '<div class="text-danger small">', '</div>'); ?>
							</div>

							<div class="form-group col-md-4">
								<label for="">No HP Orang Tua</label>
								<input type="text" name="nohp_ortu" class="form-control" value="<?php echo set_value('nohp_ortu'); ?>">
								<?= form_error('nohp_ortu', '<div class="text-danger small">', '</div>'); ?>
							</div>
						</div>
						<div class="form-group">
							<label for="">Alamat Orang Tua</label>
							<input type="text" name="alamat_ortu" class="form-control" value="<?php echo set_value('alamat_ortu'); ?>">
							<?= form_error('alamat_ortu', '<div class="text-danger small">', '</div>'); ?>
						</div>
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="">Ukuran Jaket Almamater</label>
								<input type="text" name="ukuran_jaket" class="form-control"
									value="<?php echo set_value('ukuran_jaket'); ?>">
								<?= form_error('ukuran_jaket', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group col-md-6">
								<label for="">Pilihan Kampus</label>
								<input type="text" name="pilihan_kampus" class="form-control"
									value="<?php echo set_value('pilihan_kampus'); ?>">
								<?= form_error('pilihan_kampus', '<div class="text-danger small">', '</div>'); ?>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="">Jenjang Studi</label>
								<select name="jenjang_studi" id="mahasiswa_jenjang" class="form-control" required>
									<option value="0">--Pilih Jenjang Studi--</option>
									<?php 
										$data['jenj'] = $this->mahasiswa_model->tampil_data('jenjang')->result();
										foreach($data['jenj'] as $jenjang_s): 
									?>
									<option value="<?= $jenjang_s->jenjang_studi; ?>">
										<?= $jenjang_s->jenjang_studi; ?>
									</option>
									<?php endforeach; ?>
								</select>
								<?= form_error('jenis_kelamin', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group col-md-6">
								<label for="">Program Studi</label>
								<select name="nama_prodi" id="mahasiswa_prodi" class="form-control" required>
									<option>--Pilih Program Studi--</option>
								</select>
								<?= form_error('nama_prodi', '<div class="text-danger small">', '</div>'); ?>
							</div>
						</div>
						<div class="form-group">
							<label for="">Dosen Wali</label>
							<select name="dosen" id="" class="form-control js-example-basic-single">
								<option value="">--Pilih Dosen Wali--</option>
								<?php 
										$data['dosen'] = $this->prodi_model->tampil_data('dosen')->result();
										foreach($data['dosen'] as $dosen)
										{ 
									?>
								<option value="<?=$dosen->id_dosen; ?>" <?php echo  set_select('dosen', $dosen->id_dosen); ?>>
									<?=$dosen->nama_dosen;?></option>
								<?php } ?>
							</select>
							<?= form_error('dosen', '<div class="text-danger small">', '</div>'); ?>
						</div>
						<div class="form-group">
							<label for="">Pilihan Kelas/Jadwal</label>
							<input type="text" name="pilihan_kelas" class="form-control" value="<?php echo set_value('pilihan_kelas'); ?>">
							<?= form_error('pilihan_kelas', '<div class="text-danger small">', '</div>'); ?>
						</div>
						<div class="form-group">
							<label for="">Foto</label><br>
							<input type="file" name="photo" required>
						</div>						
						<button type="submit" class="btn btn-primary btn-block">Simpan</button>
						<a href="<?= base_url('mahasiswa') ?>" class="btn btn-outline-secondary btn-block"><i class="fas fa-undo">&nbsp; Kembali</i></a>
													
					</div>
				</div>

				<?php form_close(); ?>
			</div>
		</div>
	</div>
</div>