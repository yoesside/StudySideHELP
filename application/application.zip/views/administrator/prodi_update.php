<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="alert alert-success" role="alert">
					<i class="fas fa-university"></i> Form Update Prodi
				</div>

				<?php foreach($prodi as $prd): ?>
				<form action="<?= base_url('prodi/update_aksi') ?>" method="post">

					<div class="row">
						<div class="col-md-6">

							<div class="form-group">
								<label for="">Kode Prodi</label>
								<input type="hidden" name="id_prodi" value="<?= $prd->id_prodi; ?>" required>
								<input type="text" name="kode_prodi" class="form-control" value="<?= $prd->kode_prodi; ?>" value="<?php echo set_value('kode_prodi'); ?>">
								<?= form_error('kode_prodi', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Nama Prodi</label>
								<input type="text" name="nama_prodi" class="form-control" value="<?= $prd->nama_prodi; ?>" required>
								<?= form_error('nama_prodi', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Jenjang Studi</label>
								<select name="jenjang_studi" id="" class="form-control" required>
									<option value="">--Pilih Jenjang Studi--</option>
									<?php 
										$data['jenjang'] = $this->prodi_model->tampil_data('jenjang')->result();
										foreach($data['jenjang'] as $jenj)
										{ 
									?>
									<option value="<?=$jenj->jenjang_studi; ?>" <?php if($jenj->jenjang_studi == $prd->jenjang_studi){echo 'selected=selected';} ?>><?=$jenj->jenjang_studi;?></option>
									<?php } ?>
								</select>
								<?= form_error('jenjang_studi', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Ketua Prodi</label>
								<select name="dosen" id="" class="form-control js-example-basic-single" required>
									<option value="">--Pilih Ketua Prodi--</option>
									<?php 
										$data['dosen'] = $this->prodi_model->tampil_data('dosen')->result();
										foreach($data['dosen'] as $dosen)
										{ 
									?>
									<option value="<?=$dosen->id_dosen; ?>" <?php if($dosen->id_dosen == $prd->ketua_prodi){echo 'selected=selected';} ?>><?=$dosen->nama_dosen;?></option>
									<?php } ?>
								</select>
								<?= form_error('dosen', '<div class="text-danger small">', '</div>'); ?>
							</div>

							<button type="submit" class="btn btn-primary">Simpan</button>

						</div>
					</div>

				</form>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</div>