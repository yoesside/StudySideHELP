<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="title-1">Daftar KHS Mahasiswa</h2>
						</div>
					</div>
				</div>
				<table class="table table-hover display responsive nowrap" id="datatableku" style="width:100%">
					<thead>
						<tr>
							<th>NO</th>
							<th>NIM</th>
							<th>NAMA LENGKAP</th>
							<th>KHS</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							if (empty($mahasiswa)){
								echo "<div class='alert alert-warning'>Belum ada data Mahasiswa</div>";
							}else{
							$no = 1;
							foreach($mahasiswa as $mhs): ?>
						<tr>
							<td width="20px;"><?= $no++; ?></td>
							<td><?= $mhs->nim; ?></td>
							<td><?= $mhs->nama_lengkap; ?></td>
							<td>
								<div class="dropdown">
									<button class="btn btn-danger btn-sm dropdown-toggle" type="button" id="dropdownMenuButton"
										data-toggle="dropdown" data-boundary="viewport" aria-haspopup="true" aria-expanded="false">
										<i class="fas fa-print"></i>&nbsp; Cetak KHS
									</button>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="min-width:100px;">
										<a class="dropdown-item" href="<?= base_url('khs/cetakKHSSemuaPdf/'.$mhs->id) ?>" target="_blank">PDF</a>
										<a class="dropdown-item" href="<?= base_url('khs/cetakKHSSemuaWord/'.$mhs->id) ?>" target="_blank">Docx</a>
										<a class="dropdown-item" href="<?= base_url('khs/cetakKHSXlsx/') ?>" target="_blank">Xlsx</a>
										<a class="dropdown-item" href="<?= base_url('khs/cetakKHSHTML/') ?>" target="_blank">HTML</a>
									</div>
								</div>
							</td>
						</tr>

						<?php 
							endforeach; 
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>