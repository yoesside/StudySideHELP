<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="title-1">Edit Mata Kuliah</h2>
						</div>
					</div>
				</div>

				<?php foreach($matakuliah as $mk): ?>
				<form action="<?= base_url('matakuliah/update_aksi') ?>" method="post">

					<div class="row">
						<div class="col-md-6">

							<div class="form-group">
								<label for="">Nama Mata Kuliah</label>
								<input type="hidden" name="kode_matakuliah" class="form-control" value="<?= $mk->kode_matakuliah ?>" required>
								<input type="text" name="nama_matakuliah" class="form-control" value="<?= $mk->nama_matakuliah ?>" required>
							</div>
							<div class="form-group">
								<label for="">SKS</label>
								<select name="sks" id="" class="form-control" required>
									<option value="1" <?php if($mk->sks == '1'){echo 'selected=selected';} ?>>1</option>
									<option value="2" <?php if($mk->sks == '2'){echo 'selected=selected';} ?>>2</option>
									<option value="3" <?php if($mk->sks == '3'){echo 'selected=selected';} ?>>3</option>
									<option value="4" <?php if($mk->sks == '4'){echo 'selected=selected';} ?>>4</option>
									<option value="5" <?php if($mk->sks == '5'){echo 'selected=selected';} ?>>5</option>
									<option value="6" <?php if($mk->sks == '6'){echo 'selected=selected';} ?>>6</option>
								</select>
							</div>
							<div class="form-group">
								<label for="">Semester</label>
								<select name="semester" id="" class="form-control"> required
									<option value="1" <?php if($mk->semester == '1'){echo 'selected=selected';} ?>>1</option>
									<option value="2" <?php if($mk->semester == '2'){echo 'selected=selected';} ?>>2</option>
									<option value="3" <?php if($mk->semester == '3'){echo 'selected=selected';} ?>>3</option>
									<option value="4" <?php if($mk->semester == '4'){echo 'selected=selected';} ?>>4</option>
									<option value="5" <?php if($mk->semester == '5'){echo 'selected=selected';} ?>>5</option>
									<option value="6" <?php if($mk->semester == '6'){echo 'selected=selected';} ?>>6</option>
									<option value="7" <?php if($mk->semester == '7'){echo 'selected=selected';} ?>>7</option>
									<option value="8" <?php if($mk->semester == '8'){echo 'selected=selected';} ?>>8</option>
								</select>
							</div>
							<div class="form-group">
								<label for="">Jenis Semester</label>
								<select name="jns_semester" id="" class="form-control" required>
									<option value="Ganjil" <?php if($mk->jns_semester == 'Ganjil'){echo 'selected=selected';} ?>>Ganjil</option>
									<option value="Genap" <?php if($mk->jns_semester == 'Genap'){echo 'selected=selected';} ?>>Genap</option>
								</select>
								<?= form_error('jns_semester', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Program Studi</label>
								<select name="nama_prodi" id="" class="form-control" required>
									<?php foreach($prodi as $prd): ?>
									<option value="<?= $prd->id_prodi; ?>" <?php if($prd->id_prodi == $mk->id_prodi){echo 'selected=selected';}?>>
									<?= $prd->nama_prodi."-".$prd->jenjang_studi; ?></option>
									<?php endforeach; ?>
								</select>
							</div>
							<button type="submit" class="btn btn-primary btn-sm">Simpan</button>

						</div>
					</div>

				</form>
				<?php endforeach; ?>

			</div>
		</div>
	</div>
</div>