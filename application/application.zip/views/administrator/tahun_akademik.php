<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="title-1">Tahun Akademik</h2>
							<a href="<?= base_url('tahun_akademik/tambah_tahun_akademik') ?>" class="au-btn au-btn-icon au-btn--blue">
								<i class="zmdi zmdi-plus"></i>Tambah Tahun Akademik
							</a>
						</div>
					</div>
				</div>

				<?= $this->session->flashdata('pesan'); ?>

				<table class="table table-hover display responsive nowrap" id="datatableku" style="width:100%">
					<thead>
						<tr>
							<th>NO</th>
							<th>TAHUN AKADEMIK</th>
							<th>SEMESTER</th>
							<th>STATUS</th>
							<th>AKSI</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$no = 1;
						foreach($tahun_akademik as $tak): 
					?>

						<tr>
							<td><?= $no++; ?></td>
							<td><?= $tak->tahun_akademik; ?></td>
							<td><?= $tak->semester; ?></td>
							<td><?= $tak->status; ?></td>
							<td>
								<?= anchor('tahun_akademik/update/'.$tak->id_thn_akad, '<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></div>') ?>
								<?= anchor('tahun_akademik/delete/'.$tak->id_thn_akad, '<div onclick="return confirm(\'Yakin akan menghapus?\')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></div>') ?>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>