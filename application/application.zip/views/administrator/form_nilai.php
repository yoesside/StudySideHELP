<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<center>
					<legend><strong>MASUKKAN NILAI AKHIR</strong></legend>
					<?php
						foreach($mhspgm as $rownilai){
							$id_matkul = $rownilai->id_matkul;
						}
					?>
					<div class="container pb-5" style="font-size:15px;">
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Kode Mata Kuliah </div>
							<div class="col-sm pr-0 text-left"><?= $rownilai->kode_matakuliah; ?></div>
							<div class="col-sm text-right font-weight-bold pl-0">Dosen Pengampu</div>
							<div class="col-sm pr-0 text-left"><?= $rownilai->nama_dosen; ?></div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Kelas</div>
							<div class="col-sm pr-0 text-left"><?= $rownilai->nama_kelas; ?></div>
							<div class="col-sm text-right font-weight-bold pl-0">Nama Mata Kuliah</div>
							<div class="col-sm pr-0 text-left"><?= $rownilai->nama_matakuliah; ?></div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">SKS</div>
							<div class="col-sm pr-0 text-left"><?= $rownilai->sks; ?></div>
							<div class="col-sm text-right font-weight-bold pl-0">Tahun Akademik</div>
							<div class="col-sm pr-0 text-left"><?= $rownilai->tahun_akademik.' ('.$rownilai->jns_semester.')'; ?></div>
						</div>
					</div>
				</center>
				
				<form action="<?= base_url('nilai/simpan_nilai') ?>" method="post">
					<input type="hidden" name="id_th_akad" value="<?= $rownilai->id_thn_akad; ?>">
					<input type="hidden" name="kode_matkul" value="<?= $rownilai->kode_matakuliah; ?>">
					<input type="hidden" name="id_pengampu" value="<?= $rownilai->id_pengampu; ?>">
					<div class="table-responsive mt-3">
						<table class="table table-bordered table-striped text-dark">
							<thead class="thead-light">
								<tr>
									<th>No</th>
									<th>NIM</th>
									<th>Nama Mahasiswa</th>
									<th>Nilai Angka</th>
									<th>Bobot</th>
									<th>Nilai Huruf</th>
								</tr>
							</thead>
							<tbody>
								<?php
									$no = 1;
									foreach($mhspgm as $row): 
										$idmhs = $row->id_mhs;
										$where = array(
											'krs.id_thn_akad' => $rownilai->id_thn_akad,
											'krs.id_mhs' => $idmhs,
											'krs.id_matkul' => $id_matkul,
											'krs.semester' => $rownilai->nmsemester,
										  );
										$data['nilai'] = $this->pengampu_model->ambil_nilai($where, 'krs')->result();
										if (empty($data['nilai'])){
								?>
								<tr>
									<td><?= $no++; ?></td>
									<td><?= $row->nim; ?></td>
									<td><?= $row->nama_lengkap; ?></td>
									<td colspan='3'>
										<span class="text-danger d-flex justify-content-center">Belum Mengisi KRS</span>
									</td>
								</tr>
								<?php
										}else{
										foreach($data['nilai'] as $nilairw){
								?>
								<tr>
									<td><?= $no++; ?></td>
									<td><?= $nilairw->nim; ?></td>
									<td><?= $nilairw->nama_lengkap; ?></td>
									<input type="hidden" name="id_krs[]" value="<?= $nilairw->id_krs; ?>">
									<input type="hidden" name="sks[]" value="<?= $nilairw->sks; ?>">
									<td>
										<input type="text" name="nilai_angka[]" class="form-control" value="<?= $nilairw->nilai_angka; ?>">
									</td>
									<td>
										<?= $nilairw->bobot; ?>
									</td>
									<td>
										<?= $nilairw->nilai_huruf; ?>
									</td>
								</tr>
								<?php 
										}
									}
									endforeach; 
								?>
							</tbody>
						</table>
					</div>
					<div class="container d-flex justify-content-center pt-4">
						<button type="submit" class="btn btn-primary mr-2">Simpan</button>
						<a href="<?= base_url(); ?>nilai/input_nilai" class="btn btn-outline-secondary ml-2">Kembali</a>
					</div>
				</form>

			</div>
		</div>
	</div>
</div>