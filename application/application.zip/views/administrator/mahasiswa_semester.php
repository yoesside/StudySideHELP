<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card" style="overflow:auto;">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="h6">Ubah Semester Mahasiswa</h2>
							<a href="<?= base_url('mahasiswa') ?>" class="au-btn au-btn-icon au-btn--blue">
								<i class="fas fa-undo"></i>Kembali
							</a>
						</div>
					</div>
				</div>

				<?= $this->session->flashdata('pesan'); ?>
				<form action="<?= base_url('mahasiswa/ubahsemester_aksi') ?>" method="post">
					<div class="row justify-content-center">
						<div class="col-md-6">
							
							<?php 
								foreach($ubahsem as $sem):
							?>
							<div class="form-group">
								<label>Nama</label>
								<input type="text" class="form-control" value="<?= $sem->nama_lengkap;?>" readonly>
							</div>
							<input type="hidden" name="id_mhs" class="form-control" value="<?= $sem->id;?>" readonly>
							<div class="form-group">
								<label>NIM</label>
								<input type="text" name="nim" class="form-control" value="<?= $sem->nim;?>" readonly>							
							</div>
							<?php
								endforeach; 
							?>
							
							<div class="form-group">
								<label for="">Semester</label>
								
								<select name="semester" id="" class="form-control" required>
									<?php 
										$ceksemester = $this->mahasiswa_model->ambil_sem_mahasiswa($sem->id);
										if($ceksemester > 0){
										foreach($ceksemester as $sem){
									?>
										<option>--Pilih Semester--</option>
										<option value="1" <?php if ($sem->nm_semester == 1){echo "selected=selected";} ?>>Semester 1</option>
										<option value="2" <?php if ($sem->nm_semester == 2){echo "selected=selected";} ?>>Semester 2</option>
										<option value="3" <?php if ($sem->nm_semester == 3){echo "selected=selected";} ?>>Semester 3</option>
										<option value="4" <?php if ($sem->nm_semester == 4){echo "selected=selected";} ?>>Semester 4</option>
										<option value="5" <?php if ($sem->nm_semester == 5){echo "selected=selected";} ?>>Semester 5</option>
										<option value="6" <?php if ($sem->nm_semester == 6){echo "selected=selected";} ?>>Semester 6</option>
										<option value="7" <?php if ($sem->nm_semester == 7){echo "selected=selected";} ?>>Semester 7</option>
										<option value="8" <?php if ($sem->nm_semester == 8){echo "selected=selected";}?>>Semester 8</option>
									<?php 
										}
									}else{
									?>
										<option>--Pilih Semester--</option>
										<option value="1">Semester 1</option>
										<option value="2">Semester 2</option>
										<option value="3">Semester 3</option>
										<option value="4">Semester 4</option>
										<option value="5">Semester 5</option>
										<option value="6">Semester 6</option>
										<option value="7">Semester 7</option>
										<option value="8">Semester 8</option>
										<?php
									}
									?>
								</select>
								<?= form_error('semester', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<button type="submit" class="btn btn-primary btn-block">Simpan</button>
							<a href="<?= base_url('mahasiswa') ?>" class="btn btn-outline-secondary btn-block"><i class="fas fa-undo">&nbsp; Kembali</i></a>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>