<!DOCTYPE html>
<html lang="en">

	<head>

		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

		<!-- Title Page-->
		<title>Biodata</title>

		<!-- Fontfaces CSS-->
		<style media="print">
			body{
				font-family: Calibri, Helvetica, sans-serif;
			}
			table{
				margin-left: auto;
				margin-right: auto;
				vertical-align: top;
			}
			.kepala{
				border-collapse:collapse;
    			border-spacing:0;
				text-align:center;
				font-family: Calibri, Helvetica, sans-serif;
			}	
			.tabel{
				font-family:"Times New Roman";
				font-size:12px;
			}	
			.kanan{
				width:200px;
			}
			@page{
				margin-top: 45mm;
				header: firstpage;
			}
		</style>


	</head>
	<body>
	<htmlpageheader name="firstpage">
		<table class="kepala" cellspacing="0" style="width:700px;position:relative;">
			<tr cellspacing="0">
				<th>
					<img class="mb-2" src="<?= base_url('assets_dashboard/images/header.png') ?>" alt=""
						style="">
				</th>
			</tr>
		</table>
	</htmlpageheader>
	<sethtmlpageheader name="firstpage" value="on" show-this-page="1" />
		<table class="tabel">
			<tr>
				<th colspan="4">
					<h3>BIODATA MAHASISWA</h3>
				</th>
			</tr>
			<?php foreach($detail as $dt): ?>
			<tr>
				<th colspan="4" style="text-align:center;border:0;padding-bottom:20px;">
					<img class="mb-2" src="<?= base_url('assets_dashboard/images/icon/'.$dt->photo ) ?>" alt=""
						style="width:100px;">
				</th>
			</tr>
			<tr>
				<td>1</td>
				<td>Nama Lengkap</td>
				<td>:</td>
				<td class="kanan"><?= $dt->nama_lengkap; ?></td>
			</tr>
			<tr>
				<td>2</td>
				<td>NIM</td>
				<td>:</td>
				<td><?= $dt->nim; ?></td>
			</tr>
			<tr>
				<td>3</td>
				<td>NIK</td>
				<td>:</td>
				<td><?= $dt->nik; ?></td>
			</tr>
			<tr>
				<td>4</td>
				<td>Tempat & Tgl Lahir</td>
				<td>:</td>
				<td><?= $dt->tempat_lahir.", ".$dt->tanggal_lahir; ?></td>
			</tr>
			<tr>
				<td>5</td>
				<td>Jenis Kelamin</td>
				<td>:</td>
				<td><?= $dt->jenis_kelamin; ?></td>
			</tr>
			<tr>
				<td>6</td>
				<td>Status</td>
				<td>:</td>
				<td><?= $dt->status; ?></td>
			</tr>
			<tr>
				<td>7</td>
				<td>Agama</td>
				<td>:</td>
				<td><?= $dt->agama; ?></td>
			</tr>
			<tr>
				<td>8</td>
				<td>Alamat Tinggal</td>
				<td>:</td>
				<td><?= $dt->alamat; ?></td>
			</tr>
			<tr>
				<td>9</td>
				<td>Kode Pos</td>
				<td>:</td>
				<td><?= $dt->kode_pos; ?></td>
			</tr>
			<tr>
				<td>10</td>
				<td>No HP</td>
				<td>:</td>
				<td><?= $dt->telepon; ?></td>
			</tr>
			<tr>
				<td>11</td>
				<td>No WA</td>
				<td>:</td>
				<td><?= $dt->no_wa; ?></td>
			</tr>
			<tr>
				<td>12</td>
				<td>Email</td>
				<td>:</td>
				<td><?= $dt->email; ?></td>
			</tr>
			<tr>
				<td>13</td>
				<td>Nama Asal SMA/SMK</td>
				<td>:</td>
				<td><?= $dt->asal_sma; ?></td>
			</tr>
			<tr>
				<td>14</td>
				<td>Alamat Asal SMA/SMK</td>
				<td>:</td>
				<td><?= $dt->alamat_sma; ?></td>
			</tr>
			<tr>
				<td>15</td>
				<td>Jurusan Sewaktu SMA/SMK</td>
				<td>:</td>
				<td><?= $dt->jurusan_sma; ?></td>
			</tr>
			<tr>
				<td>16</td>
				<td>Nama Ibu</td>
				<td>:</td>
				<td><?= $dt->nama_ibu; ?></td>
			</tr>
			<tr>
				<td>17</td>
				<td>Nama Ayah</td>
				<td>:</td>
				<td><?= $dt->nama_ayah; ?></td>
			</tr>
			<tr>
				<td>18</td>
				<td>Pekerjaan Ayah</td>
				<td>:</td>
				<td><?= $dt->pekerjaan_ayah; ?></td>
			</tr>
			<tr>
				<td>19</td>
				<td>Pekerjaan Ibu</td>
				<td>:</td>
				<td><?= $dt->pekerjaan_ibu; ?></td>
			</tr>
			<tr>
				<td>20</td>
				<td>No. HP Orang Tua</td>
				<td>:</td>
				<td><?= $dt->nohp_ortu; ?></td>
			</tr>
			<tr>
				<td>21</td>
				<td>Alamat Lengkap Orang Tua</td>
				<td>:</td>
				<td><?= $dt->alamat_ortu; ?></td>
			</tr>
			<tr>
				<td>22</td>
				<td>Ukuran Jaket almamater</td>
				<td>:</td>
				<td><?= $dt->ukuran_jaket; ?></td>
			</tr>
			<tr>
				<td>23</td>
				<td>Pilihan Kampus</td>
				<td>:</td>
				<td><?= $dt->pilihan_kampus; ?></td>
			</tr>
			<tr>
				<td>24</td>
				<td>Jurusan</td>
				<td>:</td>
				<?php
					$where = array('id_prodi' => $dt->nama_prodi);
					$data['prodi']    = $this->mahasiswa_model->ambil_jenjang_prodi($where);
					foreach($data['prodi'] as $prod){ 
				?>
				<td><?= $prod->nama_prodi."-".$prod->jenjang_studi; ?></td>
				<?php	
										}
										?>
			</tr>
			<tr>
				<td>25</td>
				<td>Pilihan Kelas/Jadwal</td>
				<td>:</td>
				<td><?= $dt->pilihan_kelas; ?></td>
			</tr>

			<?php endforeach; ?>
		</table>
	</body>

</html>