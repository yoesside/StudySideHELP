<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap justify-content-center">
							<h2 class="title-5">Buat Kelas Baru</h2>
						</div>
					</div>
				</div>
				<form action="<?= base_url('kelas/tambah_kelas_aksi') ?>" method="post">
					<div class="row justify-content-center">
						<div class="col-md-6">
							<div class="form-group">
								<label for="">Nama Kelas</label>
								<input name="nama_kelas" class="form-control" value="<?php echo set_value('nama_kelas'); ?>" placeholder="Masukkan nama kelas" required>
								<?= form_error('nama_kelas', '<div class="text-danger small">', '</div>'); ?>
							</div>
							

							<button type="submit" class="btn btn-primary btn-block">Simpan</button>
							<a href="<?= base_url('kelas') ?>" class="btn btn-outline-secondary btn-block"><i class="fas fa-undo">&nbsp; Kembali</i></a>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>