<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="title-2">Pilih Program Studi untuk menampilkan data mahasiswa</h2>
						</div>
					</div>
				</div>
				<div class="account2">
                    <div class="row align-items-center">
						<?php 
							foreach($prodi as $prd): 
						?>
						<div class="col-md-auto col-sm pl-1 pr-1 pb-3" style="">
							<a href="<?= base_url('mahasiswa/prodi/'.$prd->kode_prodi) ?>" type="button" class="btn btn-outline-primary btn-block">
								<?= $prd->nama_prodi." - ".$prd->jenjang_studi; ?>
							</a>
						</div>
						<?php endforeach; ?>
                    </div>
				</div>
			</div>
		</div>
	</div>
</div>