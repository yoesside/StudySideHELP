<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="title-5">Mahasiswa</h2>
							<a href="<?= base_url('pengampu') ?>" class="btn btn-outline-primary">
								Kembali
							</a>
						</div>
					</div>
				</div>
				<?php
					foreach($mhspgmket as $rowdt){
					}
				?>
				<div class="pb-5">
					<div class="container pb-5" style="font-size:15px;">
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Semester </div>
							<div class="col-sm pr-0"><?= $rowdt->nmsemester; ?></div>
							<div class="col-sm text-right font-weight-bold pl-0">Kelas</div>
							<div class="col-sm pr-0"><?= $rowdt->nama_kelas; ?></div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Dosen Pengampu</div>
							<div class="col-sm pr-0"><?= $rowdt->nama_dosen.' ['.$rowdt->nidn.']'; ?></div>
							<div class="col-sm text-right font-weight-bold pl-0">Mata Kuliah</div>
							<div class="col-sm pr-0"><?= $rowdt->nama_matakuliah.' ['.$rowdt->kode_matakuliah.']'; ?></div>
						</div>
					</div>
					<form action="<?= base_url('pengampu/tambah_pengampumhs_aksi') ?>" method="post">
						<div class="row">
							<div class="col-md-6">
								<?php
									foreach($mhsampu as $rwmhsampu){
									}
								?>
								<input name="id_pengampu" type="hidden" value="<?=$rwmhsampu->id_pengampu;?>">
								<div class="input-group mb-3">
										<?php
										if(!empty($mhspgm)){
											$where1 = array();
											foreach($mhspgm as $key){
												$where1[] = 'id !='.$key->id_mhs;
											}
											
												$where = implode(' and ',$where1);
											}else{
												$where = 'id!= ';
											}
										?>
										<select name="id_mhs" id="" class="form-control js-example-basic-single" required>
											<option value="">-Pilih Mahasiswa-</option>
											<?php 
												$data['mhs'] = $this->pengampu_model->tampil_mahasiswa($where, 'mahasiswa')->result();
												foreach($data['mhs'] as $rwmhs)
											{ 
											?>
											<option value="<?=$rwmhs->id; ?>"><?=$rwmhs->nama_lengkap.' ['.$rwmhs->nim.']';?></option>
											<?php } ?>
										</select>
										<?= form_error('id_mhs', '<div class="text-danger small">', '</div>'); ?>
						
									<div class="input-group-append">
										<button type="submit" class="btn btn-success btn-block">
											<span class="fas fa-plus" id="basic-addon2"></span>
										</button>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
				<table class="table display" id="datatablep" style="width:100%">
					<thead>
						<tr>
							<th>NO</th>
							<th>Mahasiswa</th>
							<th>#</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$no = 1;
							foreach($mhspgm as $rowmhs): 
								$id_matkulmhs = $rowmhs->id_matkul_mhs;
								$idpengampu = $rwmhsampu->id_pengampu;
						?>
						<tr>
							<td><?= $no++; ?></td>
							<td><?= '['.$rowmhs->nim.'] '.$rowmhs->nama_lengkap; ?></td>
							<td>
								<a  onclick="return confirm('Yakin menghapus mahasiswa dari kelas?')"
									href="<?= base_url('pengampu/delete_mhs/'.$id_matkulmhs.'/'.$idpengampu) ?>" 
									class="btn btn-sm btn-outline-danger">
									<span class="fas fa-times"></span>
								</a>
							</td>
						</tr>
					</tbody>
					<?php endforeach; ?>
				</table>
			</div>
		</div>
	</div>
</div>