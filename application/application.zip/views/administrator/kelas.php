<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card" style="overflow:auto;">

				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="h6">Daftar Kelas</h2>
							<a href="<?= base_url('kelas/tambah_kelas') ?>" class="au-btn au-btn-icon au-btn--blue">
								<i class="zmdi zmdi-plus"></i>Baru
							</a>
						</div>
					</div>
				</div>

				<?= $this->session->flashdata('pesan'); ?>

				<table class="table table-hover display responsive nowrap" id="datatableku" style="width:100%">
					<thead>
						<tr>
							<th>NO</th>
							<th>Nama Kelas</th>
							<th>#</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$no = 1;
							foreach($kelas as $rowkelas): ?>
						<tr>
							<td><?= $no++; ?></td>
							<td><?= $rowkelas->nama_kelas; ?></td>
							<td>
								<?= anchor('kelas/update/'.$rowkelas->id_kelas, '<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></div>') ?>
								<?= anchor('kelas/delete/'.$rowkelas->id_kelas, '<div onclick="return confirm(\'Yakin akan menghapus?\')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></div>') ?>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>