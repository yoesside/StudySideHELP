<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card" style="overflow:auto;">

				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="h6">Daftar Dosen Pengampu</h2>
							<a href="<?= base_url('pengampu/tambah_pengampu') ?>" class="au-btn au-btn-icon au-btn--blue">
								<i class="zmdi zmdi-plus"></i>Baru
							</a>
						</div>
					</div>
				</div>

				<?= $this->session->flashdata('pesan'); ?>
					<table class="table display table-responsive" id="datatablep" style="width:100%">
						<thead>
							<tr>
								<th width="20px">NO</th>
								<th width="100px">Semester</th>
								<th width="100px">Kelas</th>
								<th width="250px">Nama</th>
								<th width="200px">Mata Kuliah</th>
								<th width="100px">Mahasiswa</th>
								<th width="100px">#</th>
							</tr>
						</thead>
						<tbody>
							<?php 
							$no = 1;
							foreach($pengampu as $rowpengampu): ?>
							<tr>
								<td><?= $no++; ?></td>
								<td><?= $rowpengampu->nmsemester; ?> [<?= $rowpengampu->tahun_akademik; ?>]</td>
								<td><?= $rowpengampu->nama_kelas; ?></td>
								<td><?= '['.$rowpengampu->nidn.'] '.$rowpengampu->nama_dosen; ?></td>
								<td><?= '['.$rowpengampu->kode_matakuliah.'] '.$rowpengampu->nama_matakuliah; ?></td>
								<td>
									<?php
										$where = array(
											'matkul_mhs.id_pengampu' => $rowpengampu->id_pengampu,
										  );
										  $data['mhspgm'] = $this->pengampu_model->mhs_ampu($where, 'matkul_mhs')->result();
										  $nojlh = 0;
										  foreach($data['mhspgm'] as $rowjlmhs){
											$nojlh++;
										  }
										  echo $nojlh;
									?>
								</td>
								<td>
									<?= anchor('pengampu/delete/'.$rowpengampu->id_pengampu, '<div onclick="return confirm(\'Yakin akan menghapus?\')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></div>') ?>
									<?= anchor('pengampu/mahasiswa/'.$rowpengampu->id_pengampu, '<div class="btn btn-sm btn-primary"><i class="fa fa-user"></i></div>') ?>
								</td>
							</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
			</div>
		</div>
	</div>
</div>