<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap justify-content-center">
							<h2 class="title-1">Edit Mahasiswa</h2>
						</div>
					</div>
				</div>

				<?php foreach($detail as $mhs): ?>
	
				<form action="<?= base_url('mahasiswa/update_mahasiswa_aksi') ?>" enctype="multipart/form-data" method="post" accept-charset="utf-8">
					<div class="row justify-content-center">
						<div class="col-md-8">

							<div class="form-row">
								<div class="form-group col-md-6">
									<label for="">NIM</label>
									<input type="hidden" id="idmhs" name="id" value="<?= $mhs->id; ?>">
									<input type="text" name="nim" class="form-control" value="<?= $mhs->nim; ?>" required>
									<?= form_error('nim', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-6">
									<label for="">NIK</label>
									<input type="text" name="nik" class="form-control" value="<?= $mhs->nik; ?>" required>
									<?= form_error('nik', '<div class="text-danger small">', '</div>'); ?>
								</div>
							</div>
							<div class="form-group">
								<label for="">Nama Mahasiswa</label>
								<input type="text" name="nama_lengkap" class="form-control" value="<?= $mhs->nama_lengkap; ?>" required>
								<?= form_error('nama_lengkap', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-row">
								<div class="form-group col-md-6">
									<label for="">Tempat Lahir</label>
									<input type="text" name="tempat_lahir" class="form-control" value="<?= $mhs->tempat_lahir; ?>" required>
									<?= form_error('tempat_lahir', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-6">
									<label for="">Tanggal Lahir</label>
									<input type="date" name="tanggal_lahir" class="form-control" value="<?= $mhs->tanggal_lahir; ?>"
										required>
									<?= form_error('tanggal_lahir', '<div class="text-danger small">', '</div>'); ?>
								</div>
							</div>
							<div class="form-row">
								<div class="form-group col-md-6">
									<label for="">Jenis Kelamin</label>
									<select name="jenis_kelamin" id="" class="form-control" value="<?= $mhs->jenis_kelamin; ?>" required>
										<option>Laki-laki</option>
										<option>Perempuan</option>
									</select>
									<?= form_error('jenis_kelamin', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-6">
									<label for="">Status</label>
									<select name="status" id="" class="form-control" required>
										<option value="">--Pilih Status--</option>
										<option value="Belum Menikah" <?php if($mhs->status == "Belum Menikah"){echo "selected=selected";} ?>>Belum Menikah
										</option>
										<option value="Menikah" <?php if($mhs->status == "Menikah"){echo "selected=selected";} ?>>Menikah</option>
										<option value="Bercerai" <?php if($mhs->status == "Bercerai"){echo "selected=selected";} ?>>Bercerai</option>
									</select>
									<?= form_error('status', '<div class="text-danger small">', '</div>'); ?>
								</div>
							</div>
							<div class="form-group">
								<label for="">Status</label>
								<select name="agama" id="" class="form-control" required>
									<option value="">--Pilih Agama--</option>
									<option value="Islam" <?php if($mhs->agama == "Islam"){echo "selected=selected";} ?>>Islam</option>
									<option value="Kristen Protestan" <?php if($mhs->agama == "Kristen Protestan"){echo "selected=selected";} ?>>Kristen
										Protestan</option>
									<option value="Kristen Katolik" <?php if($mhs->agama == "Kristen Katolik"){echo "selected=selected";} ?>>Kristen Katolik
									</option>
									<option value="Hindu" <?php if($mhs->agama == "Hindu"){echo "selected=selected";} ?>>Hindu</option>
									<option value="Buddha" <?php if($mhs->agama == "Buddha"){echo "selected=selected";} ?>>Buddha</option>
									<option value="Khonghucu" <?php if($mhs->agama == "Khonghucu"){echo "selected=selected";} ?>>Khonghucu</option>
								</select>
								<?= form_error('agama', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Alamat Tinggal</label>
								<input type="text" name="alamat" class="form-control" value="<?= $mhs->alamat; ?>" required>
								<?= form_error('alamat', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-row">
								<div class="form-group col-md-6">
									<label for="">Kode Pos</label>
									<input type="text" name="kode_pos" class="form-control" value="<?= $mhs->kode_pos; ?>" required>
									<?= form_error('kode_pos', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-6">
									<label for="">NO HP</label>
									<input type="text" name="telepon" class="form-control" value="<?= $mhs->telepon; ?>" required>
									<?= form_error('telepon', '<div class="text-danger small">', '</div>'); ?>
								</div>
							</div>
							<div class="form-row">
								<div class="form-group col-md-6">
									<label for="">No WA</label>
									<input type="text" name="no_wa" class="form-control" value="<?= $mhs->no_wa; ?>" required>
									<?= form_error('no_wa', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-6">
									<label for="">Email</label>
									<input type="text" name="email" class="form-control" value="<?= $mhs->email; ?>" required>
									<?= form_error('email', '<div class="text-danger small">', '</div>'); ?>
								</div>
							</div>
							<div class="form-row">
								<div class="form-group col-md-6">
									<label for="">Asal SMA/SMK</label>
									<input type="text" name="asal_sma" class="form-control" value="<?= $mhs->asal_sma; ?>" required>
									<?= form_error('asal_sma', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-6">
									<label for="">Jurusan SMA/SMK</label>
									<input type="text" name="jurusan_sma" class="form-control" value="<?= $mhs->jurusan_sma; ?>" required>
									<?= form_error('jurusan_sma', '<div class="text-danger small">', '</div>'); ?>
								</div>
							</div>
							<div class="form-group">
								<label for="">Alamat SMA/SMK</label>
								<input type="text" name="alamat_sma" class="form-control" value="<?= $mhs->alamat_sma; ?>" required>
								<?= form_error('alamat_sma', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Nama Ibu</label>
								<input type="text" name="nama_ibu" class="form-control" value="<?= $mhs->nama_ibu; ?>" required>
								<?= form_error('nama_ibu', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Nama Ayah</label>
								<input type="text" name="nama_ayah" class="form-control" value="<?= $mhs->nama_ayah; ?>" required>
								<?= form_error('nama_ayah', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-row">
								<div class="form-group col-md-4">
									<label for="">Pekerjaan Ayah</label>
									<input type="text" name="pekerjaan_ayah" class="form-control"
										value="<?= $mhs->pekerjaan_ayah; ?>" required>
									<?= form_error('pekerjaan_ayah', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-4">
									<label for="">Pekerjaan Ibu</label>
									<input type="text" name="pekerjaan_ibu" class="form-control"
										value="<?= $mhs->pekerjaan_ibu; ?>" required>
									<?= form_error('pekerjaan_ibu', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-4">
									<label for="">No HP Orang Tua</label>
									<input type="text" name="nohp_ortu" class="form-control" value="<?= $mhs->nohp_ortu; ?>" required>
									<?= form_error('nohp_ortu', '<div class="text-danger small">', '</div>'); ?>
								</div>
							</div>
							<div class="form-group">
								<label for="">Alamat Orang Tua</label>
								<input type="text" name="alamat_ortu" class="form-control" value="<?= $mhs->alamat_ortu; ?>" required>
								<?= form_error('alamat_ortu', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-row">
								<div class="form-group col-md-6">
									<label for="">Ukuran Jaket Almamater</label>
									<input type="text" name="ukuran_jaket" class="form-control"
										value="<?= $mhs->ukuran_jaket; ?>" required>
									<?= form_error('ukuran_jaket', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-6">
									<label for="">Pilihan Kampus</label>
									<input type="text" name="pilihan_kampus" class="form-control"
										value="<?= $mhs->pilihan_kampus; ?>" required>
									<?= form_error('pilihan_kampus', '<div class="text-danger small">', '</div>'); ?>
								</div>
							</div>
							<div class="form-row">
								<div class="form-group col-md-6">
									<label for="">Jenjang Studi</label>
									<select name="jenjang_studi" id="mahasiswa_jenjang_up" class="form-control" required>
										<option value="0">--Pilih Jenjang Studi--</option>
										<?php 
										$data['jenj'] = $this->mahasiswa_model->tampil_data('jenjang')->result();
										foreach($data['jenj'] as $jenjang_s): 
									?>
										<option value="<?= $jenjang_s->jenjang_studi; ?>"
											<?php if($jenjang_s->jenjang_studi == $mhs->jenjang_studi){echo "selected=selected";} ?>>
											<?= $jenjang_s->jenjang_studi; ?>
										</option>
										<?php endforeach; ?>
									</select>
									<?= form_error('jenis_kelamin', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-6">
									<label for="">Program Studi</label>
									<select name="nama_prodi" id="mahasiswa_prodi_up" class="form-control" required>
										<option>--Pilih Program Studi--</option>
									</select>
									<?= form_error('nama_prodi', '<div class="text-danger small">', '</div>'); ?>
								</div>
							</div>
							<div class="form-group">
								<label for="">Dosen Wali</label>
								<select name="dosen" id="" class="form-control js-example-basic-single">
									<option value="">--Pilih Dosen Wali--</option>
									<?php 
										$data['dosen'] = $this->prodi_model->tampil_data('dosen')->result();
										foreach($data['dosen'] as $dosen)
										{ 
									?>
									<option value="<?=$dosen->id_dosen; ?>" <?php if($dosen->id_dosen == $mhs->dosen_wali){echo 'selected=selected';} ?>>
										<?=$dosen->nama_dosen;?></option>
									<?php } ?>
								</select>
								<?= form_error('dosen', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Pilihan Kelas/Jadwal</label>
								<input type="text" name="pilihan_kelas" class="form-control"
									value="<?= $mhs->pilihan_kelas; ?>" required>
								<?= form_error('pilihan_kelas', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<?php foreach($detail as $dt): ?>
								<img src="<?= base_url('assets_dashboard/images/icon/').$mhs->photo; ?>" style="width:20%;">
								<?php endforeach; ?><br><br>
								<label for="">Foto</label><br>
								<input class="d-none" name="gbrmhs1" value="<?= $mhs->photo; ?>">
								<input type="file" name="gambarmhs">
							</div>
							<button type="submit" class="btn btn-primary btn-block">Simpan</button>
							<a href="<?= base_url('mahasiswa') ?>" class="btn btn-outline-secondary btn-block"><i class="fas fa-undo">&nbsp; Kembali</i></a>

						</div>
					</div>

				</form>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</div>