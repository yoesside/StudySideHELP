<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
			<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap justify-content-center">
							<h2 class="title-5">Edit jadwal pengisian KRS</h2>
						</div>
					</div>
				</div>

				<?php foreach($tahun_akademik as $tak): ?>
				<form action="<?= base_url('tahun_akademik/update_aksi') ?>" method="post">
					<div class="row justify-content-center">
						<div class="col-md-6">
							<div class="form-row">
								<div class="form-group col-md-5">
									<label for="">Tanggal awal</label>
									<input type="date" name="jadwal_awal" class="form-control" value="<?= $tak->jadwal_awal_krs; ?>" required>
									<?= form_error('jadwal_awal', '<div class="text-danger small">', '</div>'); ?>
								</div>
								<div class="form-group col-md-2">
									<label for="">&nbsp;</label>
									<div clas="justify-content-center h4" style="text-align:center">s/d</div>
								</div>
								<div class="form-group col-md-5">
									<label for="">Tanggal akhir</label>
									<input type="date" name="jadwal_akhir" class="form-control"
										value="<?= $tak->jadwal_akhir_krs; ?>" required>
									<?= form_error('jadwal_akhir', '<div class="text-danger small">', '</div>'); ?>
								</div>
							</div>
							<div class="form-group">
								<label for="">Tahun Akademik</label>
								<input type="hidden" name="id_thn_akad" value="<?= $tak->id_thn_akad; ?>" class="form-control">
								<input type="text" name="tahun_akademik" placeholder="Masukkan tahun akademik" class="form-control"
									value="<?= $tak->tahun_akademik; ?>" required>
								<?= form_error('tahun_akademik', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Semester</label>
								<select name="semester" id="" class="form-control" value="<?= $tak->jns_semester; ?>" required>
									<option value="Ganjil" <?php if($tak->jns_semester == "Ganjil"){echo "selected=selected";} ?>>Ganjil</option>
									<option value="Genap" <?php if($tak->jns_semester == "Genap"){echo "selected=selected";} ?>>Genap</option>
								</select>
								<?= form_error('semester', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Status</label>
								<select name="status" id="" class="form-control" required>
									<option value="Aktif" <?php if($tak->status == "Aktif"){echo "selected=selected";} ?>>Aktif</option>
									<option value="Tidak Aktif" <?php if($tak->status == NULL){echo "selected=selected";} ?>>Tidak Aktif</option>
								</select>
								<?= form_error('status', '<div class="text-danger small">', '</div>'); ?>
							</div>

							<button type="submit" class="btn btn-primary btn-block">Simpan</button>
							<a href="<?= base_url('krs') ?>" class="btn btn-outline-secondary btn-block"><i class="fas fa-undo">&nbsp; Kembali</i></a>
						</div>
					</div>
				</form>

				<?php endforeach; ?>
			</div>
		</div>
	</div>
</div>