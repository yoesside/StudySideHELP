<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card" style="overflow:auto;">

				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="h6">Daftar Dosen</h2>
							<a href="<?= base_url('dosen/tambah_dosen') ?>" class="au-btn au-btn-icon au-btn--blue">
								<i class="zmdi zmdi-plus"></i>Tambah Dosen
							</a>
						</div>
					</div>
				</div>

				<?= $this->session->flashdata('pesan'); ?>

				<div class='alert alert-warning mt-3'>
					Untuk menambahkan dosen sebagai user, silahkan di klik menu jadikan user melalui
					tanda titi tiga pada kolom tindakan dari mahasiswa yang bersangkutan
				</div>

				<table class="table table-hover display responsive nowrap" id="datatableku" style="width:100%">
					<thead>
						<tr>
							<th>NO</th>
							<th>NIDN</th>
							<th>Nama</th>
							<th>Alamat</th>
							<th>Email</th>
							<th>Tindakan</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$no = 1;
							foreach($dosen as $dsn): ?>
						<tr>
							<td><?= $no++; ?></td>
							<td><?= $dsn->nidn; ?></td>
							<td><?= $dsn->nama_dosen; ?></td>
							<td><?= $dsn->alamat; ?></td>
							<td><?= $dsn->email; ?></td>
							<td>
								<div class="dropdown">
									<a class="btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
										aria-expanded="false">
										<i class="fas fa-ellipsis-v"></i>
									</a>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
										<a class="dropdown-item" href="<?= base_url('dosen/detail/'.$dsn->id_dosen) ?>">Detail</a>
										<a class="dropdown-item" href="<?= base_url('dosen/update/'.$dsn->id_dosen) ?>">Edit</a>
										<a class="dropdown-item" onclick="return confirm('Yakin akan menghapus?')"
											href="<?= base_url('mahasiswa/delete/'.$dsn->nidn) ?>">Hapus</a>
										<?php 
												if($dsn->status_user == "Sudah"){
													echo "";
												}else{
											?>
										<a class="dropdown-item" onclick="return confirm('Yakin jadikan sebagi user?')"
											href="<?= base_url('dosen/jadi_user/'.$dsn->id_dosen) ?>">Jadikan User</a>
										<?php
												}
											?>
									</div>
								</div>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>