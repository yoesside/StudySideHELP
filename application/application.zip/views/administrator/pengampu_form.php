<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap justify-content-center">
							<h2 class="title-5">Buat Pengampu Baru</h2>
						</div>
					</div>
				</div>
				<form action="<?= base_url('pengampu/tambah_pengampu_aksi') ?>" method="post">
					<div class="row justify-content-center">
						<div class="col-md-6">
							<div class="form-group">
								<label for="">Tahun Akademik</label>
								<select name="id_thn_akad" id="" class="form-control js-example-basic-single" required>
									<option>-Pilih Tahun Akademik-</option>
									<?php 
										$data['thn_akad'] = $this->pengampu_model->tampil_thn_akad('tahun_akademik')->result();
										foreach($data['thn_akad'] as $rwthn_akad)
										{ 
									?>
									<option value="<?=$rwthn_akad->id_thn_akad; ?>">
										<?=$rwthn_akad->tahun_akademik.' ['.$rwthn_akad->jns_semester.']';?>
									</option>
									<?php } ?>
								</select>
								<?= form_error('id_thn_akad', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Semester</label>
								<select name="semester" id="" class="form-control js-example-basic-single" required>
									<option value="">-Pilih Semester-</option>
									<option value="1">Semester 1</option>
									<option value="2">Semester 2</option>
									<option value="3">Semester 3</option>
									<option value="4">Semester 4</option>
									<option value="5">Semester 5</option>
									<option value="6">Semester 6</option>
									<option value="7">Semester 7</option>
									<option value="8">Semester 8</option>
								</select>
								<?= form_error('semester', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Kelas</label>
								<select name="id_kelas" id="" class="form-control js-example-basic-single" required>
									<option value="">-Pilih Kelas-</option>
									<?php 
										$data['kelas'] = $this->pengampu_model->tampil_kelas('kelas')->result();
										foreach($data['kelas'] as $rwkelas)
										{ 
									?>
									<option value="<?=$rwkelas->id_kelas; ?>"><?=$rwkelas->nama_kelas;?></option>
									<?php } ?>
								</select>
								<?= form_error('id_kelas', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Dosen</label>
								<select name="id_dosen" id="" class="form-control js-example-basic-single" required>
									<option value="">-Pilih Dosen-</option>
									<?php 
										$data['dosen'] = $this->pengampu_model->tampil_dosen('dosen')->result();
										foreach($data['dosen'] as $rwdosen)
										{ 
									?>
									<option value="<?=$rwdosen->id_dosen; ?>"><?=$rwdosen->nama_dosen;?></option>
									<?php } ?>
								</select>
								<?= form_error('id_dosen', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Mata Kuliah</label>
								<select name="id_matkul" id="" class="form-control js-example-basic-single" required>
									<option value="">-Pilih Mata Kuliah-</option>
									<?php 
										$data['matkul'] = $this->pengampu_model->tampil_matkul('matakuliah')->result();
										foreach($data['matkul'] as $rwmatkul)
										{ 
									?>
									<option value="<?=$rwmatkul->id_matkul; ?>">
										<?='('.$rwmatkul->kode_matakuliah.') '.$rwmatkul->nama_matakuliah.' [Semester '.$rwmatkul->semester.']';?>
									</option>
									<?php } ?>
								</select>
								<?= form_error('id_matkul', '<div class="text-danger small">', '</div>'); ?>
							</div>
							

							<button type="submit" class="btn btn-primary btn-block">Simpan</button>
							<a href="<?= base_url('pengampu') ?>" class="btn btn-outline-secondary btn-block"><i class="fas fa-undo">&nbsp; Kembali</i></a>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>