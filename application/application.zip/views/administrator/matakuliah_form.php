<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="title-1">Tambah Mata Kuliah</h2>
						</div>
					</div>
				</div>

				<form action="<?= base_url('matakuliah/tambah_matakuliah_aksi') ?>" method="post">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="">Kode Mata Kuliah</label>
								<input type="text" name="kode_matakuliah" class="form-control" value="<?php echo set_value('kode_matakuliah'); ?>">
								<?= form_error('kode_matakuliah', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Nama Mata Kuliah</label>
								<input type="text" name="nama_matakuliah" class="form-control">
								<?= form_error('nama_matakuliah', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">SKS</label>
								<select name="sks" id="" class="form-control">
									<option>1</option>
									<option>2</option>
									<option>3</option>
									<option>4</option>
									<option>5</option>
									<option>6</option>
								</select>
								<?= form_error('sks', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Semester</label>
								<select name="semester" id="" class="form-control">
									<option>1</option>
									<option>2</option>
									<option>3</option>
									<option>4</option>
									<option>5</option>
									<option>6</option>
									<option>7</option>
									<option>8</option>
								</select>
								<?= form_error('semester', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Jenis Semester</label>
								<select name="jns_semester" id="" class="form-control">
									<option>Ganjil</option>
									<option>Genap</option>
								</select>
								<?= form_error('jns_semester', '<div class="text-danger small">', '</div>'); ?>
							</div>
							<div class="form-group">
								<label for="">Program Studi</label>
								<select name="nama_prodi" id="" class="form-control">
									<option value="">--Pilih Program Studi--</option>
									<?php foreach($prodi as $prd): ?>
									<option value="<?= $prd->id_prodi; ?>"><?= $prd->nama_prodi."-".$prd->jenjang_studi; ?></option>
									<?php endforeach; ?>
								</select>
								<?= form_error('nama_prodi', '<div class="text-danger small">', '</div>'); ?>
							</div>

							<button type="submit" class="btn btn-primary mb-4">Simpan</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>