<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card" style="overflow:auto;">
				<div class="row pb-4">
					<div class="col-md-12">
						<div class="overview-wrap">
							<h2 class="title-1">Program Studi</h2>
							<a href="<?= base_url('prodi/tambah_prodi') ?>" class="au-btn au-btn-icon au-btn--blue">
								<i class="zmdi zmdi-plus"></i>Tambah Prodi
							</a>
						</div>
					</div>
				</div>

				<?= $this->session->flashdata('pesan'); ?>
				<table class="table table-hover display responsive nowrap" id="datatableku" style="width:100%">
					<thead>
						<tr>
							<th>NO</th>
							<th>KODE PRODI</th>
							<th>NAMA PRODI</th>
							<th>Jenjang Studi</th>
							<th>AKSI</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$no = 1;
							foreach($prodi as $prd): 
						?>
						<tr>
							<td width="20px;"><?= $no++; ?></td>
							<td><?= $prd->kode_prodi; ?></td>
							<td><?= $prd->nama_prodi; ?></td>
							<td><?= $prd->jenjang_studi; ?></td>
							<td>
								<?= anchor('prodi/update/'.$prd->id_prodi, '<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></div>') ?>
								<?= anchor('prodi/delete/'.$prd->id_prodi, '<div onclick="return confirm(\'Yakin akan menghapus?\')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></div>') ?>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>