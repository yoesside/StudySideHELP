<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="account2">
					<h3>
						Pilih Level User
					</h3>
                    <div class="row mt-4">
                        <a href="<?= base_url('mahasiswa') ?>" type="button" class="btn btn-outline-primary btn-lg mr-3">
                            <i class="fas fa-graduation-cap fa-2x"></i><br> Mahasiswa
                        </a>
                        <a href="<?= base_url('users/tambah_users') ?>" type="button" class="btn btn-outline-primary btn-lg ml-3">
                            <i class="fas fa-user fa-2x"></i><br> Administrator
                        </a>
                        <a href="<?= base_url('dosen') ?>" type="button" class="btn btn-outline-primary btn-lg ml-3">
                            <i class="far fa-user fa-2x"></i><br> Dosen
                        </a>
                    </div>
				</div>
			</div>
		</div>
	</div>
</div>