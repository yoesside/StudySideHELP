<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="alert alert-success" role="alert">
					<i class="fas fa-university"></i> Form Masuk Halaman Input Nilai
				</div>

				<table class="table display" id="datatablep" style="width:100%">
					<thead>
						<tr>
							<th width="20px">NO</th>
							<th width="100px">Semester</th>
							<th width="100px">Kelas</th>
							<th width="200px">Mata Kuliah</th>
							<th width="100px">#</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$no = 1;
							foreach($mtkulampu as $rowpengampu): ?>
						<tr>
							<td><?= $no++; ?></td>
							<td><?= $rowpengampu->nmsemester; ?> [<?= $rowpengampu->tahun_akademik; ?>]</td>
							<td><?= $rowpengampu->nama_kelas; ?></td>
							<td><?= '['.$rowpengampu->kode_matakuliah.'] '.$rowpengampu->nama_matakuliah; ?></td>
							<td>
								<a class="btn btn-outline-success" href="<?= base_url('Nilai_dsn/isi_nilai/'.$rowpengampu->id_pengampu) ?>" data-toggle="tooltip" data-placement="top" title="Input Nilai">
									<span class="fas fa-book"></span>
								</a>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>