<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card" style="overflow:auto;">
				<div class="row pb-5">
					<div class="col-md-12 row">
						<?php
							$id_dsn = $this->session->userdata('id_dosen');
							$data['detail'] = $this->dosen_model->ambil_id_dosen($id_dsn);
							foreach ($data['detail'] as $rowdt){
								$id_dsn = $rowdt->id_dosen ;
							}
						?>
						<div class="container p-0 col">
							<span class="fas fa-outdent"></span>
							<span class="title-8 ml-2 font-weight-bold">Profile Dosen</span>
						</div>
					</div>
				</div>

				<div class="container pb-5" style="font-size:15px;">
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">NIDN</div>
						<div class="col-sm pr-0"><?= $rowdt->nidn ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Nama</div>
						<div class="col-sm pr-0"><?= $rowdt->nama_dosen; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Alamat</div>
						<div class="col-sm pr-0"><?= $rowdt->alamat; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Jenis Kelamin</div>
						<div class="col-sm pr-0"><?= $rowdt->jenis_kelamin; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Email</div>
						<div class="col-sm pr-0"><?= $rowdt->email; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">No HP</div>
						<div class="col-sm pr-0"><?= $rowdt->telp; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Email</div>
						<div class="col-sm pr-0">
							<img class="mb-2" src="<?= base_url('assets/uploads/').$rowdt->photo; ?>" alt=""
								style="width:50%;">
						</div>
					</div>
				</div>
				<div class="d-flex justify-content-center">
					<a href="<?= base_url('dosen/edit_profil_dsn') ?>" class="btn btn-primary">Ubah</a>
				</div>
			</div>
		</div>
	</div>
</div>