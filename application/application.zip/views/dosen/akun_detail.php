<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="account2">
					<h3>
						Ubah Password
					</h3>

					<form class="modern-form" action="<?= base_url('akun/update_akun_dsn') ?>" enctype="multipart/form-data" method="post" accept-charset="utf-8">
						<?php foreach($detail as $dtuser): ?>
						<div class="account2 pb-5" style="border-bottom:none;">
							<div class="image img-cir" style="width:150px;">
								<img style="width:100%;"
									src="<?= base_url('assets_dashboard/images/icon/').$dtuser->gambar ?>"
									alt="<?= $dtuser->nama; ?>" />
							</div>
						</div>
						<div class="form-group form-design d-none">
							<input name="id_user" value="<?= $this->session->userdata('id_user') ?>" type="text" class="form-control">
						</div>
						<div class="form-group form-design">
							<input name="username" id="disabledTextInput" value="<?= $dtuser->username; ?>" type="text" class="form-input" 
								placeholder="Username" disabled>
							<span>Username</span>
						</div>
						<div class="form-group form-design">
                            <input value="<?= $this->session->userdata('password') ?>" type="password" class="form-input form-password" 
								name="password" id="password" placeholder="Kata Sandi"/>
                            <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>
                        </div>

						<div class="pb-4"></div>
						<div class="form-group">
							<input type="submit" name="submit" id="submit" value="Simpan"/>
						</div>
						<?php endforeach; ?>
					</form>

                </div>
			</div>
		</div>
	</div>
</div>