<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
		
				<div class="au-breadcrumb-content">
					<div class="au-breadcrumb-left">
						<span class="au-breadcrumb-span">Anda berada di:</span>
						<ul class="list-unstyled list-inline au-breadcrumb__list">
							<li class="list-inline-item active">
								<a href="#">Home</a>
							</li>
							<li class="list-inline-item seprate">
								<span>/</span>
							</li>
							<li class="list-inline-item">Dashboard</li>
						</ul>
					</div>
				</div>

				<div class="alert alert-light pt-5 pl-0" role="alert">
					<h4 class="alert-heading">Selamat Datang!</h4>
					<?php
						$data['dosen']    = $this->dosen_model->ambil_id_dosen($id_dosen);
						foreach($data['dosen'] as $rowdsn){
							$nama_dosen = $rowdsn->nama_dosen;
						}
					?>
					<p>Selamat datang <strong><?= $nama_dosen; ?></strong> di Sistem Informasi Akademik ITBI Kampus Milenial, anda
						login
						sebagai
						<strong><?= $level; ?></strong></p>
					<hr>
					<!-- Button trigger modal -->
				</div>

				<!-- Modal -->
			</div>
		</div>
	</div>
</div>