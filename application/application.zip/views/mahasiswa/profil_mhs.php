<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card" style="overflow:auto;">
				<div class="row pb-5">
					<div class="col-md-12 row">
						<?php
							$idmhs = $this->session->userdata('id_mhs');
							$data['detail'] = $this->mahasiswa_model->ambil_id_mahasiswa($idmhs);
							foreach ($data['detail'] as $rowdt){
								$id_mhs = $rowdt->id ;
							}
						?>
						<div class="container p-0 col">
							<span class="fas fa-outdent"></span>
							<span class="title-8 ml-2 font-weight-bold">Profile Mahasiswa</span>
						</div>
						<div class="col">
							<div class="overview-wrap d-flex flex-row-reverse bd-highlight">
								<div class="dropdown">
									<button class="btn btn-primary btn-sm dropdown-toggle" type="button"
										id="dropdownMenuButton" data-toggle="dropdown" data-boundary="viewport"
										aria-haspopup="true" aria-expanded="false">
										<i class="fas fa-print"></i>&nbsp; Cetak Biodata
									</button>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
										<a class="dropdown-item" href="<?= base_url('mahasiswa/cetakDetailPdf/'.$id_mhs) ?>"target="_blank">PDF</a>
										<a class="dropdown-item" href="<?= base_url('mahasiswa/cetakWord/'.$id_mhs) ?>" target="_blank">Docx</a>
										<a class="dropdown-item" href="<?= base_url('mahasiswa/cetakXlsx/'.$id_mhs) ?>" target="_blank">Xlsx</a>
										<a class="dropdown-item" href="<?= base_url('mahasiswa/Biodatahtml/'.$id_mhs) ?>" target="_blank">HTML</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="container pb-5" style="font-size:15px;">
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">NIM </div>
						<div class="col-sm pr-0"><?= $rowdt->nim; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Nama</div>
						<div class="col-sm pr-0"><?= $rowdt->nama_lengkap; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">NIK</div>
						<div class="col-sm pr-0"><?= $rowdt->nik; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Tempat Lahir</div>
						<div class="col-sm pr-0"><?= $rowdt->tempat_lahir; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Tanggal Lahir</div>
						<div class="col-sm pr-0"><?= $rowdt->tanggal_lahir; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Jenis Kelamin</div>
						<div class="col-sm pr-0"><?= $rowdt->jenis_kelamin; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Agama</div>
						<div class="col-sm pr-0"><?= $rowdt->agama; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Alamat Tinggal</div>
						<div class="col-sm pr-0"><?= $rowdt->alamat; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Kode Pos</div>
						<div class="col-sm pr-0"><?= $rowdt->kode_pos; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">No HP</div>
						<div class="col-sm pr-0"><?= $rowdt->telepon; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold pl-0">No WA</div>
						<div class="col-sm pr-0"><?= $rowdt->no_wa; ?></div>
						<div class="col-sm text-right font-weight-bold">Foto</div>
						<div class="col-sm pr-0">
							<img class="mb-2" src="<?= base_url('assets_dashboard/images/icon/').$rowdt->photo; ?>" alt=""
								style="width:50%;">
						</div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Email</div>
						<div class="col-sm pr-0"><?= $rowdt->email; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Nama Asal SMA/SMK</div>
						<div class="col-sm pr-0"><?= $rowdt->asal_sma; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Alamat Asal SMA/SMK</div>
						<div class="col-sm pr-0"><?= $rowdt->alamat_sma; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Jurusan Sewaktu SMA/SMK</div>
						<div class="col-sm pr-0"><?= $rowdt->jurusan_sma; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Nama Ibu </div>
						<div class="col-sm pr-0"><?= $rowdt->nama_ibu; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Nama Ayah </div>
						<div class="col-sm pr-0"><?= $rowdt->nama_ayah; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Pekerjaan Ayah</div>
						<div class="col-sm pr-0"><?= $rowdt->pekerjaan_ayah; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Pekerjaan Ibu</div>
						<div class="col-sm pr-0"><?= $rowdt->pekerjaan_ibu; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">No. HP Orang Tua</div>
						<div class="col-sm pr-0"><?= $rowdt->nohp_ortu; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Alamat Lengkap Orang Tua</div>
						<div class="col-sm pr-0"><?= $rowdt->alamat_ortu; ?></div>
					</div>
					<?php
						$where = array('id_prodi' => $rowdt->nama_prodi);
						$data['prodi']    = $this->mahasiswa_model->ambil_jenjang_prodi($where);
						foreach($data['prodi'] as $prod){ 
							$prodi = $prod->nama_prodi;
							$jenjang = $prod->jenjang_studi;
						}
					?>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Jurusan</div>
						<div class="col-sm pr-0"><?= $prodi; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Jenjang Pendidikan</div>
						<div class="col-sm pr-0"><?= $jenjang; ?></div>
					</div>
				</div>
				<div class="d-flex justify-content-center">
					<a href="<?= base_url('mahasiswa/edit_profil_mhs') ?>" class="btn btn-primary">Ubah</a>
				</div>
			</div>
		</div>
	</div>
</div>