<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="row">
				<div class="col-md-12">
					<div class="overview-wrap">
						<h2 class="title-1">Dashboard</h2>
					</div>
				</div>
			</div>
			<?php
				$idmhs = $this->session->userdata('id_mhs'); 
				foreach($getmhs as $rowmhs){
					$idmhs			= $rowmhs->id;
					$semester_mhs	= $rowmhs->nm_semester;
					$status_uangkul	= $rowmhs->status_uang_kuliah;
				}
			?>
			<div class="row m-t-25">
				<div class="col-lg">
					<div class="au-card recent-report">
						<div class="au-card-inner">
							<div class="row justify-content-between">
								<div class="col-sm-7">
									<h5 class="title-2">Kemajuan Studi</h5>
								</div>
								<div class="col-sm-5">
									<div class="dropdown">
										<button class="btn btn-danger btn-sm dropdown-toggle" type="button" id="dropdownMenuButton"
											data-toggle="dropdown" data-boundary="viewport" aria-haspopup="true" aria-expanded="false">
											<i class="fas fa-print"></i>&nbsp; Cetak KHS Full
										</button>
										<div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="min-width:100px;">
											<a class="dropdown-item" href="<?= base_url('khs/cetakKHSSemuaPdf/'.$idmhs) ?>"
												target="_blank">PDF</a>
										</div>
									</div>
								</div>
							</div>
							<div class="chart-info mt-4">
								<div class="chart-info__left p-3 bg-secondary rounded-circle">
									<span class="fas fa-trophy fa-3x text-white"></span>
								</div>
								<div class="chart-info__right">
								<?php
									foreach($getjlhipk1 as $rowjumlah1){
										$jumlahnilai_akhir1 = $rowjumlah1->jumlahn;
									}
									foreach($getjlhipk2 as $rowjumlah2){
										$jumlahnilai_akhir2 = $rowjumlah2->jumlahsks;
									}
								?>
									<span class="text-success h1 font-weight-bold">
										<?php 
											if(!empty($jumlahnilai_akhir1) and !empty($jumlahnilai_akhir2)){
												echo number_format($jumlahnilai_akhir1/$jumlahnilai_akhir2, 2); 
											}
										?>
									</span>
									<div class="font-weight-bold">IPK</div>
								</div>
							</div>
							<div>
								<div class="table-responsive">
									<table class="table">
										<thead>
											<tr class="table-primary">
												<th scope="col">Semester</th>
												<th scope="col">IP Semester</th>
												<th scope="col">Cetak</th>
											</tr>
										</thead>
										<tbody>
											<?php
												foreach($group as $groupkhs){
													$wherekhs = array(
														'krs.semester' => $groupkhs->semester,
														'krs.id_mhs'   => $groupkhs->id_mhs
													);
													$khssem = $groupkhs->semester;
													$data['jumlahnilai'] = $this->transkrip_model->jumlah_nilai_akhir($idmhs, $khssem)->result();
													foreach($data['jumlahnilai'] as $rowjumlah){
														$jumlahnilai_akhir = $rowjumlah->jumlah;
													}
													$data['jumlahskssm'] = $this->transkrip_model->jumlah_sks_sem($idmhs, $khssem)->result();
													foreach($data['jumlahskssm'] as $rowsksjlh){
														$skslhsem = $rowsksjlh->jumlah_sks;
											?>
											<tr>
												<td><?= $groupkhs->semester; ?></td>
												<td>
												<?php 
													if($groupkhs->semester == $semester_mhs and $status_uangkul == 'Izin'){
														echo 'Uang kuliah belum lunas';
													}else{
														echo number_format($jumlahnilai_akhir/$skslhsem, 2); 
													}
												?>
												</td>
												<td>
												<?php 
													if($groupkhs->semester == $semester_mhs and $status_uangkul == 'Izin'){
														echo 'Uang kuliah belum lunas';
													}else{
												?>

												<div class="dropdown">
													<button class="btn btn-success btn-sm dropdown-toggle" type="button" id="dropdownMenuButton"
														data-toggle="dropdown" data-boundary="viewport" aria-haspopup="true" aria-expanded="false">
														<i class="fas fa-print"></i>&nbsp; Cetak KHS
													</button>
													<div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="min-width:100px;">
														<a class="dropdown-item" href="<?= base_url('khs/cetakKHSPdf/'.$idmhs.'/'.$khssem) ?>"
															target="_blank">PDF</a>
														<a class="dropdown-item" href="<?= base_url('khs/cetakWordKHS/'.$idmhs.'/'.$khssem) ?>"
															target="_blank">Docx</a>
														<a class="dropdown-item" href="<?= base_url('khs/cetakKHSXlsx/'.$idmhs.'/'.$khssem) ?>"
															target="_blank">Xlsx</a>
														<a class="dropdown-item" href="<?= base_url('khs/cetakKHSHTML/'.$idmhs.'/'.$khssem) ?>"
															target="_blank">HTML</a>
													</div>
												</div>

												<?php
													}
												?>
												</td>
											</tr>
											<?php
													}
												}
											?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg">
					<div class="au-card recent-report">
						<div class="au-card-inner">
							<h3 class="title-2">Histori KRS</h3>
							<div class="chart-info mt-4">
								<div class="chart-info__left p-3 bg-secondary rounded-circle">
									<span class="fas fa-pencil-square-o fa-3x text-white"></span>
								</div>
								<div class="chart-info__right">
									<?php
										foreach($getjlhipk2 as $rowjlhsks){
											$jlhsks = $rowjlhsks->jumlahsks;
										}
									?>
									<span class="text-success h1 font-weight-bold">
										<?= $jlhsks; ?>
									</span>
									<div class="font-weight-bold">Total SKS</div>
								</div>
							</div>
							<div>
								<div class="table-responsive">
									<table class="table">
										<thead>
											<tr class="table-primary">
												<th scope="col">Semester</th>
												<th scope="col">Total SKS</th>
												<th scope="col">Cetak</th>
											</tr>
										</thead>
										<tbody>
											<?php
												foreach($group as $rowgroup){
													$semester = $rowgroup->semester;
													$data['jumlahsks'] = $this->transkrip_model->jumlah_sks_sem($idmhs, $semester)->result();
													foreach($data['jumlahsks'] as $rowjlhsks){
														$jlhsks = $rowjlhsks->jumlah_sks;
													}
											?>
											<tr>
												<td><?= $rowgroup->semester; ?></td>
												<td><?= $jlhsks; ?></td>
												<td>
													<div class="dropdown">
														<button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton"
															data-toggle="dropdown"  data-boundary="viewport" aria-haspopup="true" aria-expanded="false">
															<i class="fas fa-print"></i>&nbsp; Cetak KRS
														</button>
														<div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="min-width:100px;">
															<a class="dropdown-item" href="<?= base_url('krs_mhs/cetakKrsPdf/'.$idmhs.'/'.$semester) ?>"
																target="_blank">PDF</a>
															<a class="dropdown-item" href="<?= base_url('krs_mhs/cetakWordKRS/'.$idmhs.'/'.$semester) ?>"
																target="_blank">Docx</a>
															<a class="dropdown-item" href="<?= base_url('krs_mhs/cetakKRSXlsx/'.$idmhs.'/'.$semester) ?>"
																target="_blank">Xlsx</a>
															<a class="dropdown-item" href="<?= base_url('krs_mhs/cetakKrsHTML/'.$idmhs.'/'.$semester) ?>"
																target="_blank">HTML</a>
														</div>
													</div>
												</td>
											</tr>
											<?php
												}
											?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
</div>