<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card" style="overflow:auto;">
				<div class="row pb-5">
					<div class="col-md-12 row">
						<?php
							$idmhs = $this->session->userdata('id_mhs');
							$level = $this->session->userdata('level');
							$data['detail'] = $this->mahasiswa_model->ambil_id_mahasiswa($idmhs);
							foreach ($data['detail'] as $rowdt){
								$id_mhs = $rowdt->id ;
							}
						?>
						<div class="container p-0 col">
							<span class="fas fa-outdent"></span>
							<span class="title-8 ml-2 font-weight-bold">Profile Mahasiswa</span>
						</div>
						<div class="col">
							<div class="overview-wrap d-flex flex-row-reverse bd-highlight">
								<div class="dropdown">
									<button class="btn btn-primary btn-sm dropdown-toggle" type="button"
										id="dropdownMenuButton" data-toggle="dropdown" data-boundary="viewport"
										aria-haspopup="true" aria-expanded="false">
										<i class="fas fa-print"></i>&nbsp; Cetak Biodata
									</button>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
										<a class="dropdown-item" href="<?= base_url('mahasiswa/cetakDetailPdf/'.$id_mhs) ?>"target="_blank">PDF</a>
										<a class="dropdown-item" href="<?= base_url('mahasiswa/cetakWord/'.$id_mhs) ?>" target="_blank">Docx</a>
										<a class="dropdown-item" href="<?= base_url('mahasiswa/cetakXlsx/'.$id_mhs) ?>" target="_blank">Xlsx</a>
										<a class="dropdown-item" href="<?= base_url('mahasiswa/Biodatahtml/'.$id_mhs) ?>" target="_blank">HTML</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="container pb-5" style="font-size:15px;">
					<form action="<?= base_url('mahasiswa/update_mhs_aksi') ?>" enctype="multipart/form-data" method="post"
						accept-charset="utf-8">
						<input type="hidden" id="idmhs" name="id" value="<?= $rowdt->id; ?>">
						<input type="hidden" name="level" value="<?= $level; ?>">
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">NIM </div>
							<div class="col-sm pr-0"><?= $rowdt->nim; ?></div>
							<div class="col-sm text-right font-weight-bold pl-0">Nama</div>
							<div class="col-sm pr-0">
								<input type="text" name="nama_lengkap" class="form-control" value="<?= $rowdt->nama_lengkap; ?>" required>
							</div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">NIK</div>
							<div class="col-sm pr-0"><?= $rowdt->nik; ?></div>
							<div class="col-sm text-right font-weight-bold pl-0">Tempat Lahir</div>
							<div class="col-sm pr-0">
								<input type="text" name="tempat_lahir" class="form-control" value="<?= $rowdt->tempat_lahir; ?>" required>
							</div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Tanggal Lahir</div>
							<div class="col-sm pr-0">
								<input type="date" name="tanggal_lahir" class="form-control" value="<?= $rowdt->tanggal_lahir; ?>" required>
							</div>
							<div class="col-sm text-right font-weight-bold pl-0">Jenis Kelamin</div>
							<div class="col-sm pr-0">
								<select name="jenis_kelamin" id="" class="form-control" required>
									<option value="Laki-laki" <?php if($rowdt->jenis_kelamin == "Laki-laki"){echo 'selected=selected';} ?>>Laki-laki</option>
									<option value="Perempuan" <?php if($rowdt->jenis_kelamin == "Perempuan"){echo 'selected=selected';} ?>>Perempuan</option>
								</select>
							</div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Agama</div>
							<div class="col-sm pr-0">
								<select name="agama" id="" class="form-control" required>
									<option value="">--Pilih Agama--</option>
									<option value="Islam" <?php if($rowdt->agama == "Islam"){echo "selected=selected";} ?>>Islam</option>
									<option value="Kristen Protestan"
										<?php if($rowdt->agama == "Kristen Protestan"){echo "selected=selected";} ?>>Kristen
										Protestan</option>
									<option value="Kristen Katolik" <?php if($rowdt->agama == "Kristen Katolik"){echo "selected=selected";} ?>>
										Kristen Katolik
									</option>
									<option value="Hindu" <?php if($rowdt->agama == "Hindu"){echo "selected=selected";} ?>>Hindu</option>
									<option value="Buddha" <?php if($rowdt->agama == "Buddha"){echo "selected=selected";} ?>>Buddha</option>
									<option value="Khonghucu" <?php if($rowdt->agama == "Khonghucu"){echo "selected=selected";} ?>>Khonghucu
									</option>
								</select>
							</div>
							<div class="col-sm text-right font-weight-bold pl-0">Alamat Tinggal</div>
							<div class="col-sm pr-0">
								<textarea name="alamat" class="form-control" rows="8"><?= $rowdt->alamat; ?></textarea>
							</div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Kode Pos</div>
							<div class="col-sm pr-0">
								<input type="text" name="kode_pos" class="form-control" value="<?= $rowdt->kode_pos; ?>" required>
							</div>
							<div class="col-sm text-right font-weight-bold pl-0">No HP</div>
							<div class="col-sm pr-0">
								<input type="text" name="telepon" class="form-control" value="<?= $rowdt->telepon; ?>" required>
							</div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold pl-0">No WA</div>
							<div class="col-sm pr-0">
								<input type="text" name="no_wa" class="form-control" value="<?= $rowdt->no_wa; ?>" required>
							</div>
							<div class="col-sm text-right font-weight-bold">Foto</div>
							<div class="col-sm pr-0">
								<img class="mb-2" src="<?= base_url('assets_dashboard/images/icon/').$rowdt->photo; ?>" alt=""
									style="width:50%;">
								<input class="d-none" name="gbrmhs1" value="<?= $rowdt->photo; ?>">
								<input type="file" name="gambarmhs" style="font-size:10px;">
							</div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Email</div>
							<div class="col-sm pr-0">
								<input type="text" name="email" class="form-control" value="<?= $rowdt->email; ?>" required>
							</div>
							<div class="col-sm text-right font-weight-bold pl-0">Nama Asal SMA/SMK</div>
							<div class="col-sm pr-0">
								<input type="text" name="asal_sma" class="form-control" value="<?= $rowdt->asal_sma; ?>" required>
							</div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Alamat Asal SMA/SMK</div>
							<div class="col-sm pr-0">
								<textarea name="alamat_sma" class="form-control" rows="8"><?= $rowdt->alamat_sma; ?></textarea>
							</div>
							<div class="col-sm text-right font-weight-bold pl-0">Jurusan Sewaktu SMA/SMK</div>
							<div class="col-sm pr-0">
								<input type="text" name="jurusan_sma" class="form-control" value="<?= $rowdt->jurusan_sma; ?>" required>
							</div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Nama Ibu </div>
							<div class="col-sm pr-0">
								<input type="text" name="nama_ibu" class="form-control" value="<?= $rowdt->nama_ibu; ?>" required>
							</div>
							<div class="col-sm text-right font-weight-bold pl-0">Nama Ayah </div>
							<div class="col-sm pr-0">
								<input type="text" name="nama_ayah" class="form-control" value="<?= $rowdt->nama_ayah; ?>" required>
							</div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Pekerjaan Ayah</div>
							<div class="col-sm pr-0">
								<input type="text" name="pekerjaan_ayah" class="form-control"
										value="<?= $rowdt->pekerjaan_ayah; ?>" required>
							</div>
							<div class="col-sm text-right font-weight-bold pl-0">Pekerjaan Ibu</div>
							<div class="col-sm pr-0">
								<input type="text" name="pekerjaan_ibu" class="form-control"
										value="<?= $rowdt->pekerjaan_ibu; ?>" required>
							</div>
						</div>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">No. HP Orang Tua</div>
							<div class="col-sm pr-0">
								<input type="text" name="nohp_ortu" class="form-control" value="<?= $rowdt->nohp_ortu; ?>" required>
							</div>
							<div class="col-sm text-right font-weight-bold pl-0">Alamat Lengkap Orang Tua</div>
							<div class="col-sm pr-0">
								<textarea name="alamat_ortu" class="form-control" rows="8"><?= $rowdt->alamat_ortu; ?></textarea>
							</div>
						</div>
						<?php
							$where = array('id_prodi' => $rowdt->nama_prodi);
							$data['prodi']    = $this->mahasiswa_model->ambil_jenjang_prodi($where);
							foreach($data['prodi'] as $prod){ 
								$prodi = $prod->nama_prodi;
								$jenjang = $prod->jenjang_studi;
							}
						?>
						<div class="row border-bottom pb-1 pt-1">
							<div class="col-sm text-right font-weight-bold">Jurusan</div>
							<div class="col-sm pr-0"><?= $prodi; ?></div>
							<div class="col-sm text-right font-weight-bold pl-0">Jenjang Pendidikan</div>
							<div class="col-sm pr-0"><?= $jenjang; ?></div>
						</div>
						</div>
						<div class="d-flex justify-content-center">
							<button type="submit" class="btn btn-primary mr-2">Simpan</button>
							<a href="<?= base_url('mahasiswa/profil_mhs') ?>" class="btn btn-secondary ml-2">Kembali</a>
						</div>
					</form>
			</div>
		</div>
	</div>
</div>