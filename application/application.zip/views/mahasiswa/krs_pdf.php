<!DOCTYPE html>
<html lang="en">

	<head>

		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

		<!-- Title Page-->
		<title>KRS</title>

		<!-- Fontfaces CSS-->
		<style media="print">
			body{
				font-family: Calibri, Helvetica, sans-serif;
			}
			table{
				margin-left: auto;
				margin-right: auto;
				vertical-align: top;
			}
			.kepala{
				border-collapse:collapse;
    			border-spacing:0;
				text-align:center;
				font-family: Calibri, Helvetica, sans-serif;
			}	
			.tabel{
				font-family:"Times New Roman";
				font-size:12px;
			}	
			.kanan{
				width:200px;
			}
			@page{
				margin-top: 45mm;
				header: firstpage;
			}
			.tablekrs tr td, .tablekrs tr th{
				border: 1px solid black;
			}
			.tablekrs{
  				border-collapse: collapse;
				text-align:center;
			}
			.tablekrs tr th{
				padding:10px;
			}
			.tablekrs .tratas{
				border:0;
			}
			.tablekrs .tratas td{
				border:0;
			}
			.atas td{
				text-align:left;
				font-weight:bold;
				font-size:14px;
			}
		</style>


	</head>
	<body>
	<htmlpageheader name="firstpage">
		<table class="kepala" cellspacing="0" style="width:700px;position:relative;">
			<tr cellspacing="0">
				<th>
					<img class="mb-2" src="<?= base_url('assets_dashboard/images/header.png') ?>" alt=""
						style="">
				</th>

			</tr>
		</table>
	</htmlpageheader>
	<sethtmlpageheader name="firstpage" value="on" show-this-page="1" />
		<table class="tablekrs">
			<tr class="tratas">
				<th colspan="4">
					<h1>KARTU RENCANA STUDI (KRS)</h1>
				</th>
			</tr>
			<tr class="tratas">
				<td colspan="4">
					<?php
						date_default_timezone_set('Asia/Jakarta');
						// array bulan
						function tgl_indo($tanggal){
							$bulan = array (
								1 =>   'Januari',
								'Februari',
								'Maret',
								'April',
								'Mei',
								'Juni',
								'Juli',
								'Agustus',
								'September',
								'Oktober',
								'November',
								'Desember'
							);
							$pecahkan = explode('-', $tanggal);
							
							// variabel pecahkan 0 = tanggal
							// variabel pecahkan 1 = bulan
							// variabel pecahkan 2 = tahun
						 
							return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
						}
						 
						
						foreach($krs as $rowthn_akd){
							$thnakad = $rowthn_akd->tahun_akademik;
							$nim = $rowthn_akd->nim;
							$nama = $rowthn_akd->nama_lengkap;
							$prodi = $rowthn_akd->nama_prodi;
							$ketua_prodi = $rowthn_akd->ketua_prodi;
							$dosen_wali = $rowthn_akd->dosen_wali;
							$semester = $rowthn_akd->semester;
							$tempat_lahir = $rowthn_akd->tempat_lahir;	
							$tanggal_lahir = $rowthn_akd->tanggal_lahir;	
						}

						if($semester == 1){
							$semester_huruf = 'Satu';
						}else if($semester == 2){
							$semester_huruf = 'Dua';
						}else if($semester == 3){
							$semester_huruf = 'Tiga';
						}else if($semester == 4){
							$semester_huruf = 'Empat';
						}else if($semester == 5){
							$semester_huruf = 'Lima';
						}else if($semester == 6){
							$semester_huruf = 'Enam';
						}else if($semester == 7){
							$semester_huruf = 'Tujuh';
						}else if($semester == 8){
							$semester_huruf = 'Delapan';
						}

						$data['k_prodi'] = $this->krs_model->ambil_kprodi($ketua_prodi, 'dosen')->result();
						foreach($data['k_prodi'] as $rowkprodi){
							$nama_ketuaprd = $rowkprodi->nama_dosen;
						}

						$data['dosen_wali'] = $this->krs_model->ambil_kprodi($dosen_wali, 'dosen')->result();
						foreach($data['dosen_wali'] as $rowd_wali){
							$nama_dosen_wali = $rowd_wali->nama_dosen;
						}

						$tgl_lhr = date_create($tanggal_lahir);
					?>
					<i>Tahun Akademik <?= $thnakad; ?></i>
				</td>
			</tr>
			<tr class="tratas">
				<td><br></td>
			</tr>
			<tr class="tratas atas">
				<td>NIM </td>
				<td>: <?= $nim; ?></td>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prog. Studi</td>
				<td>: <?= $prodi; ?> </td>
			</tr>
			<tr class="tratas atas">
				<td>Nama</td>
				<td>: <?= $nama; ?></td>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Semester</td>
				<td>: <?= $semester.' ('.$semester_huruf.')'; ?> </td>
			</tr>
			<tr class="tratas atas">
				<td>Tempat, Tgl Lahir</td>
				<td>: <?= $tempat_lahir.', '.tgl_indo(date_format($tgl_lhr,"Y-m-d")); ?></td>
			</tr>
			<tr class="tratas" style="border-top:2px solid black">
				<td colspan="4"><br></td>
			</tr>
			<tr>
				<th>No</th>
				<th>Kode Mata Kuliah</th>
				<th>Nama Mata Kuliah</th>
				<th>SKS</th>
			</tr>
			<?php 
				$no = '1';
				$nom = '0';
				foreach($krs as $dt):
					$nom++;
			?>
			<tr>
				<td><?= $no++; ?></td>
				<td><?= $dt->kode_matakuliah; ?></td>
				<td><?= $dt->nama_matakuliah; ?></td>
				<td><?= $dt->sks; ?></td>
			</tr>
			<?php endforeach; ?>
			<tr>
				<td colspan="3" style="text-align:left;padding-left:10px;"><b>TOTAL SKS</b></td>
				<td><b><?= $dt->jumlah_sks; ?></b></td>
			</tr>
			<tr>
				<td colspan="3" style="text-align:left;padding-left:10px;">Jumlah Mata Kuliah</td>
				<td><?= $nom++; ?></td>
			</tr>
			<tr>
				<td colspan="2" style="border:0;"><br></td>
			</tr>
			<tr>
				<td colspan="2" style="border:0;"><br></td>
			</tr>
			<tr>
				<td colspan="2" style="border:0;">Ketua Progran Studi</td>
				<td colspan="2" style="border:0;">Dosen wali</td>
			</tr>
			<tr>
				<td colspan="2" style="border:0;"><?= $prodi; ?></td>
			</tr>
			<tr>
				<td colspan="2" style="border:0;"><br></td>
			</tr>
			<tr>
				<td colspan="2" style="border:0;"><br></td>
			</tr>
			<tr>
				<td colspan="2" style="border:0;"><br></td>
			</tr>
			<tr>
				<td colspan="2" style="border:0;"><br></td>
			</tr>
			<tr>
				<td colspan="2" style="border:0;"><u>(<?= $nama_ketuaprd; ?>)</u></td>
				<td colspan="2" style="border:0;"><u>(<?= $nama_dosen_wali; ?>)</u></td>
			</tr>
			<tr>
				<td colspan="2" style="border:0;"><br></td>
			</tr>
			<tr>
				<td colspan="4" style="text-align:left;border:0;font-size:12px;">
					<i>Perhatian: KRS ini merupakan Bukti Pengambilan Mata 
						Kuliah dan menjadi syarat Pendaftaran Semester berikutnya
					</i>
				</td>
			</tr>
		</table>
	</body>

</html>