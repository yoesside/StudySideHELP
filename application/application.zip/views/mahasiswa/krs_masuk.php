<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12 row">
						<div class="container p-0 col">
							<span class="fas fa-outdent"></span>
							<span class="title-8 ml-2 font-weight-bold">Kartu Rencana Studi</span>
						</div>
						<?php
							foreach($cekidmhs as $spprow){
								$uangspp =  $spprow->status_uang_kuliah;
								$idmhs_krs  =  $spprow->id_mhs;
								$semkrs  =  $spprow->nm_semester;
							}
							if(!empty($tahun_akademik)){
								if($uangspp == 'Lunas' or $uangspp == 'Izin'){
						?>
						<div class="col">
							<div class="overview-wrap d-flex flex-row-reverse bd-highlight">
								<div class="dropdown">
									<button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton"
										data-toggle="dropdown" data-boundary="viewport" aria-haspopup="true" aria-expanded="false">
										<i class="fas fa-print"></i>&nbsp; Cetak KRS
									</button>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
										<a class="dropdown-item" href="<?= base_url('krs_mhs/cetakKrsPdf/'.$idmhs_krs.'/'.$semkrs) ?>"
											target="_blank">PDF</a>
										<a class="dropdown-item" href="<?= base_url('krs_mhs/cetakWordKRS/'.$idmhs_krs.'/'.$semkrs) ?>"
											target="_blank">Docx</a>
										<a class="dropdown-item" href="<?= base_url('krs_mhs/cetakKRSXlsx/'.$idmhs_krs.'/'.$semkrs) ?>"
											target="_blank">Xlsx</a>
										<a class="dropdown-item" href="<?= base_url('krs_mhs/cetakKrsHTML/'.$idmhs_krs.'/'.$semkrs) ?>"
											target="_blank">HTML</a>
									</div>
								</div>
							</div>
						</div>
						<?php
								}else{
									echo ' ';
								}
							} else{
								echo '';
							}
						?>
					</div>
				</div>
				<?= $this->session->flashdata('pesan'); ?>
				<?php
					foreach($cekidmhs as $semmhs){
						$id_mah  =  $semmhs->id_mhs;
						$uangkul =  $semmhs->status_uang_kuliah;
						$nm_sem  =  $semmhs->nm_semester;
					}

					foreach($getmhs as $rowmhs){
						$idmhs			= $rowmhs->id;
						$nim 			= $rowmhs->nim;
						$nama			= $rowmhs->nama_lengkap;
						$semester_mhs	= $rowmhs->nm_semester;
						$nama_prodi		= $rowmhs->nama_prodi;
						$idprodi		= $rowmhs->id_prodi;
						$jenjang_std	= $rowmhs->jenjang_studi;
					}
					if(empty($tahun_akademik)){
				?>
				
				<div class="d-flex justify-content-center font-weight-bold">Jadwal pengisian KRS belum ada atau uang kuliah belum lunas</div>
				
				<?php
					}else{
					foreach($tahun_akademik as $rowthn){
						$id_thn			= $rowthn->id_thn_akad;
						$jadwal_awal	= $rowthn->jadwal_awal_krs;
						$jadwal_akhir	= $rowthn->jadwal_akhir_krs;
						$jenissemester	= $rowthn->jns_semester;
					}
					
					$date1=date_create($jadwal_awal);
					$date2=date_create($jadwal_akhir);

					if($uangkul == 'Lunas' or $uangspp == 'Izin'){
				?>
				<div class="container pb-5" style="font-size:15px;">
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Semester </div>
						<div class="col-sm pr-0"><?= $semester_mhs; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Periode Pengisian</div>
						<div class="col-sm pr-0"><?= date_format($date1,"d-m-Y"); ?> s/d <?= date_format($date2,"d-m-Y"); ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">NIM</div>
						<div class="col-sm pr-0"><?= $nim; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Nama</div>
						<div class="col-sm pr-0"><?= $nama; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Jenjang Studi</div>
						<div class="col-sm pr-0"><?= $jenjang_std; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Program Studi</div>
						<div class="col-sm pr-0"><?= $nama_prodi; ?></div>
					</div>
				</div>
				<?php
					if($cekkrs->num_rows() > 0 or $krsada->num_rows() > 0){
				?>
				<div class="table-responsive">
					<table class="table table-bordered table-striped text-dark">
						<thead class="thead-light">
							<tr>
								<th>Kode</th>
								<th>Nama</th>
								<th>SKS</th>
							</tr>
						</thead>
						<tbody>
							<?php
				
									foreach($tampilkrs as $rowkrs):
							?>
							<tr>
								<td><?= $rowkrs->kode_matakuliah; ?></td>
								<td><?= $rowkrs->nama_matakuliah; ?></td>
								<td><?= $rowkrs->sks; ?></td>
							</tr>
							<?php 
								endforeach;
					
							?>
							<tr>
								<td class="font-weight-bold"> Total SKS</td>
								<td></td>
								<td class="font-weight-bold" id="totalsks"><?= $rowkrs->jumlah_sks; ?></td>
							</tr>
						</tbody>
					</table>
				</div>
				<?php
					}else{
				?>
				<div class="table-responsive">
					<?= form_open_multipart('krs_mhs/tambah_krs_aksi'); ?>
						<input  type="hidden" value="<?= $idmhs; ?>" name="idmhs">
						<input  type="hidden" value="<?= $id_thn; ?>" name="idthn">
						<input  type="hidden" value="<?= $semester_mhs; ?>" name="semsmhs">
						<table class="table table-bordered table-striped text-dark">
							<thead class="thead-light">
								<tr>
									<th>Kode</th>
									<th>Nama</th>
									<th>SKS</th>
									<th>Pilih</th>
								</tr>
							</thead>
							<tbody>
								<tr class="table-info">
									<td colspan="4">Mata Kuliah Wajib</td>
								</tr>
								<?php
									if (!empty($matkul)){
										foreach($matkul as $matakuliah):
								?>
								<tr>
									<td><?= $matakuliah->kode_matakuliah; ?></td>
									<td><?= $matakuliah->nama_matakuliah; ?></td>
									<td><?= $matakuliah->sks; ?></td>
									<td>
										<input class="ceksks" type="checkbox" name="id_matkul[]" data-nilai="<?= $matakuliah->sks; ?>" value="<?= $matakuliah->id_matkul; ?>">
									</td>
								</tr>
								<?php 
									endforeach;
									} 
								?>
								<tr class="table-info">
									<td colspan="4">Mata Kuliah Pilihan</td>
								</tr>
								<?php
									//Group semester untuk matakuliah pilihan (di group menurut semester)

									$wheresemjns = array(
										'jns_semester'	=> $jenissemester,
										'semester !='	=> $nm_sem
									);
									$data['group'] = $this->krs_model->getSemesterGroup($wheresemjns)->result();
										foreach($data['group'] as $rowgroup){
								?>
								<tr class="mtkulpilihan">
									<td colspan="4">Semester <?= $rowgroup->semester; ?></td>
								</tr>
								<?php	
										$where1 =  array(
											'matakuliah.semester'	=> $rowgroup->semester,
											'matakuliah.id_prodi'	=> $idprodi
										);

										$data['getpilih'] = $this->krs_model->get_sem_join($where1)->result();
										foreach($data['getpilih'] as $matkullain){
								?>
								<tr class="mtkulpilihan">
									<td><?=$matkullain->kode_matakuliah;?></td>
									<td><?=$matkullain->nama_matakuliah;?></td>
									<td><?=$matkullain->sks;?></td>
									<td>
										<input class="ceksks" type="checkbox" name="id_matkul[]" data-nilai="<?= $matkullain->sks; ?>" value="<?= $matkullain->id_matkul; ?>">
									</td>
								</tr>
								<?php
									}
								}
								?>
								<tr>
									<td class="font-weight-bold"> Total SKS</td>
									<td></td>
									<td class="font-weight-bold" id="totalsks">0</td>
									<td><input name="skstot" type="hidden" id="skstot"></td>
								</tr>
							</tbody>
						</table>
							<div class="container d-flex justify-content-center pt-4">
								<button type="submit" class="btn btn-success mr-2" onclick="return confirm('Apakah data yang anda kirim sudah benar?')">
									Submit KRS
								</button>
								<button class="btn btn-danger ml-2 row-btn" type="button">
									Mata Kuliah Lainnya
								</button>
							</div>
					<?php form_close(); ?>
				</div>
				<?php
						}
					}else{
				?>
					<div class="d-flex justify-content-center font-weight-bold">Jadwal pengisian KRS belum ada atau uang kuliah belum lunas</div>
				<?php
					}
				}
				?>
			</div>
		</div>
	</div>
</div>