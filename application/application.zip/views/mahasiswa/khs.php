<div class="container-fluid">
	<div class="row">
		<div class="col">
			<div class="au-card">
				<div class="row pb-4">
					<div class="col-md-12 row">
						<div class="container p-0 col">
							<span class="fas fa-outdent"></span>
							<span class="title-8 ml-2 font-weight-bold">Kartu Hasil Studi</span>
						</div>
						<?php
							$id_mh = $this->session->userdata('id_mhs'); 
						?>
						<div class="col">
							<div class="overview-wrap d-flex flex-row-reverse bd-highlight">
								<div class="dropdown">
									<button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton"
										data-toggle="dropdown" data-boundary="viewport" aria-haspopup="true" aria-expanded="false">
										<i class="fas fa-print"></i>&nbsp; Cetak KHS
									</button>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
										<a class="dropdown-item" href="<?= base_url('khs/cetakKHSSemuaPdf/'.$id_mh) ?>" target="_blank">PDF</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?= $this->session->flashdata('pesan'); ?>
				<?php
					foreach($getmhs as $rowmhs){
						$idmhs			= $rowmhs->id;
						$nim 			= $rowmhs->nim;
						$nama			= $rowmhs->nama_lengkap;
						$semester_mhs	= $rowmhs->nm_semester;
						$nama_prodi		= $rowmhs->nama_prodi;
						$tempat_lahir	= $rowmhs->tempat_lahir;
						$tanggal_lahir	= $rowmhs->tanggal_lahir;
						$idprodi		= $rowmhs->id_prodi;
						$jenjang_std	= $rowmhs->jenjang_studi;
						$status_uangkul	= $rowmhs->status_uang_kuliah;
					}
					$tgl_lahir=date_create($tanggal_lahir);

					//untuk menghitung IPK
					foreach($getjlhipk1 as $rowjumlah1){
						$jumlahnilai_akhir1 = $rowjumlah1->jumlahn;
					}
					foreach($getjlhipk2 as $rowjumlah2){
						$jumlahnilai_akhir2 = $rowjumlah2->jumlahsks;
					}
				?>
				<div class="container pb-5" style="font-size:15px;">
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">NIM </div>
						<div class="col-sm pr-0"><?= $nim; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Program Studi</div>
						<div class="col-sm pr-0"><?= $nama_prodi; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Nama</div>
						<div class="col-sm pr-0"><?= $nama; ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">Semester saat ini</div>
						<div class="col-sm pr-0"><?= $semester_mhs; ?></div>
					</div>
					<div class="row border-bottom pb-1 pt-1">
						<div class="col-sm text-right font-weight-bold">Tempat Tanggal Lahir</div>
						<div class="col-sm pr-0"><?= $tempat_lahir.', '.date_format($tgl_lahir,"d M Y"); ?></div>
						<div class="col-sm text-right font-weight-bold pl-0">IPK</div>
						<div class="col-sm pr-0 text-primary h3"><?= number_format($jumlahnilai_akhir1/$jumlahnilai_akhir2, 2); ?></div>
					</div>
				</div>
				<div class="table-responsive pb-3">
					<table class="table">
						<thead>
							<tr class="table-primary">
								<th scope="col">Semester</th>
								<th scope="col">IP Semester</th>
								<th scope="col">Cetak</th>
							</tr>
						</thead>
						<tbody>
							<?php
								foreach($group as $groupkhs){
									$wherekhs = array(
										'krs.semester' => $groupkhs->semester,
										'krs.id_mhs'   => $groupkhs->id_mhs
									);
									$khssem = $groupkhs->semester;
									$data['jumlahnilai'] = $this->transkrip_model->jumlah_nilai_akhir($idmhs, $khssem)->result();
									foreach($data['jumlahnilai'] as $rowjumlah){
										$jumlahnilai_akhir = $rowjumlah->jumlah;
									}
									$data['jumlahskssm'] = $this->transkrip_model->jumlah_sks_sem($idmhs, $khssem)->result();
									foreach($data['jumlahskssm'] as $rowsksjlh){
										$skslhsem = $rowsksjlh->jumlah_sks;
							?>
							<tr>
								<td><?= $groupkhs->semester; ?></td>
								<td>
									<?php
										if($groupkhs->semester == $semester_mhs and $status_uangkul == 'Izin'){
											echo 'Uang kuliah belum lunas';
										}else{
											echo number_format($jumlahnilai_akhir/$skslhsem, 2); 
										}
									?>
								</td>
								<td>
									<?php 
										if($groupkhs->semester == $semester_mhs and $status_uangkul == 'Izin'){
											echo 'Uang kuliah belum lunas';
										}else{
									?>
									<div class="dropdown">
										<button class="btn btn-success btn-sm dropdown-toggle" type="button" id="dropdownMenuButton"
											data-toggle="dropdown" data-boundary="viewport" aria-haspopup="true"
											aria-expanded="false">
											<i class="fas fa-print"></i>&nbsp; Cetak KHS
										</button>
										<div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="min-width:100px;">
											<a class="dropdown-item" href="<?= base_url('khs/cetakKHSPdf/'.$idmhs.'/'.$khssem) ?>"
												target="_blank">PDF</a>
											<a class="dropdown-item" href="<?= base_url('khs/cetakWordKHS/'.$idmhs.'/'.$khssem) ?>"
												target="_blank">Docx</a>
											<a class="dropdown-item" href="<?= base_url('khs/cetakKHSXlsx/'.$idmhs.'/'.$khssem) ?>"
												target="_blank">Xlsx</a>
											<a class="dropdown-item" href="<?= base_url('khs/cetakKHSHTML/'.$idmhs.'/'.$khssem) ?>"
												target="_blank">HTML</a>
										</div>
									</div>
									<?php
										}
									?>
								</td>
							</tr>
							<?php
													}
												}
											?>
						</tbody>
					</table>
				</div>
				<?php
					$data['jumlah'] = $this->transkrip_model->jumlah_nilai_akhir($idmhs, $semester_mhs)->result();
					foreach($data['jumlah'] as $rowjumlah){
						$jumlahnilai_akhir = $rowjumlah->jumlah;
					}
				?>
				<?php 
					if($status_uangkul == 'Izin'){
						echo '';
					}else{
				?>

				<h3 class="pb-4">KHS untuk semester saat ini (Semester <?= $semester_mhs; ?>)</h3>
				<div class="table-responsive">
					<table class="table table-bordered table-striped text-dark">
						<thead class="thead-light">
							<tr>
								<th rowspan="2">No</th>
								<th rowspan="2">Kode</th>
								<th rowspan="2">Nama</th>
								<th rowspan="2">SKS (K)</th>
								<th colspan="3">Nilai</th>
								<th>Nilai Akhir</th>
							</tr>
							<tr>
								<th>Angka (A)</th>
								<th>Huruf (H)</th>
								<th>Bobot (N)</th>
								<th>(N x K)</th>
							</tr>
						</thead>
						<tbody>
							<?php
									if (!empty($getkhs)){
										$no = 1;
										$where = array(
											'krs.semester' => $semester_mhs,
											'krs.id_mhs'   => $idmhs
										);
										$data['getkhs'] = $this->transkrip_model->datakhs($where, 'krs')->result();
										foreach($data['getkhs'] as $matakuliah):
								?>
							<tr>
								<td><?= $no++; ?></td>
								<td><?= $matakuliah->kode_matakuliah; ?></td>
								<td><?= $matakuliah->nama_matakuliah; ?></td>
								<td><?= $matakuliah->sks; ?></td>
								<td><?= $matakuliah->nilai_angka; ?></td>
								<td><?= $matakuliah->nilai_huruf; ?></td>
								<td><?= $matakuliah->bobot; ?></td>
								<td><?= $matakuliah->nilai_akhir; ?></td>
							</tr>
							<?php 
									endforeach;
									} 
								?>
							<tr>
								<td></td>
								<td class="font-weight-bold" colspan="2">Jumlah</td>
								<td class="font-weight-bold" id="totalsks"><?= $matakuliah->jumlah_sks ?></td>
								<td></td>
								<td></td>
								<td></td>
								<td class="font-weight-bold"><?= $jumlahnilai_akhir; ?></td>
							</tr>
							<tr class="ipkhs">
								<td></td>
								<td class="font-weight-bold" colspan="2">Indeks Prestasi (IP) : </td>
								<td class="font-weight-bold" id="totalsks">
									<?= number_format($jumlahnilai_akhir/$matakuliah->jumlah_sks, 2); ?>
								</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
						</tbody>
					</table>
				</div>

				<?php
					}
				?>

			</div>
		</div>
	</div>
</div>