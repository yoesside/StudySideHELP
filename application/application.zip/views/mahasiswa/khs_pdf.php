<!DOCTYPE html>
<html lang="en">

	<head>

		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

		<!-- Title Page-->
		<title>KHS</title>

		<!-- Fontfaces CSS-->
		<style media="print">
			body{
				font-family: Calibri, Helvetica, sans-serif;
			}
			table{
				margin-left: auto;
				margin-right: auto;
				vertical-align: top;
			}
			.kepala{
				border-collapse:collapse;
    			border-spacing:0;
				text-align:center;
				font-family: Calibri, Helvetica, sans-serif;
			}	
			.tabel{
				font-size:12px;
			}	
			.kanan{
				width:200px;
			}
			@page{
				margin-top: 45mm;
				header: firstpage;
			}
			.tablekrs tr td, .tablekrs tr th{
				display:block;
				border: 1px solid black;
			}
			.tablekrs tr th.fit, .tablekrs tr td.fit{
				white-space:nowrap;
			}
			.tablekrs{
  				border-collapse: collapse;
				text-align:center;
				vertical-align:middle;
			}
			.tablekrs tr th{
				padding:10px;
			}
			.tablekrs .tratas{
				border:0;
			}
			.tablekrs .tratas td{
				border:0;
			}
			.atas td{
				text-align:left;
				font-weight:bold;
				font-size:14px;
			}
		</style>


	</head>
	<body>
	<htmlpageheader name="firstpage">
		<table class="kepala" cellspacing="0" style="width:700px;position:relative;">
			<tr cellspacing="0">
				<th>
					<img class="mb-2" src="<?= base_url('assets_dashboard/images/header.png') ?>" alt=""
						style="">
				</th>

			</tr>
		</table>
	</htmlpageheader>
	<sethtmlpageheader name="firstpage" value="on" show-this-page="1" />
		<table class="tablekrs">
			<tr class="tratas">
				<th colspan="8">
					<h1>KARTU HASIL STUDI (KHS)</h1>
				</th>
			</tr>
			<tr class="tratas">
				<td colspan="8">
					<?php
						date_default_timezone_set('Asia/Jakarta');
						// array bulan
						function tgl_indo($tanggal){
							$bulan = array (
								1 =>   'Januari',
								'Februari',
								'Maret',
								'April',
								'Mei',
								'Juni',
								'Juli',
								'Agustus',
								'September',
								'Oktober',
								'November',
								'Desember'
							);
							$pecahkan = explode('-', $tanggal);
							
							// variabel pecahkan 0 = tanggal
							// variabel pecahkan 1 = bulan
							// variabel pecahkan 2 = tahun
						 
							return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
						}
						 
						
						foreach($getkhs as $rowthn_akd){
							$thnakad = $rowthn_akd->tahun_akademik;
							$idmhs = $rowthn_akd->id_mhs;
							$nim = $rowthn_akd->nim;
							$nama = $rowthn_akd->nama_lengkap;
							$prodi = $rowthn_akd->nama_prodi;
							$ketua_prodi = $rowthn_akd->ketua_prodi;
							$dosen_wali = $rowthn_akd->dosen_wali;
							$semester = $rowthn_akd->semester;
							$tempat_lahir = $rowthn_akd->tempat_lahir;	
							$tanggal_lahir = $rowthn_akd->tanggal_lahir;	
						}
						
						$data['jumlah'] = $this->transkrip_model->jumlah_nilai_akhir($idmhs, $semester)->result();
						foreach($data['jumlah'] as $rowjumlah){
							$jumlahnilai_akhir = $rowjumlah->jumlah;
						}

						if($semester == 1){
							$semester_huruf = 'Satu';
						}else if($semester == 2){
							$semester_huruf = 'Dua';
						}else if($semester == 3){
							$semester_huruf = 'Tiga';
						}else if($semester == 4){
							$semester_huruf = 'Empat';
						}else if($semester == 5){
							$semester_huruf = 'Lima';
						}else if($semester == 6){
							$semester_huruf = 'Enam';
						}else if($semester == 7){
							$semester_huruf = 'Tujuh';
						}else if($semester == 8){
							$semester_huruf = 'Delapan';
						}

						$data['k_prodi'] = $this->krs_model->ambil_kprodi($ketua_prodi, 'dosen')->result();
						foreach($data['k_prodi'] as $rowkprodi){
							$nama_ketuaprd = $rowkprodi->nama_dosen;
						}

						$data['dosen_wali'] = $this->krs_model->ambil_kprodi($dosen_wali, 'dosen')->result();
						foreach($data['dosen_wali'] as $rowd_wali){
							$nama_dosen_wali = $rowd_wali->nama_dosen;
						}

						$tgl_lhr = date_create($tanggal_lahir);
					?>
					<i>Tahun Akademik <?= $thnakad; ?></i>
				</td>
			</tr>
			<tr class="tratas">
				<td><br></td>
			</tr>
			<tr class="tratas atas">
				<td colspan="2">NIM </td>
				<td colspan="2">: <?= $nim; ?></td>
				<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prog. Studi</td>
				<td colspan="2">: <?= $prodi; ?> </td>
			</tr>
			<tr class="tratas atas">
				<td colspan="2">Nama</td>
				<td colspan="2">: <?= $nama; ?></td>
				<td colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Semester</td>
				<td colspan="2">: <?= $semester.' ('.$semester_huruf.')'; ?> </td>
			</tr>
			<tr class="tratas atas" style="padding-bottom:5px;">
				<td colspan="2" class="fit">Tempat, Tgl Lahir</td>
				<td colspan="2">: <?= $tempat_lahir.', '.tgl_indo(date_format($tgl_lhr,"Y-m-d")); ?></td>
			</tr>
			<tr class="tratas" style="border-top:2px solid black;">
				<td colspan="8"><br></td>
			</tr>
			<tr>
				<th rowspan="2">No</th>
				<th rowspan="2" class="fit">Kode M.K</th>
				<th rowspan="2" class="fit">Nama Mata Kuliah</th>
				<th rowspan="2">SKS(K)</th>
				<th colspan="3" class="fit">Nilai</th>
				<th class="fit">Nilai Akhir</th>
			</tr>
			<tr>
				<th class="fit">Angka (A)</th>
				<th class="fit">Huruf (H)</th>
				<th class="fit">Bobot (N)</th>
				<th class="fit">(N x K)</th>
			</tr>
			<?php 
				$no = '1';
				$nom = '0';
				foreach($getkhs as $dt):
					$nom++;
			?>
			<tr>
				<td><?= $no++; ?></td>
				<td><?= $dt->kode_matakuliah; ?></td>
				<td class="fit"><?= $dt->nama_matakuliah; ?></td>
				<td><?= $dt->sks; ?></td>
				<td><?= $dt->nilai_angka; ?></td>
				<td><?= $dt->nilai_huruf; ?></td>
				<td><?= $dt->bobot; ?></td>
				<td><?= $dt->nilai_akhir; ?></td>
			</tr>
			<?php endforeach; ?>
			<tr>
				<td></td>
				<td colspan="2" style="text-align:left;padding-left:10px;"><b>Jumlah</b></td>
				<td><b><?= $dt->jumlah_sks; ?></b></td>
				<td></td>
				<td></td>
				<td></td>
				<td><b><?= $jumlahnilai_akhir; ?></b></td>
			</tr>
			<tr style="border:0;border-bottom:2px solid black;">
				<td style="border:0;"></td>
				<td colspan="2" style="text-align:left;padding-left:10px;border:0;"><b>Indeks Prestasi (IP) : </b></td>
				<td style="border:0;">
					<b><?= number_format($jumlahnilai_akhir/$dt->jumlah_sks, 2); ?></b>
				</td>
				<td style="border:0;"></td>
				<td style="border:0;"></td>
				<td style="border:0;"></td>
				<td style="border:0;"></td>
			</tr>
			<tr><td style="border:0;"><br></td></tr>
			<tr><td style="border:0;"><br></td></tr>
			<tr>
				<td style="text-align:left;border:0;font-size:12px;">
					<i>Keterangan</i>
				</td>
			</tr>
			<tr>
				<td style="text-align:left;border:0;font-size:12px;">
					<i>Skala Nilai</i>
				</td>
			</tr>
			<tr>
				<td style="text-align:left;border:0;font-size:12px;">
					<i>Skala Nilai</i>
				</td>
			</tr>
			<tr>
				<td style="text-align:left;border:0;font-size:12px;">
					<i>80- 100</i>
				</td>
				<td style="text-align:left;border:0;font-size:12px;">
					<i>: A</i>
				</td>
			</tr>
			<tr>
				<td style="text-align:left;border:0;font-size:12px;">
					<i>70 - 79 </i>
				</td>
				<td style="text-align:left;border:0;font-size:12px;">
					<i>: C</i>
				</td>
			</tr>
			<tr>
				<td style="text-align:left;border:0;font-size:12px;">
					<i>50 - 59</i>
				</td>
				<td style="text-align:left;border:0;font-size:12px;">
					<i>: D</i>
				</td>
			</tr>
			<tr>
				<td style="text-align:left;border:0;font-size:12px;">
					<i>0 - 49</i>
				</td>
				<td style="text-align:left;border:0;font-size:12px;">
					<i>: E</i>
				</td>
			</tr>
		</table>
	</body>

</html>