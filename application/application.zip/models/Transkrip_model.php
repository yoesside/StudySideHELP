<?php

class Transkrip_model extends CI_Model{

  public $table = 'krs';
  public $id = 'id_krs';
  
  var $table1 = 'mahasiswa';

  var $table2 = 'matakuliah';

  var $table3 = 'prodi';

  var $table4 = 'tahun_akademik';

  var $table5 = 'semester';

  var $table6 = 'jumlah_sks';
  

  public function datakhs($where){
    $this->db->select('*');
		$this->db->from($this->table);
		$this->db->join($this->table1, 'krs.id_mhs = mahasiswa.id');
		$this->db->join($this->table2, 'krs.id_matkul = matakuliah.id_matkul');
		$this->db->join($this->table6, 'krs.id_mhs = jumlah_sks.id_mhs and krs.id_thn_akad = jumlah_sks.id_ta_akad');
		$this->db->where($where);
		return $this->db->get();
  }

  public function datasemhal($wheresm){
    $this->db->select('*');
    $this->db->from($this->table5);
		$this->db->where($wheresm);
		return $this->db->get();
  }

  public function jumlah_nilai_akhir($idmhs, $semester){
    return $this->db->query('SELECT SUM(krs.nilai_akhir) AS jumlah FROM krs WHERE krs.id_mhs='.$idmhs.' and krs.semester='.$semester);
  }

  public function jumlah_nilaia_ipk($idmhs){
    return $this->db->query('SELECT SUM(krs.nilai_akhir) AS jumlahn FROM krs WHERE krs.id_mhs='.$idmhs);
  }

  public function jumlah_sks_ipk($idmhs){
    return $this->db->query('SELECT SUM(jumlah_sks.jumlah_sks) AS jumlahsks FROM jumlah_sks WHERE jumlah_sks.id_mhs='.$idmhs);
  }

  public function jumlah_sks_sem($idmhs, $semester){
    return $this->db->query('SELECT * FROM jumlah_sks WHERE jumlah_sks.id_mhs='.$idmhs.' and jumlah_sks.semester='.$semester);
  }

  public function getSemesterGroup($where){
    $this->db->group_by('semester'); 
    $this->db->where($where);
		$this->db->order_by('semester', 'ASC');
		return $this->db->get($this->table);
  }

  public function insert($data){
    $this->db->insert($this->table, $data);
  }

  public function update($datanilai){
   
    $this->db->update_batch('krs', $datanilai, 'id_krs');
  }
}