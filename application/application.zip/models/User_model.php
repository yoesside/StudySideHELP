<?php

class User_model extends CI_Model{

  public $table = 'users';
  public $id = 'id_user';

  public function ambil_data($id){
    $this->db->where('username', $id);
    return $this->db->get('users')->row();
  }

  public function ambil_id_user($id){
    $hasil = $this->db->where('id_user', $id)->get('users');
    if($hasil->num_rows() > 0){
      return $hasil->result();
    }
    else{
      return false;
    }
  }

  public function ambil_id_mahasiswa($id){
    $hasil = $this->db->where('id', $id)->get('mahasiswa');
    if($hasil->num_rows() > 0){
      return $hasil->result();
    }
    else{
      return false;
    }
  }

  public function tampil_data($table){
    return $this->db->get($table);
  }

  public function insert_data($data, $table){
    $this->db->insert($table, $data);
  }

  public function edit_data($where, $table){
    return $this->db->get_where($table, $where);
  }

  public function update_data($where, $data, $table){
    $this->db->where($where);
    $this->db->update($table, $data);
  }

  public function hapus_data($where, $table){
    $this->db->where($where);
    $this->db->delete($table);
  }

}