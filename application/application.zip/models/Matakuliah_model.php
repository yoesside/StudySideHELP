<?php

class Matakuliah_model extends CI_Model{
  public $table = 'matakuliah';
  public $id    = 'kode_matakuliah';
  public $order = 'DESC';

  var $table2 = 'prodi';

  public function tampil_data($table){
    $this->db->select('*');
		$this->db->from($this->table);
		$this->db->join($this->table2, 'matakuliah.id_prodi = prodi.id_prodi');
		$this->db->order_by('id_matkul', $this->order);
		return $this->db->get();
  }

  public function insert_data($data, $table){
    $this->db->insert($table, $data);
  }
  
  public function ambil_kode_matakuliah($kode){
    $result = $this->db->where('kode_matakuliah', $kode)->get('matakuliah');

    if($result->num_rows() > 0){
      return $result->result();
    }
    else{
      return false;
    }
  }
  public function matkuldetail($kode){
    $this->db->select('*');
		$this->db->from($this->table);
		$this->db->join($this->table2, 'matakuliah.id_prodi = prodi.id_prodi');
		$this->db->where('kode_matakuliah', $kode);
		return $this->db->get();
  }

  public function ambil_matakuliah_wajib($wherewajib){
    $result = $this->db->where($wherewajib)->get('matakuliah');

    if($result->num_rows() > 0){
      return $result->result();
    }
    else{
      return false;
    }
  }

  public function update_data($where, $data, $table){
    $this->db->where($where);
    $this->db->update($table, $data);
  }

  public function hapus_data($where, $table){
    $this->db->where($where);
    $this->db->delete($table);
  }

  public function get_by_id($id){
    $this->db->where($this->id, $id);
    return $this->db->get($this->table)->row();
  }
}