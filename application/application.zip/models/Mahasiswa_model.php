<?php

class Mahasiswa_model extends CI_Model{

  public $table = 'mahasiswa';
  public $id    = 'nim';
  public $order = 'DESC';

  var $table2 = 'semester';
  var $table3 = 'prodi';

  public function tampil_data($table){
    return $this->db->get($table);
  }

  public function tampil_data_join(){
    $this->db->select('*');
		$this->db->from($this->table);
		$this->db->join($this->table2, 'mahasiswa.id = semester.id_mhs');
		$this->db->order_by('mahasiswa.id', $this->order);
		return $this->db->get();
  }

  public function get_data_join($where){
    $this->db->select('*');
		$this->db->from($this->table);
		$this->db->join($this->table2, 'mahasiswa.id = semester.id_mhs');
    $this->db->join($this->table3, 'mahasiswa.nama_prodi = prodi.id_prodi');
    $this->db->where($where);
		return $this->db->get();
  }

  public function ambil_id_mahasiswa($id){
    $hasil = $this->db->where('id', $id)->get('mahasiswa');
    if($hasil->num_rows() > 0){
      return $hasil->result();
    }
    else{
      return false;
    }
  }

  public function ambil_nimmhs($nim){
    $hasil = $this->db->where('nim', $nim)->get('mahasiswa');
    if($hasil->num_rows() > 0){
      return $hasil->result();
    }
    else{
      return false;
    }
  }

  public function ambil_sem_mahasiswa($id){
    $hasil = $this->db->where('id_mhs', $id)->get('semester');
    if($hasil->num_rows() > 0){
      return $hasil->result();
    }
    else{
      return false;
    }
  }

  public function ambil_nim_semester_mhs($id_mhs){
    $this->db->where("id_mhs", $id_mhs);
    return $this->db->get('semester');
  }

  public function ambil_prodi_mahasiswa($id_prod){
    $this->db->select('*');
		$this->db->from($this->table);
    $this->db->where('nama_prodi', $id_prod);
    $this->db->order_by('id', $this->order);
		return $this->db->get();
  }

  public function ambil_jenjang_prodi($where){
    $hasil = $this->db->where($where)->get('prodi');
    if($hasil->num_rows() > 0){
      return $hasil->result();
    }
    else{
      return false;
    }
  }

  public function insert_data($data, $table){
    $this->db->insert($table, $data);
  }

  public function insert_datasem($datasem, $table2){
    $this->db->insert($table2, $datasem);
  }

  public function insert_data_semester($dataup, $table2){
    $this->db->insert($table2, $dataup);
  }

  public function update_data($where, $data, $table){
    $this->db->where($where);
    $this->db->update($table, $data);
  }

  public function update_data_semester($where, $data, $table2){
    $this->db->where($where);
    $this->db->update($table2, $data);
  }

  public function hapus_data($where, $table){
    $this->db->where($where);
    $this->db->delete($table);
  }

  public function get_by_id($id){
    $this->db->where($this->id, $id);
    return $this->db->get($this->table)->row();
  }

}