<?php

class Pengampu_model extends CI_Model{
  public $table = 'pengampu';
  public $id_pengampu    = 'id_pengampu';
  public $order = 'DESC';

  var $table2 = 'matakuliah';

  var $table3 = 'tahun_akademik';

  var $table4 = 'dosen';

  var $table5 = 'kelas';

  var $table6 = 'mahasiswa';

  var $table7 = 'matkul_mhs';

  var $table8 = 'krs';

  public function tampil_data($table){
    $this->db->select('*');
		$this->db->from($this->table);
		$this->db->join($this->table2, 'pengampu.id_matkul = matakuliah.id_matkul');
		$this->db->join($this->table3, 'pengampu.id_thn_akad = tahun_akademik.id_thn_akad');
		$this->db->join($this->table4, 'pengampu.id_dosen = dosen.id_dosen');
		$this->db->join($this->table5, 'pengampu.kelas = kelas.id_kelas');
		$this->db->order_by('id_pengampu', $this->order);
		return $this->db->get();
  }

  public function mhs_ampu($where){
    $this->db->select('*');
    $this->db->from($this->table);
		$this->db->join($this->table5, 'pengampu.kelas = kelas.id_kelas');
		$this->db->join($this->table4, 'dosen.id_dosen = pengampu.id_dosen');
		$this->db->join($this->table2, 'matakuliah.id_matkul = pengampu.id_matkul');
		$this->db->join($this->table7, 'pengampu.id_pengampu = matkul_mhs.id_pengampu');
    $this->db->join($this->table6, 'matkul_mhs.id_mhs = mahasiswa.id');
		$this->db->where($where);
		return $this->db->get();
  }

  public function mhs_ampu_nilai($where){
    $this->db->select('*');
    $this->db->from($this->table);
		$this->db->join($this->table5, 'pengampu.kelas = kelas.id_kelas');
    $this->db->join($this->table3, 'pengampu.id_thn_akad = tahun_akademik.id_thn_akad');
		$this->db->join($this->table4, 'dosen.id_dosen = pengampu.id_dosen');
		$this->db->join($this->table2, 'matakuliah.id_matkul = pengampu.id_matkul');
		$this->db->join($this->table7, 'pengampu.id_pengampu = matkul_mhs.id_pengampu');
    $this->db->join($this->table6, 'matkul_mhs.id_mhs = mahasiswa.id');
		$this->db->where($where);
		return $this->db->get();
  }

  public function ambil_nilai($where){
    $this->db->select('*');
    $this->db->from($this->table8);
		$this->db->join($this->table6, 'krs.id_mhs = mahasiswa.id');
		$this->db->join($this->table2, 'krs.id_matkul = matakuliah.id_matkul');
		$this->db->join($this->table3, 'krs.id_thn_akad = tahun_akademik.id_thn_akad');
		$this->db->where($where);
		return $this->db->get();
  }

  public function mhs_ampu_ket($where){
    $this->db->select('*');
    $this->db->from($this->table);
		$this->db->join($this->table5, 'pengampu.kelas = kelas.id_kelas');
		$this->db->join($this->table4, 'dosen.id_dosen = pengampu.id_dosen');
		$this->db->join($this->table2, 'matakuliah.id_matkul = pengampu.id_matkul');
		$this->db->where($where);
		return $this->db->get();
  }

  public function ampumatkul($where){
    $this->db->select('*');
		$this->db->from($this->table);
		$this->db->join($this->table2, 'pengampu.id_matkul = matakuliah.id_matkul');
		$this->db->join($this->table3, 'pengampu.id_thn_akad = tahun_akademik.id_thn_akad');
		$this->db->join($this->table4, 'pengampu.id_dosen = dosen.id_dosen');
		$this->db->join($this->table5, 'pengampu.kelas = kelas.id_kelas');
		$this->db->order_by('id_pengampu', $this->order);
    $this->db->where($where);
		return $this->db->get();
  }

  public function cekpengampu($where){
    $this->db->select('*');
    $this->db->from($this->table);
		$this->db->where($where);
		return $this->db->get();
  }

  public function get_by_id($id){
    $hasil = $this->db->where('id_pengampu', $id)->get('pengampu');
    if($hasil->num_rows() > 0){
      return $hasil->result();
    }
    else{
      return false;
    }
  }

  public function tampil_thn_akad($table3){
    return $this->db->get($this->table3);
  }

  public function tampil_dosen($table4){
    return $this->db->get($this->table4);
  }

  public function tampil_matkul($table2){
    return $this->db->get($this->table2);
  }

  public function tampil_kelas($table5){
    return $this->db->get($this->table5);
  }

  public function tampil_mahasiswa($where){
    $this->db->select('*');
    $this->db->from($this->table6);
    $this->db->where($where);
		return $this->db->get();
  }

  public function insert_data($data, $table){
    $this->db->insert($table, $data);
  }

  public function insert_data_mhs($data, $table7){
    $this->db->insert($table7, $data);
  }
  
  public function ambil_kode_matakuliah($kode){
    $result = $this->db->where('kode_matakuliah', $kode)->get('matakuliah');

    if($result->num_rows() > 0){
      return $result->result();
    }
    else{
      return false;
    }
  }
  public function matkuldetail($kode){
    $this->db->select('*');
		$this->db->from($this->table);
		$this->db->join($this->table2, 'matakuliah.id_prodi = prodi.id_prodi');
		$this->db->where('kode_matakuliah', $kode);
		return $this->db->get();
  }

  public function ambil_matakuliah_wajib($wherewajib){
    $result = $this->db->where($wherewajib)->get('matakuliah');

    if($result->num_rows() > 0){
      return $result->result();
    }
    else{
      return false;
    }
  }

  public function update_data($where, $data, $table){
    $this->db->where($where);
    $this->db->update($table, $data);
  }

  public function hapus_data($where, $table){
    $this->db->where($where);
    $this->db->delete($table);
  }

  public function hapus_mhs($where, $table7){
    $this->db->where($where);
    $this->db->delete($table7);
  }
}