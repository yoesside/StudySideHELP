<?php

class Tahunakademik_model extends CI_Model{

  public function tampil_data($table){
    return $this->db->get($table);
  }

  public function insert_data($data, $table){
    $this->db->insert($table, $data);
  }

  public function edit_data($where, $table){
    return $this->db->get_where($table, $where);
  }

  public function ambil_aktif($table){
    return $this->db->get_where($table, 'status="Aktif"');
  }

  public function update_data($where, $data, $table){
    $this->db->where($where);
    $this->db->update($table, $data);
  }

  public function update_cek($id){
    $hasil = $this->db->where('id_thn_akad', $id)->get('tahun_akademik');
    if($hasil->num_rows() > 0){
      return $hasil->result();
    }
    else{
      return false;
    }
  }

  public function idmhs_cek($idmhs){
    $hasil = $this->db->where('id_mhs', $idmhs)->get('semester');
    if($hasil->num_rows() > 0){
      return $hasil->result();
    }
    else{
      return false;
    }
  }

  public function hapus_data($where, $table){
    $this->db->where($where);
    $this->db->delete($table);
  }

  public $table = 'tahun_akademik';
  public $id    = 'id_thn_akad';

  var $table1 = 'semester';

  public function get_by_id($id){
    $this->db->where($this->id, $id);
    return $this->db->get($this->table)->row();
  }
}