<?php

class Nilai extends CI_Controller{

  function __construct(){
    parent::__construct();

    $this->load->model('transkrip_model');
		$this->load->helper(array('form','url'));
		$this->load->library(array('form_validation','session','upload'));

    if(!isset($this->session->userdata['username'])){
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Anda belum login!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('auth');
    }
  }

  public function index(){
    $data['mahasiswa'] = $this->mahasiswa_model->tampil_data_join()->result();

    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/masuk_khs', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function nilai_aksi(){
    $this->_rulesKhs();

    if($this->form_validation->run() == FALSE){
      $this->index();
    }
    else{
      $nim = $this->input->post('nim', TRUE);
      $thn_akad = $this->input->post('id_thn_akad', TRUE);

      $query = "SELECT krs.id_thn_akad, krs.kode_matakuliah, matakuliah.nama_matakuliah, matakuliah.sks, krs.nilai FROM krs INNER JOIN matakuliah ON krs.kode_matakuliah=matakuliah.kode_matakuliah WHERE krs.nim=$nim AND krs.id_thn_akad=$thn_akad";

      $sql = $this->db->query($query)->result();

      $smt = $this->db->select('tahun_akademik, jns_semester')
                      ->from('tahun_akademik')
                      ->where(array('id_thn_akad' => $thn_akad))->get()->row();

      $query_str = "SELECT mahasiswa.nim, mahasiswa.nama_lengkap, prodi.nama_prodi FROM mahasiswa INNER JOIN prodi ON mahasiswa.nama_prodi=prodi.nama_prodi";

      $mhs = $this->db->query($query_str)->row();

      if($smt->jns_semester == 1){
        $tampilSemester = "Ganjil";
      }
      else{
        $tampilSemester = "Genap";
      }
    }

    $data = array(
      'mhs_data' => $sql,
      'mhs_nim' => $nim,
      'mhs_nama' => $mhs->nama_lengkap,
      'mhs_prodi' => $mhs->nama_prodi,
      'thn_akad' => $smt->tahun_akademik. "(" .$tampilSemester. ")",
    );

    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/khs', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function input_nilai(){
    $data = array(
      'kode_matakuliah' => set_value('kode_matakuliah'),
      'id_thn_akad'     => set_value('id_thn_akad'),
    );

    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/input_nilai_form', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function input_nilai_aksi(){
      $id_thn_akad = $this->input->post('id_thn_akad');
      $semester = $this->input->post('semester');
      $id_kelas = $this->input->post('id_kelas');
      $id_dosen = $this->input->post('id_dosen');
      $id_matkul = $this->input->post('id_matkul');
      
      $where = array(
        'id_thn_akad' => $id_thn_akad,
        'nmsemester' => $semester,
        'kelas' => $id_kelas,
        'id_dosen' => $id_dosen,
        'id_matkul' => $id_matkul,
      );

      $data['cekpengampu'] = $this->pengampu_model->cekpengampu($where , 'pengampu')->result();
      if(empty($data['cekpengampu'])){
        $data['error'] =
          '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            Data yang anda input belum tersedia
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>';

        $this->load->view('templates_administrator/header');
        $this->load->view('templates_administrator/sidebar');
        $this->load->view('administrator/input_nilai_form', $data);
        $this->load->view('templates_administrator/footer');
        
      }else{
        foreach($data['cekpengampu'] as $rwcekpengampu){
          $id_pengampu = $rwcekpengampu->id_pengampu;
        }
        redirect('nilai/isi_nilai/'.$id_pengampu);
      }
  }

  public function isi_nilai(){
    $id_pengampu = $this->uri->segment('3');

    $where = array(
      'pengampu.id_pengampu' => $id_pengampu,
    );
    $data['mhspgm'] = $this->pengampu_model->mhs_ampu_nilai($where, 'matkul_mhs')->result();
      
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/form_nilai', $data);
    $this->load->view('templates_administrator/footer');
  }
  public function isi_nilai1(){
      $kode_matakuliah = $this->uri->segment('3');
      $id_thn_akad = $this->uri->segment('4');
      $kode = $kode_matakuliah;
      $data['kodemtkul'] = $this->matakuliah_model->ambil_kode_matakuliah($kode);
      if (empty($data['kodemtkul'])) {
        $id_matakul = $kode_matakuliah;
      }else{
        foreach($data['kodemtkul'] as $idmatkul){
          $id_matakul = $idmatkul->id_matkul;
        }
      }

      $this->db->select('*');
      $this->db->from('krs as k');
      $this->db->join('mahasiswa as m', 'm.id = k.id_mhs');
      $this->db->join('matakuliah as d', 'k.id_matkul = d.id_matkul');
      $this->db->where('k.id_thn_akad', $id_thn_akad);
      $this->db->where('k.id_matkul', $id_matakul);
      $query = $this->db->get()->result();

      $data = array(
        'list_nilai' => $query,
        'kode_matakuliah' => $kode_matakuliah,
        'id_thn_akad' => $id_thn_akad
      );

      $this->load->view('templates_administrator/header');
      $this->load->view('templates_administrator/sidebar');
      $this->load->view('administrator/form_nilai', $data);
      $this->load->view('templates_administrator/footer');
    
  }

  public function simpan_nilai(){
    $kode_matkul  = $this->input->post('kode_matkul');
    $id_th_akad   = $this->input->post('id_th_akad');
    $id_krs       = $this->input->post('id_krs');
    $nilai_angka  = $this->input->post('nilai_angka');
    $sks          = $this->input->post('sks');
    $id_pengampu  = $this->input->post('id_pengampu');

    $datanilai = array();
    foreach ($id_krs as $key => $val) {

      if ($nilai_angka[$key] >='80' and $nilai_angka[$key] <= '100'){
        $nilai_huruf = 'A';
        $bobot = '4';
      }else if ($nilai_angka[$key] >='75' and $nilai_angka[$key] <= '79'){
        $nilai_huruf = 'B+';
        $bobot = '3.5';
      }else if ($nilai_angka[$key] >='70' and $nilai_angka[$key] <= '74'){
        $nilai_huruf = 'B';
        $bobot = '3';
      }else if ($nilai_angka[$key] >='65' and $nilai_angka[$key] <= '69'){
        $nilai_huruf = 'C+';
        $bobot = '2.5';
      }else if ($nilai_angka[$key] >='60' and $nilai_angka[$key] <= '64'){
        $nilai_huruf = 'C';
        $bobot = '2';
      }else if ($nilai_angka[$key] >='50' and $nilai_angka[$key] <= '59'){
        $nilai_huruf = 'D';
        $bobot = '1';
      }else if ($nilai_angka[$key] >='0' and $nilai_angka[$key] <= '49'){
        $nilai_huruf = 'E';
        $bobot = '0';
      }else{
        $nilai_huruf = 'F';
        $bobot = '-';
      }

      $nilai_akhir = $bobot * $sks[$key];
      //number_format($jumlahnilai_akhir/$dt->jumlah_sks, 2);
      $datanilai[] = array(      
        'id_krs'      => $id_krs[$key],        
        'nilai_angka' => $nilai_angka[$key],
        'nilai_huruf' => $nilai_huruf,
        'bobot'       => $bobot,    
        'nilai_akhir' => $nilai_akhir  
      );       
    } 
      
    $this->db->update_batch('krs', $datanilai, 'id_krs');  

    
    redirect('nilai/isi_nilai/'.$id_pengampu);
    
    
  }

  public function _rulesKhs(){
    $this->form_validation->set_rules('nim', 'nim', 'required');
    $this->form_validation->set_rules('id_thn_akad', 'id_thn_akad', 'required');
  }

  public function _rulesInputNilai(){
    $this->form_validation->set_rules('kode_matakuliah', 'Kode Mata Kuliah', 'required');
    $this->form_validation->set_rules('id_thn_akad', 'Tahun Akademik', 'required');
  }

}