<?php

class Dashboard_dsn extends CI_Controller{

  function __construct(){
    parent::__construct();

    if(!isset($this->session->userdata['username'])){
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Anda belum login!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('auth');
    }
  }

  public function index(){
    $data = $this->user_model->ambil_data($this->session->userdata['username']);
    $data = array(
      'username' => $data->username,
      'level'    => $data->level,
      'id_dosen'    => $data->id_dosen,
    );
    
    $this->load->view('templates_dosen/header');
    $this->load->view('templates_dosen/sidebar');
    $this->load->view('dosen/dashboard',$data);
    $this->load->view('templates_dosen/footer');
  }
}