<?php

class Dashboard_mhs extends CI_Controller{

  function __construct(){
    parent::__construct();

    if(!isset($this->session->userdata['username'])){
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Anda belum login!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('auth');
    }
  }

  public function index(){
    $idmhs = $this->session->userdata('id_mhs'); 

    $where1 = 'krs.id_mhs ='.'"'.$idmhs.'"';

    $where = 'id ='.'"'.$idmhs.'"';

    $data['group'] =  $this->transkrip_model->getSemesterGroup($where1)->result();
    $data['getjlhipk1'] = $this->transkrip_model->jumlah_nilaia_ipk($idmhs)->result();
    $data['getjlhipk2'] = $this->transkrip_model->jumlah_sks_ipk($idmhs)->result();
    $data['getmhs'] = $this->mahasiswa_model->get_data_join($where)->result();
    
    $this->load->view('templates_user/header');
    $this->load->view('templates_user/sidebar');
    $this->load->view('mahasiswa/dashboard',$data);
    $this->load->view('templates_user/footer');
  }
}