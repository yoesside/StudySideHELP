<?php

class Auth extends CI_Controller{

  public function index(){
    if(!isset($this->session->userdata['username'])){
      $this->load->view('administrator/login');
    }else{
      if($this->session->userdata('level') == 'admin'){
        redirect('dashboard');
      }else if($this->session->userdata('level') == 'mahasiswa'){
        redirect('dashboard_mhs');
      }else if($this->session->userdata('level') == 'dosen'){
        redirect('dashboard_dsn');
      }
    }
  }
  
  public function proses_login(){

    $this->form_validation->set_rules('username', 'Username', 'required', ['required' => 'Username wajib diisi']);
    $this->form_validation->set_rules('password', 'Password', 'required', ['required' => 'Password wajib diisi']);
    if($this->form_validation->run() == FALSE){
      $this->load->view('administrator/login');
    }
    else{
      $username = $this->input->post('username');
      $password = $this->input->post('password');

      $user = $username;
      $pass = md5($password);

      $cek = $this->login_model->cek_login($user, $pass);

      if($cek->num_rows() > 0){
        foreach($cek->result() as $ck){
          $sess_data['id_user'] = $ck->id_user;
          $sess_data['id_mhs'] = $ck->id_mhs;
          $sess_data['id_dosen'] = $ck->id_dosen;
          $sess_data['username'] = $ck->username;
          $sess_data['email'] = $ck->email;
          $sess_data['level'] = $ck->level;
          $sess_data['gambar'] = $ck->gambar;
          $sess_data['nama'] = $ck->nama;
          $sess_data['identitas'] = $ck->identitas;
          $sess_data['jenis_kelamin'] = $ck->jenis_kelamin;
          $sess_data['alamat'] = $ck->alamat;
          $sess_data['password'] = $password;

          $this->session->set_userdata($sess_data);
        }
        if($sess_data['level'] == 'admin'){
          redirect('dashboard');
        }
        else if($sess_data['level'] == 'mahasiswa'){
          redirect('dashboard_mhs');
        } else if($sess_data['level'] == 'dosen'){
          redirect('dashboard_dsn');
        }
        else{
          $this->session->set_flashdata(
            'pesan',
            '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                Username atau password salah
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>'
          );
          redirect('auth');
        }
      }
      else{
        $this->session->set_flashdata(
          'pesan',
          '<div class="alert alert-danger alert-dismissible fade show" role="alert">
              Username atau password salah
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>'
        );
        redirect('auth');
      }
    }
  }

  public function logout(){
    $this->session->sess_destroy();
    redirect('auth');
  }
}