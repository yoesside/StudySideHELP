<?php

class Tahun_akademik extends CI_Controller{

  function __construct(){
    parent::__construct();

    if(!isset($this->session->userdata['username'])){
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Anda belum login!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('auth');
    }
  }

  public function index(){
    $data['tahun_akademik'] = $this->tahunakademik_model->tampil_data('tahun_akademik')->result();
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/tahun_akademik', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function tambah_tahun_akademik(){
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/tahun_akademik_form');
    $this->load->view('templates_administrator/footer');
  }

  public function tambah_tahun_akademik_aksi(){
    $this->_rules();

    if($this->form_validation->run() == FALSE){
      $this->tambah_tahun_akademik();
    }
    else{
      $tahun_akademik = $this->input->post('tahun_akademik');
      $semester       = $this->input->post('semester');
      $status         = $this->input->post('status');
      $jadwal_awal    = $this->input->post('jadwal_awal');
      $jadwal_akhir   = $this->input->post('jadwal_akhir');

      if($status == '0'){
        $status = NULL;
      } else {
        $status         = $this->input->post('status');
      }

      $data = array(
        'tahun_akademik'    => $tahun_akademik,
        'jns_semester'      => $semester,   
        'status'            => $status,
        'jadwal_awal_krs'   => $jadwal_awal,
        'jadwal_akhir_krs'  => $jadwal_akhir
      ); 

      $this->tahunakademik_model->insert_data($data, 'tahun_akademik');
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data tahun akademik berhasil ditambahkan
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('krs');
    }
  }

  public function update($id){
    $where = array('id_thn_akad' => $id);
    $data['tahun_akademik'] = $this->tahunakademik_model->edit_data($where, 'tahun_akademik')->result();

    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/tahun_akademik_update', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function update_aksi(){
    $id             = $this->input->post('id_thn_akad');
    $tahun_akademik = $this->input->post('tahun_akademik');
    $semester       = $this->input->post('semester');
    $status         = $this->input->post('status');
    $jadwal_awal    = $this->input->post('jadwal_awal');
    $jadwal_akhir   = $this->input->post('jadwal_akhir');

    if($status == 'Tidak Aktif'){
      $status = NULL;
    } else {
      $status       = $this->input->post('status');
    }

    $data = array(
      'tahun_akademik'    => $tahun_akademik,
      'jns_semester'      => $semester,
      'status'            => $status,
      'jadwal_awal_krs'   => $jadwal_awal,
      'jadwal_akhir_krs'  => $jadwal_akhir
    );

    $where = array('id_thn_akad' => $id);

    $datast['cekst'] = $this->tahunakademik_model->update_cek($id);
      foreach($datast['cekst'] as $dtstatus){
        $dat_status = $dtstatus->status;
      }
      if($status != $dat_status) {
        $is_unique =  '|is_unique[tahun_akademik.status]';
      } else {
        $is_unique =  '';
      }
      


      $this->form_validation->set_rules('status', 'status', 'required'.$is_unique, [
        'required'  => 'Status wajib diisi!',
        'is_unique' => 'Masih ada tahun akademik yang aktif, mohon status yang masih aktif diubah dulu.'
      ]);

      if($this->form_validation->run() == false){
        $this-> update($id);
      } else {

      $this->tahunakademik_model->update_data($where, $data, 'tahun_akademik');
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data tahun akademik berhasil diupdate
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('krs');
    }
  }

  public function delete($id){
    $where = array('id_thn_akad' => $id);
    $this->tahunakademik_model->hapus_data($where, 'tahun_akademik');
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data tahun akademik berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('krs');
  }

  public function sem_baru(){
    $semesterbr = $this->input->post('sembaru');

    $data = array(
      'status_uang_kuliah'    => 'belum'
    );

    if($semesterbr == 'Semester_Baru'){
      $this->db->update('semester',$data);
    }else{
      echo'';
    }

    redirect('krs');
  }

  public function _rules(){
    $this->form_validation->set_rules('status', 'status', 'required|is_unique[tahun_akademik.status]', [
      'required' => 'Status wajib diisi!',
      'is_unique'     => 'Masih ada tahun akademik yang aktif, mohon status yang masih aktif diubah dulu.'
    ]);
    $this->form_validation->set_rules('tahun_akademik', 'tahun_akademik', 'required', [
      'required' => 'Tahun akademik wajib diisi!'
    ]);
    $this->form_validation->set_rules('semester', 'semester', 'required', [
      'required' => 'Semester wajib diisi!'
    ]);
  }
}