<?php

  use PhpOffice\PhpWord\PhpWord;
  use PhpOffice\PhpWord\Writer\Word2007;

  use PhpOffice\PhpSpreadsheet\Spreadsheet;
  use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

  use PhpOffice\PhpSpreadsheet\IOFactory;

  use \PhpOffice\PhpSpreadsheet\Writer\Pdf\Mpdf;

  use PhpOffice\PhpSpreadsheet\Worksheet\MemoryDrawing;

  use PhpOffice\PhpSpreadsheet\Writer\Html;

class Krs_mhs extends CI_Controller{

  function __construct(){
    parent::__construct();

    if(!isset($this->session->userdata['username'])){
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Anda belum login!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('auth');
    }
  }

  public function index(){
    $idmhs = $this->session->userdata('id_mhs'); 
    
    //ambil semester mahasiswa
    $data['cekidmhs'] = $this->tahunakademik_model->idmhs_cek($idmhs);
    foreach($data['cekidmhs'] as $semmhs){
      $sem_mhs = $semmhs->nm_semester;
    }

    //ambil id mahasiswa dari tabel untuk mendapatkan id prodi
    $data['dataid'] = $this->mahasiswa_model->ambil_id_mahasiswa($idmhs);
    foreach($data['dataid'] as $rowid){
      $id_prodi = $rowid->nama_prodi;
    }

    $wherewajib = array(
      'semester' => $sem_mhs,
      'id_prodi' => $id_prodi
    );

    $where = 'id ='.'"'.$idmhs.'"';
    $data['matkul'] = $this->matakuliah_model->ambil_matakuliah_wajib($wherewajib);
    $data['getmhs'] = $this->mahasiswa_model->get_data_join($where)->result();
    $data['tahun_akademik'] = $this->tahunakademik_model->ambil_aktif('tahun_akademik')->result();

    //untuk cek apakah mahasiswa yang login sudah mengisi krs
    foreach($data['tahun_akademik'] as $thnaktif){
      $tahunaktf = $thnaktif->id_thn_akad;
    }

    if(empty($data['tahun_akademik'])){
      $thn_aktif = '';
    }else{
      $thn_aktif = $tahunaktf;
    }

    $whereck = array(
      'id_thn_akad' => $thn_aktif,
      'krs.id_mhs'      => $idmhs
    );

    $wherekrs = array(
      'krs.id_mhs'      => $idmhs,
      'krs.semester'      => $sem_mhs
    );

    $data['cekkrs'] = $this->krs_model->cek_krs($whereck, 'krs');
    $data['krsada'] = $this->krs_model->cek_krs($wherekrs, 'krs');

    $data['tampilkrs'] = $this->krs_model->ambil_krs($wherekrs, 'krs')->result();
    
    $this->load->view('templates_user/header');
    $this->load->view('templates_user/sidebar');
    $this->load->view('mahasiswa/krs_masuk', $data);
    $this->load->view('templates_user/footer');
  }

  public function krs_aksi(){
    $this->_rulesKrs();

    if($this->form_validation->run() == FALSE){
      $this->index();
    }
    else{
      $nim = $this->input->post('nim', TRUE);
      $thn_akad = $this->input->post('id_thn_akad', TRUE);
    }

    if($this->mahasiswa_model->get_by_id($nim) == null){
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Data mahasiswa yang diinput belum terdaftar!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('krs');
    }

    $data = array(
      'nim' => $nim,
      'id_thn_akad' => $thn_akad,
      'nama_lengkap' => $this->mahasiswa_model->get_by_id($nim)->nama_lengkap
    );

    $dataKrs = array(
      'krs_data'       => $this->baca_krs($nim, $thn_akad),
      'nim'            => $nim,
      'id_thn_akad'    => $thn_akad,
      'tahun_akademik' => $this->tahunakademik_model->get_by_id($thn_akad)->tahun_akademik,
      'semester'       => $this->tahunakademik_model->get_by_id($thn_akad)->semester=='Ganjil'?'Ganjil':'Genap',
      'nama_lengkap'   => $this->mahasiswa_model->get_by_id($nim)->nama_lengkap,
      'prodi'          => $this->mahasiswa_model->get_by_id($nim)->nama_prodi,
    );

    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/krs_list', $dataKrs);
    $this->load->view('templates_administrator/footer');
  }

  public function baca_krs($nim, $thn_akad){
    $this->db->select('k.id_krs, k.kode_matakuliah, m.nama_matakuliah, m.sks');
    $this->db->from('krs as k');
    $this->db->where('k.nim', $nim);
    $this->db->where('k.id_thn_akad', $thn_akad);
    $this->db->join('matakuliah as m', 'm.kode_matakuliah = k.kode_matakuliah');

    $krs = $this->db->get()->result();
    return $krs;
  }

  public function tambah_krs_aksi(){
      $id_mhs       = $this->input->post('idmhs');
      $idthn        = $this->input->post('idthn');
      $id_matkul    = $this->input->post('id_matkul');
      $semsmhs    = $this->input->post('semsmhs');
      $skstot    = $this->input->post('skstot');
      $data = array();
      if (empty($id_matkul)){
        $this->session->set_flashdata(
          'pesan',
          '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            Data anda masih kosong atau tidak ada mata kuliah yang anda pilih
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>'
        );
        redirect('krs_mhs');
      }else{
        foreach ($id_matkul as $idmatkul) {
          $data[] = array(             
            'id_thn_akad' => $idthn,
            'id_mhs'      => $id_mhs,
            'id_matkul'   => $idmatkul,     
            'semester'    => $semsmhs     
          );      
        }    
        
        $datasks = array(             
          'id_ta_akad' => $idthn,
          'id_mhs'      => $id_mhs,    
          'semester'    => $semsmhs,    
          'jumlah_sks'    => $skstot     
        );      

        $this->krs_model->insert($data);
        $this->krs_model->insert_sks($datasks);
        $this->session->set_flashdata(
          'pesan',
          '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data KRS berhasil di submit
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>'
        );
        redirect('krs_mhs');
      }
  }

  public function update($id){
    $row = $this->krs_model->get_by_id($id);
    $th = $row->id_thn_akad;

    if($row){
      $data = array(
        'id_krs'          => set_value('id_krs', $row->id_krs),
        'id_thn_akad'     => set_value('id_thn_akad', $row->id_thn_akad),
        'nim'             => set_value('nim', $row->nim),
        'kode_matakuliah' => set_value('kode_matakuliah', $row->kode_matakuliah),
        'thn_akad_smt'    => $this->tahunakademik_model->get_by_id($th)->tahun_akademik,
        'semester'        => $this->tahunakademik_model->get_by_id($th)->semester==1?'Ganjil':'Genap',
      );

      $this->load->view('templates_administrator/header');
      $this->load->view('templates_administrator/sidebar');
      $this->load->view('administrator/krs_update', $data);
      $this->load->view('templates_administrator/footer');      
    }
    else{
      echo "Data tidak ada!";
    }
  }

  public function update_aksi(){
    $id_krs          = $this->input->post('id_krs', TRUE);
    $nim             = $this->input->post('nim', TRUE);
    $id_thn_akad     = $this->input->post('id_thn_akad', TRUE);
    $kode_matakuliah = $this->input->post('kode_matakuliah', TRUE);

    $data = array(
      'id_krs' => $id_krs,
      'id_thn_akad' => $id_thn_akad,
      'nim' => $nim,
      'kode_matakuliah' => $this->input->post('kode_matakuliah', TRUE),
    );

    $this->krs_model->update($id_krs, $data);
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-success alert-dismissible fade show" role="alert">
        Data KRS berhasil diupdate
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('krs/index');
  }

  public function delete($id){
    $where = array('id_krs' => $id);
    $this->krs_model->hapus_data($where, 'krs');
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data KRS berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('krs/index');
  }

  public function cetakKrsPdf($idmhs, $semester){

    $where = array(
      'krs.id_mhs'      => $idmhs,
      'krs.semester'      => $semester
    );

    $data['krs'] = $this->krs_model->ambil_krs_pdf($where, 'krs')->result();
    
		$this->load->view('mahasiswa/krs_pdf', $data);

		$html = $this->output->get_output(); 
    
    $mpdf = new \Mpdf\Mpdf();
    
    $mpdf->WriteHTML($html);
    $mpdf->Output('KRS Mahasiswa.pdf', \Mpdf\Output\Destination::INLINE);
	}

  public function cetakKRSXlsx($idmhs, $semester){
    $where = array(
      'krs.id_mhs'      => $idmhs,
      'krs.semester'      => $semester
    );

    date_default_timezone_set('Asia/Jakarta');
      // array bulan
        $bulan = array (
          1 =>   'Januari',
          'Februari',
          'Maret',
          'April',
          'Mei',
          'Juni',
          'Juli',
          'Agustus',
          'September',
          'Oktober',
          'November',
          'Desember'
        );
        $sem = array (
          1 =>   'Satu',
          'Dua',
          'Tiga',
          'Empat',
          'Lima',
          'Enam',
          'Tujuh',
          'Delapan'
        );

    $data['krs'] = $this->krs_model->ambil_krs_pdf($where, 'krs')->result();
    
    
    $spreadsheet = new Spreadsheet();
    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load('./vendor/template KRS.xlsx');
		$worksheet = $spreadsheet->getActiveSheet();
   
    $x = 15 ;
    $i = 16 ;
    $jlhmatkul = 0;
    $no = 1;
    foreach($data['krs'] as $rowkrs){ 
      $i++;
      $x++;
      $jlhmatkul++;
      $worksheet->mergeCells('B'.$x.':C'.$x);
      $worksheet->mergeCells('D'.$x.':H'.$x);

      $worksheet->getCell('A'.$x)->setValue($no++);
      $worksheet->getStyle('A'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
      
      $worksheet->getCell('B'.$x)->setValue($rowkrs->kode_matakuliah);
      $worksheet->getStyle('B'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

      $worksheet->getCell('D'.$x)->setValue($rowkrs->nama_matakuliah);
      $worksheet->getStyle('D'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

      $worksheet->getCell('I'.$x)->setValue($rowkrs->sks);
      $worksheet->getStyle('I'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
    }

    $worksheet->getCell('A8')->setValue('Tahun Akademik '.$rowkrs->tahun_akademik);
    $worksheet->getStyle('A8')->getFont()->setItalic(true);

    $worksheet->getCell('D10')->setValue(': '.$rowkrs->nim);
    $worksheet->getCell('D11')->setValue(': '.$rowkrs->nama_lengkap);
    $worksheet->getCell('D12')->setValue(': '.$rowkrs->tempat_lahir.', '.date("d", strtotime($rowkrs->tanggal_lahir)).' '.$bulan[date("n", strtotime($rowkrs->tanggal_lahir))].' '.date("Y", strtotime($rowkrs->tanggal_lahir)));
    $worksheet->getCell('I10')->setValue(': '.$rowkrs->nama_prodi);
    $worksheet->getCell('I11')->setValue(': '.$rowkrs->semester.' ('.$sem[$rowkrs->semester].')');

    $data['k_prodi'] = $this->krs_model->ambil_kprodi($rowkrs->ketua_prodi, 'dosen')->result();
    foreach($data['k_prodi'] as $rowkprodi){
      $nama_ketuaprd = $rowkprodi->nama_dosen;
    }

    $data['dosen_wali'] = $this->krs_model->ambil_kprodi($rowkrs->dosen_wali, 'dosen')->result();
    foreach($data['dosen_wali'] as $rowd_wali){
      $nama_dosen_wali = $rowd_wali->nama_dosen;
    }

    $j = $i+1;
    $worksheet->getCell('I'.$i)->setValue($rowkrs->jumlah_sks);
    $worksheet->getStyle('I'.($i))->getFont()->setBold(true);
    $worksheet->getStyle('I'.$i)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

    $worksheet->getCell('I'.$j)->setValue($jlhmatkul);
    $worksheet->getStyle('I'.$j)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

    $worksheet->mergeCells('A'.$i.':H'.$i);
    $worksheet->mergeCells('A'.$j.':H'.$j);
    $worksheet->mergeCells('A'.($j+3).':C'.($j+3));
    $worksheet->mergeCells('G'.($j+3).':H'.($j+3));
    $worksheet->mergeCells('A'.($j+4).':C'.($j+4));
    $worksheet->mergeCells('A'.($j+9).':C'.($j+9));
    $worksheet->mergeCells('G'.($j+9).':H'.($j+9));
    $worksheet->mergeCells('A'.($j+11).':I'.($j+11));

    
    $worksheet->getCell('A'.($i))->setValue('TOTAL SKS');
    $worksheet->getStyle('A'.($i))->getFont()->setBold(true);
    
    $worksheet->getCell('A'.($j))->setValue('Jumlah Mata Kuliah');

    $worksheet->getCell('A'.($j+3))->setValue('Ketua Progran Studi');
    $spreadsheet->getActiveSheet()->getStyle('A'.($j+3))
    ->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

    $worksheet->getCell('G'.($j+3))->setValue('Dosen Wali');
    $spreadsheet->getActiveSheet()->getStyle('G'.($j+3))
    ->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

    $worksheet->getCell('A'.($j+4))->setValue($rowkrs->nama_prodi);
    $spreadsheet->getActiveSheet()->getStyle('A'.($j+4))
    ->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

    $worksheet->getCell('A'.($j+9))->setValue('('.$nama_ketuaprd.')');
    $spreadsheet->getActiveSheet()->getStyle('A'.($j+9))
    ->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
    $worksheet->getStyle('A'.($j+9))->getFont()->setUnderline(true);

    $worksheet->getCell('G'.($j+9))->setValue('('.$nama_dosen_wali.')');
    $spreadsheet->getActiveSheet()->getStyle('G'.($j+9))
    ->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
    $worksheet->getStyle('G'.($j+9))->getFont()->setUnderline(true);

    $worksheet->getCell('A'.($j+11))->setValue('Perhatian: KRS ini merupakan Bukti Pengambilan Mata Kuliah dan menjadi syarat Pendaftaran Semester berikutnya');
    $worksheet->getStyle('A'.($j+11))->getFont()->setItalic(true);
    $worksheet->getStyle('A'.($j+11))->getFont()->setSize(8);

    $worksheet->getStyle('A16:'.'I'.$j)->applyFromArray([
        'borders' => [
            'allBorders' => [
                'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
            ],
        ],
    ]);

		$writer = new Xlsx($spreadsheet);
		
		$filename = 'KRS mahasiswa';
		
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
		header('Cache-Control: max-age=0');

		$writer->save('php://output');
  }

  public function cetakWordKRS($idmhs, $semester){
      $where = array(
        'krs.id_mhs'      => $idmhs,
        'krs.semester'      => $semester
      );

      date_default_timezone_set('Asia/Jakarta');
      // array bulan
        $bulan = array (
          1 =>   'Januari',
          'Februari',
          'Maret',
          'April',
          'Mei',
          'Juni',
          'Juli',
          'Agustus',
          'September',
          'Oktober',
          'November',
          'Desember'
        );
        $sem = array (
          1 =>   'Satu',
          'Dua',
          'Tiga',
          'Empat',
          'Lima',
          'Enam',
          'Tujuh',
          'Delapan'
        );

    $data['krs'] = $this->krs_model->ambil_krs_pdf($where, 'krs')->result();
        
    $phpWord = new PhpWord();
    $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor('./vendor/template KRS.docx');
    $no = 1;
    $jlhmatkul = 0;
    foreach($data['krs'] as $key => $vlue){
      $jlhmatkul++;
      $values[] = array(
        'no' => $no++,
        'kode' => $vlue->kode_matakuliah,
        'matakuliah' => $vlue->nama_matakuliah,
        'sks' => $vlue->sks
      );
    }

    $data['k_prodi'] = $this->krs_model->ambil_kprodi($vlue->ketua_prodi, 'dosen')->result();
    foreach($data['k_prodi'] as $rowkprodi){
      $nama_ketuaprd = $rowkprodi->nama_dosen;
    }

    $data['dosen_wali'] = $this->krs_model->ambil_kprodi($vlue->dosen_wali, 'dosen')->result();
    foreach($data['dosen_wali'] as $rowd_wali){
      $nama_dosen_wali = $rowd_wali->nama_dosen;
    }

    $templateProcessor->setValues(
      array(
        'nim' => $vlue->nim, 
        'nama' => $vlue->nama_lengkap,
        'ttglhr' => $vlue->tempat_lahir.', '.date("d", strtotime($vlue->tanggal_lahir)).' '.$bulan[date("n", strtotime($vlue->tanggal_lahir))].' '.date("Y", strtotime($vlue->tanggal_lahir)),
        'prodi' => $vlue->nama_prodi,
        'sem' => $vlue->semester,
        'semes' => $sem[$vlue->semester],
        'jlh' => $vlue->jumlah_sks,
        'jlhm' => $jlhmatkul,
        'prodi1' => $vlue->nama_prodi,
        'kprodi' => $nama_ketuaprd,
        'dwali' => $nama_dosen_wali,
        'tahun_akademik' => $vlue->tahun_akademik,
      )
    );
    
    $templateProcessor->cloneRowAndSetValues('kode', $values);
	
    header('Content-Type: application/msword');
        	header('Content-Disposition: attachment;filename=KRS mahasiswa.docx'); 
		header('Cache-Control: max-age=0');
		
		$templateProcessor->saveAs('php://output');
	}

  public function cetakKrsHTML($idmhs, $semester){

    $where = array(
      'krs.id_mhs'      => $idmhs,
      'krs.semester'      => $semester
    );
    $data['krs'] = $this->krs_model->ambil_krs_pdf($where, 'krs')->result();
		$this->load->view('mahasiswa/krs_html', $data);
	}


  public function _rulesKrs(){
    $this->form_validation->set_rules('nim', 'nim', 'required');
    $this->form_validation->set_rules('id_thn_akad', 'id_thn_akad', 'required');
  }

  public function _rules(){
    $this->form_validation->set_rules('id_thn_akad', 'id_thn_akad', 'required');
    $this->form_validation->set_rules('nim', 'nim', 'required');
    $this->form_validation->set_rules('kode_matakuliah', 'kode_matakuliah', 'required');
  }
}