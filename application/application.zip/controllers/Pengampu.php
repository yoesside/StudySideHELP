<?php

class Pengampu extends CI_Controller{

  function __construct(){
    parent::__construct();

    if(!isset($this->session->userdata['username'])){
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Anda belum login!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('auth');
    }
  }

  public function index(){
    $data['pengampu'] = $this->pengampu_model->tampil_data('pengampu')->result();
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/pengampu',$data);
    $this->load->view('templates_administrator/footer');
  }
  

  public function tambah_pengampu(){
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/pengampu_form');
    $this->load->view('templates_administrator/footer');
  }

  public function mahasiswa($id){
    $where = array(
      'pengampu.id_pengampu' => $id,
    );
    $data['mhspgm'] = $this->pengampu_model->mhs_ampu($where, 'matkul_mhs')->result();
    $data['mhspgmket'] = $this->pengampu_model->mhs_ampu_ket($where, 'pengampu')->result();
    $data['mhsampu'] = $this->pengampu_model->get_by_id($id);
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/pengampu_mahasiswa', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function tambah_pengampu_aksi(){
    $this->_rules();

    if($this->form_validation->run() == FALSE){
      $this->tambah_pengampu();
    }
    else{
      $id_thn_akad  = $this->input->post('id_thn_akad');
      $semester     = $this->input->post('semester');
      $id_kelas     = $this->input->post('id_kelas');
      $id_dosen     = $this->input->post('id_dosen');
      $id_matkul    = $this->input->post('id_matkul');

      $data = array(
        'id_dosen'    => $id_dosen,
        'id_matkul'   => $id_matkul,   
        'kelas'       => $id_kelas,
        'id_thn_akad' => $id_thn_akad,
        'nmsemester'  => $semester
      );

      $this->pengampu_model->insert_data($data, 'pengampu');
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data mata kuliah berhasil ditambahkan
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('pengampu');
    }
  }
  public function tambah_pengampumhs_aksi(){
      $id_pengampu  = $this->input->post('id_pengampu');
      $id_mhs       = $this->input->post('id_mhs');

      $data = array(
        'id_pengampu' => $id_pengampu,
        'id_mhs'      => $id_mhs,   
      );

      $this->pengampu_model->insert_data_mhs($data, 'matkul_mhs');
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data berhasil ditambahkan
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('pengampu/mahasiswa/'.$id_pengampu);
  }

  public function _rules(){
    $this->form_validation->set_rules('id_thn_akad', 'id_thn_akad', 'required', [
      'required' => 'Tahun Akademik wajib diisi!',
    ]);
    $this->form_validation->set_rules('semester', 'semester', 'required', [
      'required' => 'Semester wajib diisi!'
    ]);
    $this->form_validation->set_rules('id_kelas', 'id_kelas', 'required', [
      'required' => 'Kelas wajib diisi!'
    ]);
    $this->form_validation->set_rules('id_dosen', 'id_dosen', 'required', [
      'required' => 'Dosen wajib diisi!'
    ]);
    $this->form_validation->set_rules('id_matkul', 'id_matkul', 'required', [
      'required' => 'Kelas wajib diisi!'
    ]);
  }

  public function update($id){
    $where = array('kode_matakuliah' => $id);
    $data['matakuliah'] = $this->db->query("SELECT * FROM matakuliah mk, prodi prd WHERE mk.id_prodi=prd.id_prodi AND mk.kode_matakuliah='$id'")->result();
    $data['prodi'] = $this->prodi_model->tampil_data('prodi')->result();

    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/matakuliah_update',$data);
    $this->load->view('templates_administrator/footer');
  }

  public function update_aksi(){
    $id              = $this->input->post('kode_matakuliah');
    $kode_matakuliah = $this->input->post('kode_matakuliah');
    $nama_matakuliah = $this->input->post('nama_matakuliah');
    $sks             = $this->input->post('sks');
    $semester        = $this->input->post('semester');
    $jns_semester    = $this->input->post('jns_semester');
    $nama_prodi      = $this->input->post('nama_prodi');

    $data = array(
      'kode_matakuliah' => $kode_matakuliah,
      'nama_matakuliah' => $nama_matakuliah,
      'sks'             => $sks,
      'semester'        => $semester,
      'jns_semester'    => $jns_semester,
      'id_prodi'        => $nama_prodi,
    );

    // print_r($data);
    // die;

    $where = array(
      'kode_matakuliah' => $id
    );

    $this->matakuliah_model->update_data($where, $data, 'matakuliah');
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-success alert-dismissible fade show" role="alert">
        Data mata kuliah berhasil diupdate
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('matakuliah');
  }

  public function delete($id){
    $where = array('id_pengampu' => $id);
    $this->pengampu_model->hapus_data($where, 'pengampu');
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data matakuliah berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('pengampu');
  }
  public function delete_mhs($id_matkulmhs, $idpengampu){
    $where = array('id_matkul_mhs' => $id_matkulmhs);
    $this->pengampu_model->hapus_mhs($where, 'matkul_mhs');
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data matakuliah berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('pengampu/mahasiswa/'.$idpengampu);
  }
}