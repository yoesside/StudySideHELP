<?php

class Prodi extends CI_Controller{

  function __construct(){
    parent::__construct();

    if(!isset($this->session->userdata['username'])){
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Anda belum login!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('auth');
    }
  }

  public function index(){
    $data['prodi'] = $this->prodi_model->tampil_data('prodi')->result();
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/prodi', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function tambah_prodi(){
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/prodi_form');
    $this->load->view('templates_administrator/footer');
  }

  public function tambah_prodi_aksi(){
    $this->_rules();

    if($this->form_validation->run() == FALSE){
      $this->tambah_prodi();
    }
    else{
      $kode_prodi   = $this->input->post('kode_prodi');
      $nama_prodi   = $this->input->post('nama_prodi');
      $jenjang_studi   = $this->input->post('jenjang_studi');
      $dosen   = $this->input->post('dosen');

      $data = array(
        'kode_prodi'    => $kode_prodi  ,
        'nama_prodi'    => $nama_prodi,
        'jenjang_studi' => $jenjang_studi,
        'ketua_prodi'    => $dosen
      );

      $this->prodi_model->insert_data($data, 'prodi');
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data prodi berhasil ditambahkan
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('prodi');
    }
  }

  public function update($id){
    $where = array('id_prodi' => $id);
    $data['prodi'] = $this->db->query("SELECT * FROM prodi WHERE id_prodi='$id'")->result();

    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/prodi_update',$data);
    $this->load->view('templates_administrator/footer');
  }

  public function update_aksi(){
    $id = $this->input->post('id_prodi');
    $kode_prodi   = $this->input->post('kode_prodi');
    $nama_prodi   = $this->input->post('nama_prodi');
    $jenjang_studi   = $this->input->post('jenjang_studi');
    $dosen   = $this->input->post('dosen');
    
    $data = array(
      'kode_prodi'    => $kode_prodi,
      'nama_prodi'    => $nama_prodi,
      'jenjang_studi' => $jenjang_studi,
      'ketua_prodi'   => $dosen
    );

    $where = array(
      'id_prodi' => $id
    );

    $dataam['ambil'] = $this->prodi_model->ambil_id_akun($id);
    foreach($dataam['ambil'] as $dtkod){
      $code_prod = $dtkod->kode_prodi;
    }
    if($kode_prodi != $code_prod) {
        $is_unique =  '|is_unique[prodi.kode_prodi]';
    } else {
        $is_unique =  '';
    }
   

    $this->form_validation->set_rules('kode_prodi', 'kode_prodi', 'required'.$is_unique, [
      'required'  => 'Kode prodi wajib diisi!',
      'is_unique' => 'Kode prodi "<b>'.$kode_prodi.'</b>" sudah ada'
    ]);

    if($this->form_validation->run() == false){
			$this-> update($id);
		} else {		
    $this->prodi_model->update_data($where, $data, 'prodi');
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-success alert-dismissible fade show" role="alert">
        Data prodi berhasil diupdate
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('prodi');
  }
  }

  public function delete($id){
    $where = array('id_prodi' => $id);
    $this->prodi_model->hapus_data($where, 'prodi');
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data prodi berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('prodi');
  }

  public function _rules(){
    $this->form_validation->set_rules('kode_prodi', 'kode_prodi', 'required|is_unique[prodi.kode_prodi]', [
      'required'  => 'Kode prodi wajib diisi!',
      'is_unique' => 'Kode prodi sudah ada'
    ]);
    $this->form_validation->set_rules('nama_prodi', 'nama_prodi', 'required', [
      'required' => 'Nama prodi wajib diisi!'
    ]);
    $this->form_validation->set_rules('jenjang_studi', 'jenjang_studi', 'required', [
      'required' => 'Jenjang Studi wajib diisi!'
    ]);
    $this->form_validation->set_rules('dosen', 'dosen', 'required', [
      'required' => 'Ketua Prodi wajib diisi!'
    ]);
  }

  
}