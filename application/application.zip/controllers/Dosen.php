<?php

class Dosen extends CI_Controller{

  function __construct(){
    parent::__construct();

    $this->load->helper(array('form','url'));
		$this->load->library(array('form_validation','session','upload'));
    
    if(!isset($this->session->userdata['username'])){
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Anda belum login!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('auth');
    }
  }

  public function index(){
    $data['dosen'] = $this->dosen_model->tampil_data('dosen')->result();
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/dosen', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function detail($id){
    $data['detail'] = $this->dosen_model->ambil_id_dosen($id);
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/dosen_detail', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function profil_dsn(){
    $this->load->view('templates_dosen/header');
    $this->load->view('templates_dosen/sidebar');
    $this->load->view('dosen/profil_dsn');
    $this->load->view('templates_dosen/footer');
  }
  public function edit_profil_dsn(){
    $this->load->view('templates_dosen/header');
    $this->load->view('templates_dosen/sidebar');
    $this->load->view('dosen/edit_profil');
    $this->load->view('templates_dosen/footer');
  }

  public function tambah_dosen(){
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/dosen_form');
    $this->load->view('templates_administrator/footer');
  }

  public function jadi_user($id){
    $data_m['detail'] = $this->dosen_model->ambil_id_dosen($id);
    foreach($data_m['detail'] as $data_n){
      $nidn = $data_n->nidn;
    }
    $data = array(
      'status_user' => 'Sudah',
    );
    $data_u = array(
      'username' => $nidn,
      'id_dosen	'  => $id,
      'password' => md5($nidn),
      'identitas' => $nidn,
      'level' => 'dosen',
      'blokir' => 'Y'
    );

    $where = array('id_dosen' => $id);
    $this->dosen_model->update_data($where, $data, 'dosen');
    $this->dosen_model->insert_data($data_u, 'users');
   
    redirect('users');
  }

  public function tambah_dosen_aksi(){
    $this->_rules();
    if($this->form_validation->run() == FALSE){
      $this->tambah_dosen();
    }
    else{
      $nidn          = $this->input->post('nidn');
      $nama_dosen    = $this->input->post('nama_dosen');
      $alamat        = $this->input->post('alamat');
      $jenis_kelamin = $this->input->post('jenis_kelamin');
      $email         = $this->input->post('email');
      $telp          = $this->input->post('telp');
      $photo         = $_FILES['photo'];
      if($photo=''){
      }
      else{
        $config['upload_path']   = './assets/uploads';
        $config['allowed_types'] = 'jpg|jpeg|png|gif|tiff';

        $this->load->library('upload', $config);
        if(!$this->upload->do_upload('photo')){
          echo "Gagal Upload!";
          die();
        }
        else{
          $photo = $this->upload->data('file_name');
        }
      }

      $data = array(
        'nidn'          => $nidn,
        'nama_dosen'    => $nama_dosen,
        'alamat'        => $alamat,
        'jenis_kelamin' => $jenis_kelamin,
        'email'         => $email,
        'telp'          => $telp,
        'photo'         => $photo,
      );

      $this->dosen_model->insert_data($data, 'dosen');
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data dosen berhasil ditambahkan
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('dosen');
    }
  }

  public function update($id){
    $where = array('id_dosen' => $id);
    $data['dosen']     = $this->dosen_model->edit_data($where, 'dosen')->result();
    $data['detail']    = $this->dosen_model->ambil_id_dosen($id);
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/dosen_update', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function update_dosen_aksi(){
    $this->_rules();

    if($this->form_validation->run() == FALSE){
      $id = $this->input->post('id_dosen');
      $this->update($id);
    }
    else{
      $id            = $this->input->post('id_dosen');
      $nidn          = $this->input->post('nidn');
      $nama_dosen    = $this->input->post('nama_dosen');
      $alamat        = $this->input->post('alamat');
      $jenis_kelamin = $this->input->post('jenis_kelamin');
      $email         = $this->input->post('email');
      $telp          = $this->input->post('telp');
      $photo         = $_FILES['userfile']['name'];
      if($photo){
        $config['upload_path']   = './assets/uploads';
        $config['allowed_types'] = 'jpg|jpeg|png|gif|tiff';

        $this->load->library('upload', $config);
        if($this->upload->do_upload('userfile')){
          $userfile = $this->upload->data('file_name');
          $this->db->set('photo', $userfile);
        }
        else{
          echo "Gagal upload!";
        }
      }

      $data = array(
        'nidn'          => $nidn,
        'nama_dosen'    => $nama_dosen,
        'alamat'        => $alamat,
        'jenis_kelamin' => $jenis_kelamin,
        'email'         => $email,
        'telp'          => $telp
      );

      // print_r($data);
      // die;

      $where = array(
        'id_dosen' => $id,
      );

      $this->dosen_model->update_data($where, $data, 'dosen');
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data dosen berhasil diupdate
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('dosen');
    }
  }

  public function update_profil_dosen(){
    $config['upload_path']          = './assets/uploads';
    $config['allowed_types']        = 'gif|jpg|jpeg|png|bmp|pdf';
    $config['overwrite'] = TRUE;


    $this->upload->initialize($config);
    
    $id            = $this->input->post('id_dosen');
    $nama_dosen    = $this->input->post('nama_dosen');
    $alamat        = $this->input->post('alamat');
    $jenis_kelamin = $this->input->post('jenis_kelamin');
    $email         = $this->input->post('email');
    $telp          = $this->input->post('telp');
    $gbrmhs1        = $this->input->post('gbrmhs1');
    $gambarmhs      = $_FILES['gambarmhs']['name'];
  

    if ( ! $this->upload->do_upload('gambarmhs')){
      $error = array('error' => $this->upload->display_errors());
      $gambarmhs = $gbrmhs1;
    }else{
      $gambarmhs = $this->upload->data('file_name');
    }

    $data = array(
      'nama_dosen'    => $nama_dosen,
      'alamat'        => $alamat,
      'jenis_kelamin' => $jenis_kelamin,
      'email'         => $email,
      'telp'          => $telp,
      'photo'         => $gambarmhs
    );

    // print_r($data);
    // die;

    $where = array(
      'id_dosen' => $id,
    );

    $this->dosen_model->update_data($where, $data, 'dosen');
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-success alert-dismissible fade show" role="alert">
        Data dosen berhasil diupdate
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('dosen/profil_dsn');
  }

  public function delete($id){
    $where = array('nidn' => $id);
    $this->dosen_model->hapus_data($where, 'dosen');
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data dosen berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('dosen');
  }

  public function _rules(){
    $this->form_validation->set_rules('nidn', 'nidn', 'required', [
      'required' => 'NIDN wajib diisi!'
    ]);
    $this->form_validation->set_rules('nama_dosen', 'nama_dosen', 'required', [
      'required' => 'Nama dosen wajib diisi!'
    ]);
    $this->form_validation->set_rules('alamat', 'alamat', 'required', [
      'required' => 'Alamat wajib diisi!'
    ]);
    $this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required', [
      'required' => 'Jenis kelamin wajib diisi!'
    ]);
    $this->form_validation->set_rules('email', 'email', 'required', [
      'required' => 'Email wajib diisi!'
    ]);
    $this->form_validation->set_rules('telp', 'telp', 'required', [
      'required' => 'Nomor telepon wajib diisi!'
    ]);
  }
}