<?php defined('BASEPATH') OR exit('No direct script access allowed');

  use PhpOffice\PhpWord\PhpWord;
  use PhpOffice\PhpWord\Writer\Word2007;

  use PhpOffice\PhpSpreadsheet\Spreadsheet;
  use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

  use PhpOffice\PhpSpreadsheet\IOFactory;

  use \PhpOffice\PhpSpreadsheet\Writer\Pdf\Mpdf;

  use PhpOffice\PhpSpreadsheet\Worksheet\MemoryDrawing;

  use PhpOffice\PhpSpreadsheet\Writer\Html;


class Mahasiswa extends CI_Controller{

  function __construct(){
    parent::__construct();

    $this->load->helper(array('form','url'));
		$this->load->library(array('form_validation','session','upload'));

    if(!isset($this->session->userdata['username'])){
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Anda belum login!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('auth');
    }
  }

  public function index(){
    $data['prodi'] = $this->prodi_model->tampil_data('prodi')->result();
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/prodi_mhs', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function prodi($prodi){
    $data['prodi'] = $this->prodi_model->ambil_kode_prodi($prodi);
    foreach($data['prodi'] as $idprodi){
      $id_prod = $idprodi->id_prodi;
    }
    $data['mahasiswa'] = $this->mahasiswa_model->ambil_prodi_mahasiswa($id_prod)->result();
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/mahasiswa', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function detail($id){
    $data['detail'] = $this->mahasiswa_model->ambil_id_mahasiswa($id);
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/mahasiswa_detail', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function profil_mhs(){
    $this->load->view('templates_user/header');
    $this->load->view('templates_user/sidebar');
    $this->load->view('mahasiswa/profil_mhs');
    $this->load->view('templates_user/footer');
  }

  public function edit_profil_mhs(){
    $this->load->view('templates_user/header');
    $this->load->view('templates_user/sidebar');
    $this->load->view('mahasiswa/edit_profil');
    $this->load->view('templates_user/footer');
  }

  public function ubah_semester($id){
    $data['ubahsem'] = $this->mahasiswa_model->ambil_id_mahasiswa($id);
    $data['semester'] = $this->mahasiswa_model->ambil_sem_mahasiswa($id);
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/mahasiswa_semester', $data);
    $this->load->view('templates_administrator/footer');
  }
  public function ubahsemester_aksi(){
    $id_mhs     = $this->input->post('id_mhs');
    $nim        = $this->input->post('nim');
    $semester   = $this->input->post('semester');
    $data = array(
      'id_mhs' => $id_mhs,
      'nm_semester' => $semester
    );

    $dataup = array(
      'nm_semester' => $semester
    );

    $where = array(
      'id_mhs' => $id_mhs
    );

    $ceknim = $this->mahasiswa_model->ambil_nim_semester_mhs($id_mhs);

    if($ceknim->num_rows() > 0){
      $this->mahasiswa_model->update_data_semester($where, $dataup, 'semester');
    }else{
      $this->mahasiswa_model->insert_data_semester($data, 'semester');
    }
    
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-success alert-dismissible fade show" role="alert">
        Data mahasiswa berhasil ditambahkan
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('krs/hak_krs');
  }

  public function tambah_mahasiswa(){
    $data['prodi'] = $this->mahasiswa_model->tampil_data('prodi')->result();
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/mahasiswa_form', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function tambah_mahasiswa_aksi(){
    $this->_rules();
    if($this->form_validation->run() == FALSE){
      $this->tambah_mahasiswa();
    }
    else{
      $nim            = $this->input->post('nim');
      $nik            = $this->input->post('nik');
      $nama_lengkap   = $this->input->post('nama_lengkap');
      $alamat         = $this->input->post('alamat');
      $email          = $this->input->post('email');
      $telepon        = $this->input->post('telepon');
      $tempat_lahir   = $this->input->post('tempat_lahir');
      $tanggal_lahir  = $this->input->post('tanggal_lahir');
      $jenis_kelamin  = $this->input->post('jenis_kelamin');
      $status         = $this->input->post('status');
      $agama          = $this->input->post('agama');
      $kode_pos       = $this->input->post('kode_pos');
      $no_wa          = $this->input->post('no_wa');
      $asal_sma       = $this->input->post('asal_sma');
      $alamat_sma     = $this->input->post('alamat_sma');
      $jurusan_sma    = $this->input->post('jurusan_sma');
      $nama_ibu       = $this->input->post('nama_ibu');
      $nama_ayah      = $this->input->post('nama_ayah');
      $pekerjaan_ayah = $this->input->post('pekerjaan_ayah');
      $pekerjaan_ibu  = $this->input->post('pekerjaan_ibu');
      $nohp_ortu      = $this->input->post('nohp_ortu');
      $alamat_ortu    = $this->input->post('alamat_ortu');
      $ukuran_jaket   = $this->input->post('ukuran_jaket');
      $pilihan_kampus = $this->input->post('pilihan_kampus');
      $pilihan_kelas  = $this->input->post('pilihan_kelas');
      $jenjang_studi  = $this->input->post('jenjang_studi');
      $nama_prodi     = $this->input->post('nama_prodi');
      $dosen          = $this->input->post('dosen');
      $photo          = $_FILES['photo'];
      if($photo=''){
      }
      else{
        $config['upload_path']   = './assets_dashboard/images/icon';
        $config['allowed_types'] = 'jpg|jpeg|png|gif|tiff';
        $config['overwrite'] = TRUE;

        $this->upload->initialize($config);

        $this->load->library('upload', $config);
        if(!$this->upload->do_upload('photo')){
          echo "Gagal Upload!";
          die();
        }
        else{
          $photo = $this->upload->data('file_name');
        }
      }

      $data = array(
        'nim'            => $nim,
        'nik'            => $nik,
        'nama_lengkap'   => $nama_lengkap,
        'alamat'         => $alamat,
        'email'          => $email,
        'telepon'        => $telepon,
        'tempat_lahir'   => $tempat_lahir,
        'tanggal_lahir'  => $tanggal_lahir,
        'jenis_kelamin'  => $jenis_kelamin,
        'status'         => $status,
        'agama'          => $agama,
        'kode_pos'       => $kode_pos,
        'no_wa'          => $no_wa,
        'asal_sma'       => $asal_sma,
        'alamat_sma'     => $alamat_sma,
        'jurusan_sma'    => $jurusan_sma,
        'nama_ibu'       => $nama_ibu,
        'nama_ayah'      => $nama_ayah,
        'pekerjaan_ayah' => $pekerjaan_ayah,
        'pekerjaan_ibu'  => $pekerjaan_ibu,
        'nohp_ortu'      => $nohp_ortu,
        'alamat_ortu'    => $alamat_ortu,
        'ukuran_jaket'   => $ukuran_jaket,
        'pilihan_kampus' => $pilihan_kampus,
        'pilihan_kelas'  => $pilihan_kelas,
        'jenjang_studi'  => $jenjang_studi,
        'nama_prodi'     => $nama_prodi,
        'dosen_wali'     => $dosen,
        'photo'          => $photo
      );

      $this->mahasiswa_model->insert_data($data, 'mahasiswa');
      $data['getnim'] = $this->mahasiswa_model->ambil_nimmhs($nim);
      foreach($data['getnim'] as $get_nim){
        $id_mah = $get_nim->id;
      };
      $datasem = array(
        'id_mhs' => $id_mah
      );
      $this->mahasiswa_model->insert_datasem($datasem, 'semester');

      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data mahasiswa berhasil ditambahkan
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('mahasiswa');
    }
  }

  public function update($id){
    $where = array('id' => $id);
    $data['detail']    = $this->mahasiswa_model->ambil_id_mahasiswa($id);
    $this->load->view('templates_administrator/header');
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/mahasiswa_update', $data);
    $this->load->view('templates_administrator/footer');
  }

  public function jenjangStd($jenjang){
    if ($jenjang == '0'){
      echo '<option>--Pilih Program Studi--</option>'; 
    }else{
        $where = array('jenjang_studi' => $jenjang);
        $data['prodi']    = $this->mahasiswa_model->ambil_jenjang_prodi($where);
        foreach($data['prodi'] as $prod){ 
          echo '<option value="'.$prod->id_prodi.'">'.$prod->nama_prodi.'</option>';   
      }
    }
  }

  public function jenjangStdUpdate($jenjang, $id){
    $data['detail']    = $this->mahasiswa_model->ambil_id_mahasiswa($id);
    foreach($data['detail'] as $cekid){
      $cekid->nama_prodi;
    }
    if ($jenjang == '0'){
      echo '<option>--Pilih Program Studi--</option>'; 
    }else{
        $where = array('jenjang_studi' => $jenjang);
        $data['prodi']    = $this->mahasiswa_model->ambil_jenjang_prodi($where);
        foreach($data['prodi'] as $prod){ 
          if($prod->id_prodi == $cekid->nama_prodi){
            $select = "selected=selected";
          }else{
            $select = '';
          }
          echo '<option value="'.$prod->id_prodi.'"'.$select.'>'.$prod->nama_prodi.'</option>';   
      }
    }
  }

  public function update_mahasiswa_aksi(){
      $config['upload_path']          = './assets_dashboard/images/icon';
      $config['allowed_types']        = 'gif|jpg|jpeg|png|bmp|pdf';
      $config['overwrite'] = TRUE;


      $this->upload->initialize($config);

      $id            = $this->input->post('id');
      $nim            = $this->input->post('nim');
      $nik            = $this->input->post('nik');
      $nama_lengkap   = $this->input->post('nama_lengkap');
      $alamat         = $this->input->post('alamat');
      $email          = $this->input->post('email');
      $telepon        = $this->input->post('telepon');
      $tempat_lahir   = $this->input->post('tempat_lahir');
      $tanggal_lahir  = $this->input->post('tanggal_lahir');
      $jenis_kelamin  = $this->input->post('jenis_kelamin');
      $status         = $this->input->post('status');
      $agama          = $this->input->post('agama');
      $kode_pos       = $this->input->post('kode_pos');
      $no_wa          = $this->input->post('no_wa');
      $asal_sma       = $this->input->post('asal_sma');
      $alamat_sma     = $this->input->post('alamat_sma');
      $jurusan_sma    = $this->input->post('jurusan_sma');
      $nama_ibu       = $this->input->post('nama_ibu');
      $nama_ayah      = $this->input->post('nama_ayah');
      $pekerjaan_ayah = $this->input->post('pekerjaan_ayah');
      $pekerjaan_ibu  = $this->input->post('pekerjaan_ibu');
      $nohp_ortu      = $this->input->post('nohp_ortu');
      $alamat_ortu    = $this->input->post('alamat_ortu');
      $ukuran_jaket   = $this->input->post('ukuran_jaket');
      $pilihan_kampus = $this->input->post('pilihan_kampus');
      $pilihan_kelas  = $this->input->post('pilihan_kelas');
      $jenjang_studi  = $this->input->post('jenjang_studi');
      $nama_prodi     = $this->input->post('nama_prodi');
      $dosen          = $this->input->post('dosen');
      $gbrmhs1        = $this->input->post('gbrmhs1');
      $gambarmhs      = $_FILES['gambarmhs']['name'];
    

       if ( ! $this->upload->do_upload('gambarmhs')){
         $error = array('error' => $this->upload->display_errors());
         $gambarmhs = $gbrmhs1;
       }else{
         $gambarmhs = $this->upload->data('file_name');
       }
   

      $data = array(
        'nim'            => $nim,
        'nik'            => $nik,
        'nama_lengkap'   => $nama_lengkap,
        'alamat'         => $alamat,
        'email'          => $email,
        'telepon'        => $telepon,
        'tempat_lahir'   => $tempat_lahir,
        'tanggal_lahir'  => $tanggal_lahir,
        'jenis_kelamin'  => $jenis_kelamin,
        'status'         => $status,
        'agama'          => $agama,
        'kode_pos'       => $kode_pos,
        'no_wa'          => $no_wa,
        'asal_sma'       => $asal_sma,
        'alamat_sma'     => $alamat_sma,
        'jurusan_sma'    => $jurusan_sma,
        'nama_ibu'       => $nama_ibu,
        'nama_ayah'      => $nama_ayah,
        'pekerjaan_ayah' => $pekerjaan_ayah,
        'pekerjaan_ibu'  => $pekerjaan_ibu,
        'nohp_ortu'      => $nohp_ortu,
        'alamat_ortu'    => $alamat_ortu,
        'ukuran_jaket'   => $ukuran_jaket,
        'pilihan_kampus' => $pilihan_kampus,
        'pilihan_kelas'  => $pilihan_kelas,
        'jenjang_studi'  => $jenjang_studi,
        'nama_prodi'     => $nama_prodi,
        'dosen_wali'     => $dosen,
        'photo'          => $gambarmhs
      );

      // print_r($data);
      // die;

      $where = array(
        'id' => $id,
      );
      
      $datanm['ambil'] = $this->mahasiswa_model->ambil_id_mahasiswa($id);
      foreach($datanm['ambil'] as $dtnim){
        $dat_nim = $dtnim->nim;
        $dat_nik = $dtnim->nik;
      }
      if($nim != $dat_nim) {
        $is_unique =  '|is_unique[mahasiswa.nim]';
      } else {
        $is_unique =  '';
      }
      if($nik != $dat_nik) {
        $is_uniquenik =  '|is_unique[mahasiswa.nik]';
      } else {
        $is_uniquenik =  '';
      }


      $this->form_validation->set_rules('nim', 'nim', 'required'.$is_unique, [
        'required'  => 'Nim wajib diisi!',
        'is_unique' => 'Nim "<b>'.$nim.'</b>" sudah ada'
      ]);
      $this->form_validation->set_rules('nik', 'nik', 'required'.$is_uniquenik, [
        'required'  => 'NIK wajib diisi!',
        'is_unique' => 'NIK "<b>'.$nik.'</b>" sudah ada'
      ]);

      if($this->form_validation->run() == false){
        $this->update($id);
      } else {
      $this->mahasiswa_model->update_data($where, $data, 'mahasiswa');
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data mahasiswa berhasil diupdate
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('mahasiswa');
    }
  }

  public function update_mhs_aksi(){
    $config['upload_path']          = './assets_dashboard/images/icon';
    $config['allowed_types']        = 'gif|jpg|jpeg|png|bmp|pdf';
    $config['overwrite'] = TRUE;


    $this->upload->initialize($config);

    $id            = $this->input->post('id');
    $nama_lengkap   = $this->input->post('nama_lengkap');
    $alamat         = $this->input->post('alamat');
    $email          = $this->input->post('email');
    $telepon        = $this->input->post('telepon');
    $tempat_lahir   = $this->input->post('tempat_lahir');
    $tanggal_lahir  = $this->input->post('tanggal_lahir');
    $jenis_kelamin  = $this->input->post('jenis_kelamin');
    $agama          = $this->input->post('agama');
    $kode_pos       = $this->input->post('kode_pos');
    $no_wa          = $this->input->post('no_wa');
    $asal_sma       = $this->input->post('asal_sma');
    $alamat_sma     = $this->input->post('alamat_sma');
    $jurusan_sma    = $this->input->post('jurusan_sma');
    $nama_ibu       = $this->input->post('nama_ibu');
    $nama_ayah      = $this->input->post('nama_ayah');
    $pekerjaan_ayah = $this->input->post('pekerjaan_ayah');
    $pekerjaan_ibu  = $this->input->post('pekerjaan_ibu');
    $nohp_ortu      = $this->input->post('nohp_ortu');
    $alamat_ortu    = $this->input->post('alamat_ortu');
    $jenjang_studi  = $this->input->post('jenjang_studi');
    $gbrmhs1        = $this->input->post('gbrmhs1');
    $gambarmhs      = $_FILES['gambarmhs']['name'];
  

    if ( ! $this->upload->do_upload('gambarmhs')){
      $error = array('error' => $this->upload->display_errors());
      $gambarmhs = $gbrmhs1;
    }else{
      $gambarmhs = $this->upload->data('file_name');
    }


    $data = array(
      'nama_lengkap'   => $nama_lengkap,
      'alamat'         => $alamat,
      'email'          => $email,
      'telepon'        => $telepon,
      'tempat_lahir'   => $tempat_lahir,
      'tanggal_lahir'  => $tanggal_lahir,
      'jenis_kelamin'  => $jenis_kelamin,
      'agama'          => $agama,
      'kode_pos'       => $kode_pos,
      'no_wa'          => $no_wa,
      'asal_sma'       => $asal_sma,
      'alamat_sma'     => $alamat_sma,
      'jurusan_sma'    => $jurusan_sma,
      'nama_ibu'       => $nama_ibu,
      'nama_ayah'      => $nama_ayah,
      'pekerjaan_ayah' => $pekerjaan_ayah,
      'pekerjaan_ibu'  => $pekerjaan_ibu,
      'nohp_ortu'      => $nohp_ortu,
      'alamat_ortu'    => $alamat_ortu,
      'photo'          => $gambarmhs
    );

    // print_r($data);
    // die;

    $where = array(
      'id' => $id,
    );
    
      $this->mahasiswa_model->update_data($where, $data, 'mahasiswa');
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data mahasiswa berhasil diupdate
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('mahasiswa/profil_mhs');
  }

  public function delete($id){
    $where = array('id' => $id);
    $this->mahasiswa_model->hapus_data($where, 'mahasiswa');
    $this->session->set_flashdata(
      'pesan',
      '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data mahasiswa berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>'
    );
    redirect('mahasiswa');
  }

  public function cetakWord($id){
    $where = array('id' => $id);
    $data['detail']    = $this->mahasiswa_model->ambil_id_mahasiswa($id);

    foreach($data['detail'] as $bio){ 
      $nim            = $bio->nim;  
      $nik            = $bio->nik ;
      $nama_lengkap   = $bio->nama_lengkap;
      $alamat         = $bio->alamat;
      $email          = $bio->email;
      $telepon        = $bio->telepon;
      $tempat_lahir   = $bio->tempat_lahir;
      $tanggal_lahir  = $bio->tanggal_lahir;
      $jenis_kelamin  = $bio->jenis_kelamin;
      $status         = $bio->status;
      $agama          = $bio->agama;
      $kode_pos       = $bio->kode_pos;
      $no_wa          = $bio->no_wa;
      $asal_sma       = $bio->asal_sma;
      $alamat_sma     = $bio->alamat_sma;
      $jurusan_sma    = $bio->jurusan_sma;
      $nama_ibu       = $bio->nama_ibu;
      $nama_ayah      = $bio->nama_ayah;
      $pekerjaan_ayah = $bio->pekerjaan_ayah;
      $pekerjaan_ibu  = $bio->pekerjaan_ibu;
      $nohp_ortu      = $bio->nohp_ortu;
      $alamat_ortu    = $bio->alamat_ortu;
      $ukuran_jaket   = $bio->ukuran_jaket;
      $pilihan_kampus = $bio->pilihan_kampus;
      $pilihan_kelas  = $bio->pilihan_kelas;
      $jenjang_studi  = $bio->jenjang_studi;
      $nama_prodi     = $bio->nama_prodi;
      $photo          = $bio->photo;
    }

    $where = array('id_prodi' => $nama_prodi);
    $datap['prodi']    = $this->mahasiswa_model->ambil_jenjang_prodi($where);
    foreach($datap['prodi'] as $prod_nama){ 
      $prodi = $prod_nama->nama_prodi;
    }

    $phpWord = new PhpWord();
    $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor('./vendor/template.docx');
    $templateProcessor->setValues([
      'nim'            => $nim,
      'nik'            => $nik,
      'nama_lengkap'   => $nama_lengkap,
      'alamat'         => $alamat,
      'email'          => $email,
      'telepon'        => $telepon,
      'tempat_lahir'   => $tempat_lahir,
      'tanggal_lahir'  => $tanggal_lahir,
      'jenis_kelamin'  => $jenis_kelamin,
      'status'         => $status,
      'agama'          => $agama,
      'kode_pos'       => $kode_pos,
      'no_wa'          => $no_wa,
      'asal_sma'       => $asal_sma,
      'alamat_sma'     => $alamat_sma,
      'jurusan_sma'    => $jurusan_sma,
      'nama_ibu'       => $nama_ibu,
      'nama_ayah'      => $nama_ayah,
      'pekerjaan_ayah' => $pekerjaan_ayah,
      'pekerjaan_ibu'  => $pekerjaan_ibu,
      'nohp_ortu'      => $nohp_ortu,
      'alamat_ortu'    => $alamat_ortu,
      'ukuran_jaket'   => $ukuran_jaket,
      'pilihan_kampus' => $pilihan_kampus,
      'pilihan_kelas'  => $pilihan_kelas,
      'jenjang_studi'  => $jenjang_studi,
      'nama_prodi'     => $prodi
     ]);

     
     
    $templateProcessor->setImageValue('foto', array('path' => './assets_dashboard/images/icon/'.$photo, 'width' => 121.6, 'height' => 128, 'ratio' => false));
		
		header('Content-Type: application/msword');
        	header('Content-Disposition: attachment;filename=mahasiswa.docx'); 
		header('Cache-Control: max-age=0');
		
		$templateProcessor->saveAs('php://output');
	}

  public function cetakXlsx($id){
    $where = array('id' => $id);
    $data['detail']    = $this->mahasiswa_model->ambil_id_mahasiswa($id);

    foreach($data['detail'] as $bio){ 
      $nim            = $bio->nim;  
      $nik            = $bio->nik ;
      $nama_lengkap   = $bio->nama_lengkap;
      $alamat         = $bio->alamat;
      $email          = $bio->email;
      $telepon        = $bio->telepon;
      $tempat_lahir   = $bio->tempat_lahir;
      $tanggal_lahir  = $bio->tanggal_lahir;
      $jenis_kelamin  = $bio->jenis_kelamin;
      $status         = $bio->status;
      $agama          = $bio->agama;
      $kode_pos       = $bio->kode_pos;
      $no_wa          = $bio->no_wa;
      $asal_sma       = $bio->asal_sma;
      $alamat_sma     = $bio->alamat_sma;
      $jurusan_sma    = $bio->jurusan_sma;
      $nama_ibu       = $bio->nama_ibu;
      $nama_ayah      = $bio->nama_ayah;
      $pekerjaan_ayah = $bio->pekerjaan_ayah;
      $pekerjaan_ibu  = $bio->pekerjaan_ibu;
      $nohp_ortu      = $bio->nohp_ortu;
      $alamat_ortu    = $bio->alamat_ortu;
      $ukuran_jaket   = $bio->ukuran_jaket;
      $pilihan_kampus = $bio->pilihan_kampus;
      $pilihan_kelas  = $bio->pilihan_kelas;
      $jenjang_studi  = $bio->jenjang_studi;
      $nama_prodi     = $bio->nama_prodi;
      $photo          = $bio->photo;
    }

    $where = array('id_prodi' => $nama_prodi);
    $datap['prodi']    = $this->mahasiswa_model->ambil_jenjang_prodi($where);
    foreach($datap['prodi'] as $prod_nama){ 
      $prodi = $prod_nama->nama_prodi;
    }
   

    $spreadsheet = new Spreadsheet();
    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load('./vendor/template.xlsx');
		$worksheet = $spreadsheet->getActiveSheet();
    $worksheet->getCell('H9')->setValue($nama_lengkap);
		$worksheet->getCell('H10')->setValue($nim);
    $worksheet->getCell('H11')->setValue($nik);
    $worksheet->getCell('H12')->setValue($tempat_lahir.", ".$tanggal_lahir);
    $worksheet->getCell('H13')->setValue($jenis_kelamin);
    $worksheet->getCell('H14')->setValue($status);
    $worksheet->getCell('H15')->setValue($agama);
    $worksheet->getCell('H16')->setValue($alamat);
    $worksheet->getCell('H17')->setValue($kode_pos);
    $worksheet->getCell('H18')->setValue($telepon);
    $worksheet->getCell('H19')->setValue($no_wa);
    $worksheet->getCell('H20')->setValue($email);
    $worksheet->getCell('H21')->setValue($asal_sma);
    $worksheet->getCell('H22')->setValue($alamat_sma);
    $worksheet->getCell('H23')->setValue($jurusan_sma);
    $worksheet->getCell('H24')->setValue($nama_ibu);
    $worksheet->getCell('H25')->setValue($nama_ayah);
    $worksheet->getCell('H26')->setValue($pekerjaan_ayah);
    $worksheet->getCell('H27')->setValue($pekerjaan_ibu);
    $worksheet->getCell('H28')->setValue($nohp_ortu);
    $worksheet->getCell('H29')->setValue($alamat_ortu);
    $worksheet->getCell('H30')->setValue($ukuran_jaket);
    $worksheet->getCell('H31')->setValue($pilihan_kampus);
    $worksheet->getCell('H32')->setValue($prodi."-".$jenjang_studi);
    $worksheet->getCell('H33')->setValue($pilihan_kelas);
    
    $drawing = new \PhpOffice\PhpSpreadsheet\Worksheet\Drawing();
    $drawing->setCoordinates('F2');
 
    $drawing->setPath('./assets_dashboard/images/icon/'.$photo);
    $drawing->setHeight(128);

    $drawing->setWorksheet($spreadsheet->getActiveSheet());
    
    
    //'width' => 121.6

		$writer = new Xlsx($spreadsheet);
		
		$filename = 'mahasiswa';
		
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
		header('Cache-Control: max-age=0');

		$writer->save('php://output');
  }

  public function cetakDetailPdf($id){
    $where = array('id' => $id);
		$data['detail']    = $this->mahasiswa_model->ambil_id_mahasiswa($id);
    
		$this->load->view('administrator/biodata_pdf', $data);

		$html = $this->output->get_output(); 
    
    $mpdf = new \Mpdf\Mpdf();
    
    $mpdf->WriteHTML($html);
    $mpdf->Output('mahasiswa.pdf', \Mpdf\Output\Destination::INLINE);
	}

  public function Biodatahtml($id){
    $where = array('id' => $id);
		$data['detail']    = $this->mahasiswa_model->ambil_id_mahasiswa($id);
    
		$this->load->view('administrator/biodata_mahasiswa', $data);
	}

  public function _rules(){
    $this->form_validation->set_rules('nim', 'nim', 'required|is_unique[mahasiswa.nim]', [
      'required' => 'Nim wajib diisi!',
      'is_unique'     => 'Nim sudah ada'
    ]);
    $this->form_validation->set_rules('nik', 'nik', 'required|is_unique[mahasiswa.nik]', [
      'required' => 'NIK wajib diisi!',
      'is_unique'     => 'NIK sudah ada mohon periksa lagi'
    ]);
    $this->form_validation->set_rules('nama_lengkap', 'nama_lengkap', 'required', [
      'required' => 'Nama lengkap wajib diisi!'
    ]);
    $this->form_validation->set_rules('status', 'status', 'required', [
      'required' => 'Status wajib diisi!'
    ]);
    $this->form_validation->set_rules('agama', 'agama', 'required', [
      'required' => 'Agama wajib diisi!'
    ]);
    $this->form_validation->set_rules('alamat', 'alamat', 'required', [
      'required' => 'Alamat wajib diisi!'
    ]);
    $this->form_validation->set_rules('kode_pos', 'kode_pos', 'required', [
      'required' => 'Kode Pos wajib diisi!'
    ]);
    $this->form_validation->set_rules('no_wa', 'no_wa', 'required', [
      'required' => 'No WA wajib diisi!'
    ]);
    $this->form_validation->set_rules('asal_sma', 'asal_sma', 'required', [
      'required' => 'Asal SMA/SMK wajib diisi!'
    ]);
    $this->form_validation->set_rules('alamat_sma', 'alamat_sma', 'required', [
      'required' => 'Alamat SMA SMA/SMK wajib diisi!'
    ]);
    $this->form_validation->set_rules('jurusan_sma', 'jurusan_sma', 'required', [
      'required' => 'Jurusan SMA SMA/SMK wajib diisi!'
    ]);
    $this->form_validation->set_rules('nama_ibu', 'nama_ibu', 'required', [
      'required' => 'Nama Ibu wajib diisi!'
    ]);
    $this->form_validation->set_rules('nama_ayah', 'nama_ayah', 'required', [
      'required' => 'Nama Ayah wajib diisi!'
    ]);
    $this->form_validation->set_rules('pekerjaan_ayah', 'pekerjaan_ayah', 'required', [
      'required' => 'Pekerjaan Ayah wajib diisi!'
    ]);
    $this->form_validation->set_rules('pekerjaan_ibu', 'pekerjaan_ibu', 'required', [
      'required' => 'Pekerjaan Ibu wajib diisi!'
    ]);
    $this->form_validation->set_rules('nohp_ortu', 'nohp_ortu', 'required', [
      'required' => 'No HP Orang Tua wajib diisi!'
    ]);
    $this->form_validation->set_rules('alamat_ortu', 'alamat_ortu', 'required', [
      'required' => 'Alamat Orang Tua wajib diisi!'
    ]);
    $this->form_validation->set_rules('ukuran_jaket', 'ukuran_jaket', 'required', [
      'required' => 'Ukuran Jaket wajib diisi!'
    ]);
    $this->form_validation->set_rules('pilihan_kampus', 'pilihan_kampus', 'required', [
      'required' => 'Pilihan Kampus wajib diisi!'
    ]);
    $this->form_validation->set_rules('pilihan_kelas', 'pilihan_kelas', 'required', [
      'required' => 'Pilihan Kelas wajib diisi!'
    ]);
    $this->form_validation->set_rules('email', 'email', 'required', [
      'required' => 'Email wajib diisi!'
    ]);
    $this->form_validation->set_rules('telepon', 'telepon', 'required', [
      'required' => 'Nomor telepon wajib diisi!'
    ]);
    $this->form_validation->set_rules('tempat_lahir', 'tempat_lahir', 'required', [
      'required' => 'Tempat lahir wajib diisi!'
    ]);
    $this->form_validation->set_rules('tanggal_lahir', 'tanggal_lahir', 'required', [
      'required' => 'Tanggal lahir wajib diisi!'
    ]);
    $this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required', [
      'required' => 'Jenis kelamin wajib diisi!'
    ]);
    $this->form_validation->set_rules('nama_prodi', 'nama_prodi', 'required', [
      'required' => ' Nama prodi wajib diisi!'
    ]);
  }
}