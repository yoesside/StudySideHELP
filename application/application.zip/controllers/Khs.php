<?php

 use PhpOffice\PhpWord\PhpWord;
 use PhpOffice\PhpWord\Writer\Word2007;

 use PhpOffice\PhpSpreadsheet\Spreadsheet;
 use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

 use PhpOffice\PhpSpreadsheet\IOFactory;

 use \PhpOffice\PhpSpreadsheet\Writer\Pdf\Mpdf;

 use PhpOffice\PhpSpreadsheet\Worksheet\MemoryDrawing;

 use PhpOffice\PhpSpreadsheet\Writer\Html;
 
class Khs extends CI_Controller{

  function __construct(){
    parent::__construct();

    if(!isset($this->session->userdata['username'])){
      $this->session->set_flashdata(
        'pesan',
        '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Anda belum login!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>'
      );
      redirect('auth');
    }
  }

  public function index(){
    $idmhs = $this->session->userdata('id_mhs');

    $where = 'id ='.'"'.$idmhs.'"';

    $where1 = 'krs.id_mhs ='.'"'.$idmhs.'"';
    
    $data['getmhs'] = $this->mahasiswa_model->get_data_join($where)->result();
    $data['group'] =  $this->transkrip_model->getSemesterGroup($where1)->result();
    $data['getkhs'] = $this->transkrip_model->datakhs($where1)->result();
    $data['getjlhipk1'] = $this->transkrip_model->jumlah_nilaia_ipk($idmhs)->result();
    $data['getjlhipk2'] = $this->transkrip_model->jumlah_sks_ipk($idmhs)->result();

    $this->load->view('templates_user/header');
    $this->load->view('templates_user/sidebar');
    $this->load->view('mahasiswa/khs', $data);
    $this->load->view('templates_user/footer');
  }

  public function cetakKHSPdf($idmhs, $khssem){

    $where = array(
      'krs.id_mhs'      => $idmhs,
      'krs.semester'      => $khssem
    );
    $data['getkhs'] = $this->krs_model->ambil_krs_pdf($where, 'krs')->result();
    
		$this->load->view('mahasiswa/khs_pdf', $data);

		$html = $this->output->get_output(); 
    
    $mpdf = new \Mpdf\Mpdf();
    
    $mpdf->WriteHTML($html);
    $mpdf->Output('KHS Mahasiswa.pdf', \Mpdf\Output\Destination::INLINE);
	}

  public function cetakKHSHTML($idmhs, $khssem){

    $where = array(
      'krs.id_mhs'      => $idmhs,
      'krs.semester'      => $khssem
    );
    $data['getkhs'] = $this->krs_model->ambil_krs_pdf($where, 'krs')->result();
    
		$this->load->view('mahasiswa/khs_pdf', $data);

		$html = $this->output->get_output(); 
    
    $mpdf = new \Mpdf\Mpdf();
    
    $mpdf->WriteHTML($html);
	}

  public function cetakWordKHS($idmhs, $semester){
    $where = array(
      'krs.id_mhs'      => $idmhs,
      'krs.semester'      => $semester
    );

    date_default_timezone_set('Asia/Jakarta');
    // array bulan
      $bulan = array (
        1 =>   'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
      );
      $sem = array (
        1 =>   'Satu',
        'Dua',
        'Tiga',
        'Empat',
        'Lima',
        'Enam',
        'Tujuh',
        'Delapan'
      );

    $data['krs'] = $this->krs_model->ambil_krs_pdf($where, 'krs')->result();
        
    $phpWord = new PhpWord();
    $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor('./vendor/template KHS.docx');
    $no = 1;
    $jlhmatkul = 0;
    foreach($data['krs'] as $key => $vlue){
      $jlhmatkul++;
      $values[] = array(
        'no' => $no++,
        'kode' => $vlue->kode_matakuliah,
        'matakuliah' => $vlue->nama_matakuliah,
        'sks' => $vlue->sks,
        'angka' => $vlue->nilai_angka,
        'huruf' => $vlue->nilai_huruf,
        'bobot' => $vlue->bobot,
        'nxk' => $vlue->nilai_akhir,
      );
    }

    $data['jumlah'] = $this->transkrip_model->jumlah_nilai_akhir($idmhs, $semester)->result();
    foreach($data['jumlah'] as $rowjumlah){
      $jumlahnilai_akhir = $rowjumlah->jumlah;
    }

    $templateProcessor->setValues(
      array(
        'nim' => $vlue->nim, 
        'nama' => $vlue->nama_lengkap,
        'ttglhr' => $vlue->tempat_lahir.', '.date("d", strtotime($vlue->tanggal_lahir)).' '.$bulan[date("n", strtotime($vlue->tanggal_lahir))].' '.date("Y", strtotime($vlue->tanggal_lahir)),
        'prodi' => $vlue->nama_prodi,
        'sem' => $vlue->semester,
        'semes' => $sem[$vlue->semester],
        'jlh' => $vlue->jumlah_sks,
        'jlhm' => $jlhmatkul,
        'prodi1' => $vlue->nama_prodi,
        'tahun_akademik' => $vlue->tahun_akademik,
        'na' => $jumlahnilai_akhir,
        'ip' => number_format($jumlahnilai_akhir/$vlue->jumlah_sks, 2)
      )
    );
    
    $templateProcessor->cloneRowAndSetValues('kode', $values);

    header('Content-Type: application/msword');
          header('Content-Disposition: attachment;filename=KHS mahasiswa.docx'); 
    header('Cache-Control: max-age=0');
    
    $templateProcessor->saveAs('php://output');
}

  public function cetakKHSXlsx($idmhs, $semester){
    $where = array(
      'krs.id_mhs'      => $idmhs,
      'krs.semester'      => $semester
    );

    date_default_timezone_set('Asia/Jakarta');
      // array bulan
        $bulan = array (
          1 =>   'Januari',
          'Februari',
          'Maret',
          'April',
          'Mei',
          'Juni',
          'Juli',
          'Agustus',
          'September',
          'Oktober',
          'November',
          'Desember'
        );
        $sem = array (
          1 =>   'Satu',
          'Dua',
          'Tiga',
          'Empat',
          'Lima',
          'Enam',
          'Tujuh',
          'Delapan'
        );

    $data['krs'] = $this->krs_model->ambil_krs_pdf($where, 'krs')->result();
    
    
    $spreadsheet = new Spreadsheet();
    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load('./vendor/template KHS.xlsx');
    $worksheet = $spreadsheet->getActiveSheet();
  
    $x = 16 ;
    $i = 17 ;
    $no = 1;
    foreach($data['krs'] as $rowkrs){ 
      $i++;
      $x++;
      $worksheet->mergeCells('C'.$x.':E'.$x);

      $worksheet->getCell('A'.$x)->setValue($no++);
      $worksheet->getStyle('A'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
      
      $worksheet->getCell('B'.$x)->setValue($rowkrs->kode_matakuliah);
      $worksheet->getStyle('B'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

      $worksheet->getCell('C'.$x)->setValue($rowkrs->nama_matakuliah);
      $worksheet->getStyle('C'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

      $worksheet->getCell('F'.$x)->setValue($rowkrs->sks);
      $worksheet->getStyle('F'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
      
      $worksheet->getCell('G'.$x)->setValue($rowkrs->nilai_angka);
      $worksheet->getStyle('G'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
      
      $worksheet->getCell('H'.$x)->setValue($rowkrs->nilai_huruf);
      $worksheet->getStyle('H'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
    
      $worksheet->getCell('I'.$x)->setValue($rowkrs->bobot);
      $worksheet->getStyle('I'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
      
      $worksheet->getCell('J'.$x)->setValue($rowkrs->nilai_akhir);
      $worksheet->getStyle('J'.$x)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
    }

    $data['jumlah'] = $this->transkrip_model->jumlah_nilai_akhir($idmhs, $semester)->result();
      foreach($data['jumlah'] as $rowjumlah){
        $jumlahnilai_akhir = $rowjumlah->jumlah;
      }

    $worksheet->getCell('A8')->setValue('Tahun Akademik '.$rowkrs->tahun_akademik);
    $worksheet->getStyle('A8')->getFont()->setItalic(true);

    $worksheet->getCell('D10')->setValue(': '.$rowkrs->nim);
    $worksheet->getCell('D11')->setValue(': '.$rowkrs->nama_lengkap);
    $worksheet->getCell('D12')->setValue(': '.$rowkrs->tempat_lahir.', '.date("d", strtotime($rowkrs->tanggal_lahir)).' '.$bulan[date("n", strtotime($rowkrs->tanggal_lahir))].' '.date("Y", strtotime($rowkrs->tanggal_lahir)));
    $worksheet->getCell('J10')->setValue(': '.$rowkrs->nama_prodi);
    $worksheet->getCell('J11')->setValue(': '.$rowkrs->semester.' ('.$sem[$rowkrs->semester].')');

    $j = $i+1;
    $worksheet->getCell('F'.$i)->setValue($rowkrs->jumlah_sks);
    $worksheet->getStyle('F'.($i))->getFont()->setBold(true);
    $worksheet->getStyle('F'.$i)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
    
    $worksheet->getCell('J'.$i)->setValue($jumlahnilai_akhir);
    $worksheet->getStyle('J'.($i))->getFont()->setBold(true);
    $worksheet->getStyle('J'.$i)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
    
    $worksheet->setCellValueExplicit(
      'F'.$j,
      number_format($jumlahnilai_akhir/$rowkrs->jumlah_sks, 2),
      \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING
    );
    $worksheet->getStyle('F'.($j))->getFont()->setBold(true);
    $worksheet->getStyle('F'.$j)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);


    $worksheet->mergeCells('B'.$i.':E'.$i);
    $worksheet->mergeCells('B'.$j.':E'.$j);

    
    $worksheet->getCell('B'.($i))->setValue('JUMLAH');
    $worksheet->getStyle('B'.($i))->getFont()->setBold(true);
    
    $worksheet->getCell('B'.($j))->setValue('Indeks Prestasi (IP) : ');
    $worksheet->getStyle('B'.($j))->getFont()->setBold(true);

    $worksheet->getCell('A'.($j+3))->setValue('Keterangan');
    $worksheet->getCell('A'.($j+4))->setValue('Skala Nilai');
    $worksheet->getCell('A'.($j+5))->setValue('80- 100');
    $worksheet->getCell('A'.($j+6))->setValue('70 - 79 ');
    $worksheet->getCell('A'.($j+7))->setValue('60 - 69 ');
    $worksheet->getCell('A'.($j+8))->setValue('50 - 59 ');
    $worksheet->getCell('A'.($j+9))->setValue('0 - 49 ');
    $worksheet->getCell('B'.($j+5))->setValue(': A');
    $worksheet->getCell('B'.($j+6))->setValue(': B');
    $worksheet->getCell('B'.($j+7))->setValue(': C');
    $worksheet->getCell('B'.($j+8))->setValue(': D');
    $worksheet->getCell('B'.($j+9))->setValue(': E');
    $worksheet->getStyle('A'.($j+3).':B'.($j+9))->getFont()->setItalic(true);
    $worksheet->getStyle('A'.($j+3).':B'.($j+9))->getFont()->setSize(8);

    $worksheet->getStyle('A17:'.'J'.$i)->applyFromArray([
        'borders' => [
            'allBorders' => [
                'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
            ],
        ],
    ]);

    $worksheet->getStyle('A'.$j.':J'.$j)->applyFromArray([
      'borders' => [
          'bottom' => [
              'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_MEDIUM,
          ],
      ],
  ]);

    $writer = new Xlsx($spreadsheet);
    
    $filename = 'KHS mahasiswa';
    
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
    header('Cache-Control: max-age=0');

    $writer->save('php://output');
  }


  public function cetakKHSSemuaPdf($idmhs){
    $where = 'id_mhs ='.'"'.$idmhs.'"';

    $data['group'] =  $this->transkrip_model->getSemesterGroup($where)->result();
    
    $this->load->view('mahasiswa/khs_pdfsemua', $data);

    $html = $this->output->get_output(); 
    
    $mpdf = new \Mpdf\Mpdf();
    
    $mpdf->WriteHTML($html);
    $mpdf->Output('KHS Mahasiswafull.pdf', \Mpdf\Output\Destination::INLINE);
  }

  public function cetakKHSSemuaWord($idmhs){
    $where = 'id_mhs ='.'"'.$idmhs.'"';

    date_default_timezone_set('Asia/Jakarta');
    // array bulan
      $bulan = array (
        1 =>   'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
      );
      $sem = array (
        1 =>   'Satu',
        'Dua',
        'Tiga',
        'Empat',
        'Lima',
        'Enam',
        'Tujuh',
        'Delapan'
      );
      
    $phpWord = new PhpWord();
    $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor('./vendor/template KHSfull.docx');
    $data['group'] =  $this->transkrip_model->getSemesterGroup($where)->result();
    $klon = 1;
    $replacements = array();
    $i = 0;
    foreach($data['group'] as $group_name => $group) {
        $replacements[] = array(
            'sem' => $group->semester,
            'semes' => $sem[$group->semester],
            'no' => '${no_'.$i.'}',
            'kode' => '${kode_'.$i.'}',
            'matakuliah' => '${matakuliah_'.$i.'}',
            'sks' => '${sks_'.$i.'}',
            'sks' => '${sks_'.$i.'}',
            'angka' => '${angka_'.$i.'}',
            'huruf' => '${huruf_'.$i.'}',
            'bobot' => '${bobot_'.$i.'}',
            'nxk' => '${nxk_'.$i.'}',
            
            'nim' => '${nim_'.$i.'}', 
            'nama' => '${nama_'.$i.'}',
            'ttglhr' => '${ttglhr_'.$i.'}',
            'prodi' => '${prodi_'.$i.'}',
            'jlh' => '${jlh_'.$i.'}',
            'jlhm' => '${jlhm_'.$i.'}',
            'prodi1' => '${prodi1_'.$i.'}',
            'tahun_akademik' => '${tahun_akademik_'.$i.'}',
            'na' => '${na_'.$i.'}',
            'ip' => '${ip_'.$i.'}',
            'pageBreak' => '</w:t></w:r><w:r><w:br w:type="page"/></w:r><w:r><w:t>'
        );

        $i++;
    }
  
    $templateProcessor->cloneBlock('block_name', count($replacements), true, false, $replacements);
    $i = 0;
    $j = 1;
    foreach($data['group'] as $grup) {
      $wherekhs = array(
        'krs.id_mhs'      => $idmhs,
        'krs.semester'      => $grup->semester
      );
      $data['jumlah'] = $this->transkrip_model->jumlah_nilai_akhir($idmhs, $grup->semester)->result();
      foreach($data['jumlah'] as $rowjumlah){
        $jumlahnilai_akhir = $rowjumlah->jumlah;
      }
      $data['jumlah'] = $this->transkrip_model->jumlah_nilai_akhir($idmhs, $grup->semester)->result();
      foreach($data['jumlah'] as $rowjumlah){
        $jumlahnilai_akhir = $rowjumlah->jumlah;
      }
      $data['getkhs'] = $this->krs_model->ambil_krs_pdf($wherekhs, 'krs')->result();
        $j++;
        $values = array();
        foreach($data['getkhs'] as $row) {
            $values[] = array(
                "no_{$i}" => $j,
                "kode_{$i}" => $row->kode_matakuliah,
                "matakuliah_{$i}" => $row->nama_matakuliah,
                "sks_{$i}" => $row->sks,
                "angka_{$i}" => $row->nilai_angka,
                "huruf_{$i}" => $row->nilai_huruf,
                "bobot_{$i}" => $row->bobot,
                "nxk_{$i}" => $row->nilai_akhir,
            );
        }
        $templateProcessor->setValues(
          array(
            "nim_{$i}" => $row->nim, 
            "nama_{$i}" => $row->nama_lengkap,
            "ttglhr_{$i}" => $row->tempat_lahir.', '.date("d", strtotime($row->tanggal_lahir)).' '.$bulan[date("n", strtotime($row->tanggal_lahir))].' '.date("Y", strtotime($row->tanggal_lahir)),
            "prodi_{$i}" => $row->nama_prodi,
            "jlh_{$i}" => $row->jumlah_sks,
            "prodi1_{$i}" => $row->nama_prodi,
            "tahun_akademik_{$i}" => $row->tahun_akademik,
            "na_{$i}" => $jumlahnilai_akhir,
            "ip_{$i}" => number_format($jumlahnilai_akhir/$row->jumlah_sks, 2)
          ));
       
        
        $templateProcessor->cloneRowAndSetValues("kode_{$i}", $values);
        
        $i++;
    }

    header('Content-Type: application/msword');
          header('Content-Disposition: attachment;filename=KHS mahasiswafull.docx'); 
    header('Cache-Control: max-age=0');
    
    $templateProcessor->saveAs('php://output');
  }


  public function _rulesKrs(){
    $this->form_validation->set_rules('nim', 'nim', 'required');
    $this->form_validation->set_rules('id_thn_akad', 'id_thn_akad', 'required');
  }

  public function _rules(){
    $this->form_validation->set_rules('id_thn_akad', 'id_thn_akad', 'required');
    $this->form_validation->set_rules('nim', 'nim', 'required');
    $this->form_validation->set_rules('kode_matakuliah', 'kode_matakuliah', 'required');
  }
}